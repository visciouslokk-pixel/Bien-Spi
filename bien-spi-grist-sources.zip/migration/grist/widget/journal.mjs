export const TABLE = 'BienSpi_Revisions';
export const columns = ['Dossier_ID','Revision_ID','Parent_ID','Module','Bien_ID','Statut','Revision','Schema_Version','Cree_Le','Modifie_Le','Enveloppe_JSON'];
export function rowsFromTable(table) {
  if (!Array.isArray(table.id)) throw new Error('Table Grist invalide.');
  return table.id.map((id,i) => Object.fromEntries([['id',id], ...columns.map(k => [k,table[k]?.[i]])]));
}
export function heads(rows, id) {
  const own = rows.filter(r => r.Dossier_ID === id);
  const parents = new Set(own.map(r => r.Parent_ID).filter(Boolean));
  return own.filter(r => !parents.has(r.Revision_ID));
}
export function decode(row) {
  const value = JSON.parse(row.Enveloppe_JSON);
  if (value.id !== row.Dossier_ID || value.kind !== row.Module || value.revision !== Number(row.Revision))
    throw new Error('Dossier incohérent : aucune modification effectuée.');
  return value;
}
export function createRepository(api, notify = () => {}, options = {}) {
  const known = new Map(), pending = new Map(), drafts = new Map();
  let queue = Promise.resolve();
  const uuid = options.uuid || (() => crypto.randomUUID());
  const encodePayload = options.encodePayload || (async value=>value);
  const decodePayload = options.decodePayload || (async value=>value);
  const hydrate = async record => ({...record,payload:await decodePayload(record.payload)});
  const all = async () => rowsFromTable(await api.fetchTable(TABLE));
  function current(rows, id) {
    const found = heads(rows,id);
    if (found.length > 1) throw new Error('Conflit : deux versions de ce dossier sont conservées dans Grist. Contactez le référent avant de poursuivre.');
    return found[0] || null;
  }
  async function loadRecord(id) {
    const row = current(await all(),id);
    known.set(id,row?.Revision_ID || '');
    return row ? hydrate(decode(row)) : null;
  }
  async function listRecords(kind,bienId) {
    const rows = await all(), values = [];
    for (const id of new Set(rows.filter(r=>r.Module===kind && (!bienId || r.Bien_ID===bienId)).map(r => r.Dossier_ID))) {
      const row = current(rows,id);
      if (!row) continue;
      const record = decode(row);
      if (record.kind === kind && record.status !== 'trashed' && (!bienId || record.bienId === bienId)) values.push(record);
    }
    return values.sort((a,b) => b.updatedAt.localeCompare(a.updatedAt));
  }
  async function write(input) {
    const id = input.id || input.kind + '-' + uuid();
    drafts.set(id,structuredClone({...input,id}));
    notify('');
    const rows = await all();
    // A prior request may have reached Grist although its reply was lost.
    const attempt = pending.get(id);
    if (attempt) {
      const found = rows.find(r => r.Revision_ID === attempt.Revision_ID);
      if (found) { known.set(id,found.Revision_ID); pending.delete(id); }
      else {
        if ((current(rows,id)?.Revision_ID || '') !== attempt.Parent_ID) throw new Error('Conflit pendant une sauvegarde incertaine. Votre saisie est conservée dans cette fenêtre.');
        await api.applyUserActions([['AddRecord',TABLE,null,attempt]]);
        known.set(id,attempt.Revision_ID); pending.delete(id);
        return write({...input,id});
      }
    }
    const row = current(await all(),id);
    const base = row ? decode(row) : null;
    if (row && !known.has(id)) throw new Error('Rechargez ce dossier avant de le modifier.');
    if ((known.get(id) || '') !== (row?.Revision_ID || '')) throw new Error('Ce dossier a été modifié par un autre utilisateur. Votre saisie reste dans cette fenêtre ; exportez une copie de secours avant de recharger.');
    if (input.expectedRevision !== undefined && input.expectedRevision !== (base?.revision || 0)) throw new Error('Révision dépassée.');
    const payload = await encodePayload(JSON.parse(JSON.stringify(input.payload)));
    const status = input.status || base?.status || 'draft';
    if (base && JSON.stringify(payload) === JSON.stringify(base.payload) && status === base.status && input.bienId === base.bienId) {
      drafts.delete(id); return hydrate(base);
    }
    const now = new Date().toISOString();
    const record = {id,kind:input.kind,...(input.bienId ? {bienId:input.bienId} : {}),schemaVersion:base?.schemaVersion || 1,revision:(base?.revision || 0)+1,status,createdAt:base?.createdAt || now,updatedAt:now,payload};
    const json = JSON.stringify(record);
    if (new TextEncoder().encode(json).length > (options.maxBytes || 4_000_000)) throw new Error('Le texte du dossier dépasse la taille autorisée. Téléchargez une copie de secours avant de poursuivre.');
    const fields = {Dossier_ID:id,Revision_ID:uuid(),Parent_ID:row?.Revision_ID || '',Module:record.kind,Bien_ID:record.bienId || '',Statut:status,Revision:record.revision,Schema_Version:record.schemaVersion,Cree_Le:record.createdAt,Modifie_Le:now,Enveloppe_JSON:json};
    pending.set(id,fields);
    await api.applyUserActions([['AddRecord',TABLE,null,fields]]);
    known.set(id,fields.Revision_ID); pending.delete(id);
    const verified = current(await all(),id);
    if (verified?.Revision_ID !== fields.Revision_ID) throw new Error('Une modification concurrente a été détectée. Toutes les versions sont conservées.');
    drafts.delete(id);
    return hydrate(record);
  }
  function saveRecord(input) {
    const operation = queue.catch(() => {}).then(() => write(input));
    queue = operation;
    return operation.catch(error => { notify(error.message || 'Sauvegarde impossible.'); throw error; });
  }
  async function reopenRecord(id) {
    const record = await loadRecord(id);
    return record && saveRecord({...record,status:'draft'});
  }
  return {saveRecord,loadRecord,listRecords,reopenRecord,emergency:()=>[...drafts.values()],hasPending:()=>drafts.size>0};
}
