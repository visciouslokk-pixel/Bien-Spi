import test from 'node:test';
import assert from 'node:assert/strict';
import {createRepository,rowsFromTable,heads,TABLE,columns} from './journal.mjs';
function fixture() {
 const rows=[]; let serial=0; let fail=false,lose=false;
 const api={
  async fetchTable(name){assert.equal(name,TABLE);if(fail)throw new Error('réseau indisponible');return Object.fromEntries(['id',...columns].map(k=>[k,rows.map(r=>r[k])]));},
  async applyUserActions(actions){for(const [action,name,id,fields] of actions){assert.equal(action,'AddRecord');assert.equal(name,TABLE);rows.push({id:++serial,...fields});if(lose){lose=false;throw new Error('réponse perdue');}}}
 };
 return {rows,api,fail:()=>{fail=true;},lose:()=>{lose=true;}};
}
const input=(id='edl-test')=>({id,kind:'edl',payload:{typeBien:'maison',visitMode:'entrant',unknown:{preserved:true},photos:['data:image/png;base64,AAA']},status:'draft'});
test('création et relecture complète, photos et champs inconnus inclus',async()=>{const f=fixture(),a=createRepository(f.api);const saved=await a.saveRecord(input());assert.deepEqual(await a.loadRecord(saved.id),saved);assert.equal(saved.revision,1);});
test('aucune nouvelle révision si rien ne change',async()=>{const f=fixture(),a=createRepository(f.api);await a.saveRecord(input());await a.saveRecord(input());assert.equal(f.rows.length,1);});
test('historique append-only',async()=>{const f=fixture(),a=createRepository(f.api);await a.saveRecord(input());await a.saveRecord({...input(),payload:{note:'nouvelle'}});assert.equal(f.rows.length,2);assert.equal(heads(f.rows,'edl-test').length,1);assert.match(f.rows[0].Enveloppe_JSON,/preserved/);});
test('refuse une écriture sans chargement du dossier',async()=>{const f=fixture(),a=createRepository(f.api),b=createRepository(f.api);await a.saveRecord(input());await assert.rejects(b.saveRecord(input()),/Rechargez/);});
test('conflit inter-utilisateurs sans écrasement',async()=>{const f=fixture(),a=createRepository(f.api),b=createRepository(f.api);await a.saveRecord(input());await b.loadRecord('edl-test');await a.saveRecord({...input(),payload:{note:'A'}});await assert.rejects(b.saveRecord({...input(),payload:{note:'B'}}),/autre utilisateur/);assert.equal(f.rows.length,2);assert.equal(b.emergency()[0].payload.note,'B');});
test('branches simultanées signalées, aucune suppression',async()=>{const f=fixture(),a=createRepository(f.api);await a.saveRecord(input());f.rows.push({...f.rows[0],id:2,Revision_ID:'autre'});await assert.rejects(a.loadRecord('edl-test'),/deux versions/);assert.equal(f.rows.length,2);});
test('réponse perdue : réessai idempotent',async()=>{const f=fixture(),a=createRepository(f.api);f.lose();await assert.rejects(a.saveRecord(input()),/perdue/);await a.saveRecord(input());assert.equal(f.rows.length,1);assert.equal(a.hasPending(),false);});
test('erreur réseau : brouillon de secours et aucun faux succès',async()=>{const f=fixture(),a=createRepository(f.api);f.fail();await assert.rejects(a.saveRecord(input()),/réseau/);assert.equal(a.hasPending(),true);assert.equal(f.rows.length,0);});
test('limite du pilote explicite sans données perdues',async()=>{const f=fixture(),a=createRepository(f.api,()=>{},{maxBytes:20});await assert.rejects(a.saveRecord(input()),/volumineux/);assert.equal(a.emergency().length,1);assert.equal(f.rows.length,0);});
test('liste filtrée par module et bien',async()=>{const f=fixture(),a=createRepository(f.api);await a.saveRecord({...input(),bienId:'bien-1'});await a.saveRecord({id:'dia-1',kind:'dia',payload:{adresse:'fictive'}});assert.equal((await a.listRecords('edl','bien-1')).length,1);assert.equal((await a.listRecords('edl','autre')).length,0);});
test('finalisation et réouverture conservent le contenu',async()=>{const f=fixture(),a=createRepository(f.api);await a.saveRecord({...input(),status:'finalized'});assert.equal((await a.reopenRecord('edl-test')).status,'draft');assert.equal(f.rows.length,2);});
test('structure invalide refusée',()=>{assert.throws(()=>rowsFromTable({}),/invalide/);});

