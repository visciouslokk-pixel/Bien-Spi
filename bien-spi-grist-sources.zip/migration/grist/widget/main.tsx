import { createRoot } from 'react-dom/client';
import App from './App';
import '../../../src/styles/design-system.css';
import '../../../src/styles/app.css';
import './widget.css';
createRoot(document.getElementById('root')!).render(<App/>);

