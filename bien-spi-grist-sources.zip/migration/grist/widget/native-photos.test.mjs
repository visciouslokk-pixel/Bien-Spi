import test from 'node:test';
import assert from 'node:assert/strict';
import { nativePhotoRows, nativeImageDataUrl, readNativePhotos, escapePhotoLegend } from './native-photos.mjs';
const table = { id:[1,2,3], Dossier_ID:['EDL-ESSAI-PHOTOS','EDL-ESSAI-TABLETTE','EDL-ESSAI-PHOTOS'], Legende:['PC','Tablette','Vide'], Photo:[['L',8,8],['L',9],null] };
test('photos séparées par dossier, doublons ignorés et cellule vide acceptée', () => {
  assert.deepEqual(nativePhotoRows(table,'EDL-ESSAI-PHOTOS'),[{id:8,row:1,legende:'PC'}]);
  assert.equal(nativePhotoRows(table,'EDL-ESSAI-TABLETTE')[0].id,9);
});
test('refuse dossier métier et références malformées sans télécharger', () => {
  assert.throws(()=>nativePhotoRows(table,'dossier-reel'));
  assert.throws(()=>nativePhotoRows({...table,Photo:[['L',-1],null,null]},'EDL-ESSAI-PHOTOS'));
  assert.throws(()=>nativePhotoRows({...table,Photo:[]},'EDL-ESSAI-PHOTOS'));
});
test('formats reconnus sur le contenu, SVG et HTML refusés', () => {
  assert.match(nativeImageDataUrl(Uint8Array.from([137,80,78,71,13,10,26,10])),/^data:image\/png;base64,/);
  assert.match(nativeImageDataUrl(Uint8Array.from([255,216,255,0])),/^data:image\/jpeg;base64,/);
  assert.match(nativeImageDataUrl(new TextEncoder().encode('RIFF1234WEBP')),/^data:image\/webp;base64,/);
  assert.throws(()=>nativeImageDataUrl(new TextEncoder().encode('<html>connexion</html>')));
  assert.throws(()=>nativeImageDataUrl(new Uint8Array(8*1024*1024+1)));
});
test('lecture seule et arrêt sur refus : pas de PDF partiel présenté comme complet', async () => {
  let calls=0;
  const api={fetchTable:async name=>{assert.equal(name,'BienSpi_Photos_Essai');return table;}};
  const photos=await readNativePhotos(api,async id=>{calls++;assert.equal(id,8);return Uint8Array.from([255,216,255]);},'EDL-ESSAI-PHOTOS');
  assert.equal(calls,1);assert.equal(photos[0].legende,'PC');
  await assert.rejects(readNativePhotos(api,async()=>{throw Error('403');},'EDL-ESSAI-PHOTOS'),/403/);
});
test('les légendes ne deviennent pas du HTML actif dans le PDF',()=>assert.equal(escapePhotoLegend('<img onerror="x"> &'), '&lt;img onerror=&quot;x&quot;&gt; &amp;'));
