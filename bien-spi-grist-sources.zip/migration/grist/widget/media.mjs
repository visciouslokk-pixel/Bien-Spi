export const MEDIA_TABLE = 'BienSpi_Medias';
export const mediaColumns = [{id:'Empreinte',type:'Text'},{id:'Mime',type:'Text'},{id:'Fichier',type:'Attachments'}];
const marker = '__bienSpiAttachmentV1';
const imagePattern = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=\r\n]+)$/;
export async function fingerprint(bytes) {
  const hash = await crypto.subtle.digest('SHA-256',bytes);
  return Array.from(new Uint8Array(hash), n=>n.toString(16).padStart(2,'0')).join('');
}
export function unpackImage(value) {
  const match = typeof value === 'string' && value.match(imagePattern);
  if (!match) return null;
  const binary = atob(match[2]);
  return {mime:match[1],bytes:Uint8Array.from(binary,c=>c.charCodeAt(0))};
}
function dataUrl(bytes,mime) {
  let binary='';
  for(let i=0;i<bytes.length;i+=8192) binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return `data:${mime};base64,${btoa(binary)}`;
}
export function createMediaStore(transport) {
  const references = new Map(), images = new Map();
  let indexed=false;
  async function index() {
    if(indexed)return;
    for(const ref of await transport.list()) references.set(ref.hash,ref);
    indexed=true;
  }
  async function encode(value) {
    const image = unpackImage(value);
    if(image) {
      await index();
      const hash = await fingerprint(image.bytes);
      let ref = references.get(hash);
      if(!ref) {
        const id=await transport.upload(image.bytes,image.mime,hash);
        if(!Number.isSafeInteger(id)||id<=0)throw new Error('Pièce jointe non confirmée par Grist.');
        ref={id,hash,mime:image.mime};
        // Register a native Attachments cell before referencing the file in a revision.
        await transport.register(ref);
        references.set(hash,ref);
      }
      images.set(hash,value);
      return {[marker]:ref};
    }
    if(Array.isArray(value)) {const result=[];for(const child of value)result.push(await encode(child));return result;}
    if(value && typeof value === 'object') {const result={};for(const [key,child] of Object.entries(value))result[key]=await encode(child);return result;}
    return value;
  }
  async function hydrate(value) {
    if(value && typeof value==='object' && Object.keys(value).length===1 && value[marker]) {
      const ref=value[marker];
      if(!Number.isSafeInteger(ref.id)||ref.id<=0||!/^[a-f0-9]{64}$/.test(ref.hash)||!/^image\/(png|jpeg|webp)$/.test(ref.mime))throw new Error('Référence de pièce jointe invalide.');
      if(images.has(ref.hash))return images.get(ref.hash);
      const bytes=await transport.download(ref.id);
      if(await fingerprint(bytes)!==ref.hash)throw new Error('Pièce jointe altérée ou incomplète. Le dossier n’a pas été modifié.');
      const url=dataUrl(bytes,ref.mime);
      if(images.size>=80)images.delete(images.keys().next().value);
      images.set(ref.hash,url);
      return url;
    }
    if(Array.isArray(value)){const result=[];for(const child of value)result.push(await hydrate(child));return result;}
    if(value && typeof value==='object'){const result={};for(const [key,child]of Object.entries(value))result[key]=await hydrate(child);return result;}
    return value;
  }
  return {encode,hydrate};
}
