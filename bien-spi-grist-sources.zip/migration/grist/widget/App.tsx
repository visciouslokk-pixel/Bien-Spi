import { lazy,Suspense,useEffect,useState } from 'react';
import { HomePage } from '../../../src/features/home/HomePage';
import { useRoute } from './useRoute';
import { initialize,message,subscribe,downloadEmergency,hasPending } from './repository';
import { installKeyboardViewportGuard } from '../../../src/infrastructure/android/keyboardViewport';
import {MediaDiagnostic} from './MediaDiagnostic';
const NativePhotoTrial=lazy(()=>import('./NativePhotoTrial').then(m=>({default:m.NativePhotoTrial})));
const EdlTypePage=lazy(()=>import('../../../src/features/edl/EdlTypePage').then(m=>({default:m.EdlTypePage})));
const EdlModePage=lazy(()=>import('../../../src/features/edl/EdlModePage').then(m=>({default:m.EdlModePage})));
const EdlEntryPage=lazy(()=>import('../../../src/features/edl/EdlEntryPage').then(m=>({default:m.EdlEntryPage})));
const DiaEntryPage=lazy(()=>import('../../../src/features/dia/DiaEntryPage').then(m=>({default:m.DiaEntryPage})));
export default function App() {
  const route=useRoute(), [ready,setReady]=useState(false), [status,setStatus]=useState('Connexion au document Grist…'), [error,setError]=useState('');
  const nativeTrial=new URLSearchParams(window.location.search).get('diagnostic')==='photos-natives';
  async function connect() { try { if(!nativeTrial) await initialize();setReady(true); } catch { setStatus('Connexion non établie. Ouvrez cette interface depuis Grist et vérifiez les autorisations du widget.'); } }
  useEffect(()=>{
    const stop=subscribe(()=>setError(message()));
    const keyboard=installKeyboardViewportGuard();
    const before=(event:BeforeUnloadEvent)=>{if(hasPending()){event.preventDefault();event.returnValue='';}};
    window.addEventListener('beforeunload',before);
    if(window.parent===window) setStatus('Cette interface doit être ouverte dans le document Grist Bien SPI. Aucun dossier métier n’est hébergé sur cette page publique.');
    else if(window.grist) {
      window.grist.onOptions((_options,settings)=>{if(settings?.accessLevel==='full') void connect();});
      window.grist.ready({requiredAccess:'full'});
      void connect();
    } else setStatus('Le composant de connexion Grist n’a pas chargé. Vérifiez la connexion Internet.');
    return()=>{stop();keyboard();window.removeEventListener('beforeunload',before);};
  },[]);
  if(!ready) return <main className="bs-page"><h1>Bien SPI</h1><p role="status">{status}</p><button className="bs-button" onClick={()=>void connect()}>Réessayer la connexion</button></main>;
  if(new URLSearchParams(window.location.search).get('diagnostic')==='medias')return <MediaDiagnostic/>;
  if(nativeTrial)return <Suspense fallback={<main className="bs-page">Chargement de l’essai photo…</main>}><NativePhotoTrial/></Suspense>;
  const edl=route.pathname.match(/^\/edl\/new\/([^/]+)$/), mode=route.pathname.match(/^\/edl\/mode\/([^/]+)$/);
  let content=<HomePage/>;
  if(route.pathname==='/edl')content=<EdlTypePage search={route.search}/>;
  else if(mode)content=<EdlModePage type={decodeURIComponent(mode[1])} search={route.search}/>;
  else if(edl)content=<EdlEntryPage key={route.pathname+route.search} type={decodeURIComponent(edl[1])} search={route.search}/>;
  else if(route.pathname==='/dia/new')content=<DiaEntryPage key={route.pathname+route.search} search={route.search}/>;
  return <>{error&&<aside role="alert" className="grist-error"><p>{error}</p><button className="bs-button" onClick={downloadEmergency}>Télécharger une copie de secours</button><p>Ne fermez pas cette fenêtre avant d’avoir confirmé la sauvegarde ou téléchargé la copie.</p></aside>}<Suspense fallback={<main className="bs-page">Chargement du formulaire…</main>}>{content}</Suspense></>;
}
