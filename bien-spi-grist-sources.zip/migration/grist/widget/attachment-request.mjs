// Grist requires a non-simple request header for multipart POST on older servers.
// Never log, persist, or expose the short-lived document token in error messages.
export function createAttachmentRequest(getAccessToken,fetcher=fetch,{timeoutMs=60000}={}) {
  return async function attachmentRequest(path,body) {
    if(!/^\/attachments(?:\/\d+\/download)?$/.test(path))throw new Error('Chemin de pièce jointe invalide.');
    let grant;
    try {grant=await getAccessToken({readOnly:!body});}
    catch {throw new Error('Autorisation du transfert d’images refusée par Grist. La saisie n’a pas été effacée.');}
    const base=new URL(grant.baseUrl);
    if(base.protocol!=='https:' || base.hostname!=='grist.grandlyon.fr' || base.username || base.password)throw new Error('Serveur de pièces jointes non autorisé.');
    const url=new URL(base.href.replace(/\/$/,'')+path);
    url.searchParams.set('auth',grant.token);
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
    try {
      const response=await fetcher(url,{
        method:body?'POST':'GET',body,
        ...(body?{headers:{'X-Requested-With':'XMLHttpRequest'}}:{}),
        credentials:'omit',referrerPolicy:'no-referrer',signal:controller.signal,
      });
      if(!response.ok)throw new Error(`Pièce jointe non transférée (HTTP ${response.status}). Réessayez avec une connexion.`);
      if(body) {
        const ids=await response.json();
        if(!Array.isArray(ids)||ids.length!==1||!Number.isSafeInteger(ids[0])||ids[0]<=0)throw new Error('Pièce jointe : réponse Grist non reconnue.');
        return ids;
      }
      return new Uint8Array(await response.arrayBuffer());
    } catch(error) {
      if(error instanceof Error && error.message.startsWith('Pièce jointe'))throw error;
      throw new Error('Transfert d’image interrompu ou refusé entre l’application et Grist. Gardez la saisie ouverte et téléchargez une copie de secours.');
    } finally {clearTimeout(timer);}
  };
}
