import test from 'node:test';
import assert from 'node:assert/strict';
import {createAttachmentRequest} from './attachment-request.mjs';
const grant={baseUrl:'https://grist.grandlyon.fr/o/docs/api/docs/test',token:'temporary-test-token'};
test('upload multipart : en-tête anti-CSRF, droit écriture, aucun cookie et boundary automatique',async()=>{
  const body=new FormData();body.append('upload',new Blob(['synthetic'],{type:'image/png'}),'test.png');
  const request=createAttachmentRequest(async opts=>{assert.deepEqual(opts,{readOnly:false});return grant;},async(url,opts)=>{
    assert.equal(url.pathname,'/o/docs/api/docs/test/attachments');assert.equal(url.searchParams.get('auth'),grant.token);
    assert.equal(opts.headers['X-Requested-With'],'XMLHttpRequest');assert.equal(opts.headers['Content-Type'],undefined);
    assert.equal(opts.body,body);assert.equal(opts.credentials,'omit');assert.equal(opts.method,'POST');return new Response('[21]',{status:200});
  });
  assert.deepEqual(await request('/attachments',body),[21]);
});
test('lecture : jeton lecture seule et contenu binaire',async()=>{
 const request=createAttachmentRequest(async opts=>{assert.equal(opts.readOnly,true);return grant;},async()=>new Response(new Uint8Array([1,2,3])));
 assert.deepEqual(await request('/attachments/21/download'),new Uint8Array([1,2,3]));
});
test('échec HTTP clairement signalé sans divulguer le jeton',async()=>{
 const request=createAttachmentRequest(async()=>grant,async()=>new Response('private details',{status:403}));
 await assert.rejects(request('/attachments',new FormData()),error=>/HTTP 403/.test(error.message)&&!error.message.includes(grant.token));
});
test('erreur réseau nettoyée, aucune URL sensible dans le message',async()=>{
 const request=createAttachmentRequest(async()=>grant,async url=>{throw new Error(String(url));});
 await assert.rejects(request('/attachments',new FormData()),error=>/interrompu/.test(error.message)&&!error.message.includes(grant.token));
});
test('destination étrangère refusée avant toute transmission',async()=>{
 const request=createAttachmentRequest(async()=>({...grant,baseUrl:'https://example.com/api/docs/test'}),()=>{assert.fail('ne doit pas transmettre');});
 await assert.rejects(request('/attachments',new FormData()),/non autorisé/);
});
test('réponse de connexion HTML ou IDs invalides jamais confondus avec une sauvegarde',async()=>{
 for(const value of ['<html>login</html>','[]','[0]','["21"]']){
 const request=createAttachmentRequest(async()=>grant,async()=>new Response(value));
 await assert.rejects(request('/attachments',new FormData()));
 }
});
