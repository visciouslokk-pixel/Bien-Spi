import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { readFileSync } from 'node:fs';
import { zipSync, strToU8 } from 'fflate';
const root=fileURLToPath(new URL('.',import.meta.url));
const source=path.resolve(root,'../../../src').replaceAll('\\','/');
const local=(name:string)=>path.resolve(root,name);
const project=path.resolve(root,'../../..').replaceAll('\\','/');
const snapshot:Record<string,Uint8Array>={};
const replacements:Record<string,string>={
  [source+'/infrastructure/storage/records.ts']:local('repository.ts'),
  [source+'/hooks/useRoute.ts']:local('useRoute.ts'),
};
export default defineConfig({
  root,base:'./',publicDir:false,
  plugins:[{
    name:'bien-spi-grist-isolation',enforce:'pre',
    async resolveId(id,importer) {
      if(!importer || !id.startsWith('.'))return;
      const target=path.resolve(path.dirname(importer.split('?')[0]),id).replaceAll('\\','/');
      return replacements[target] || replacements[target+'.ts'];
    },
    transform(code,id) {
      if(!id.startsWith(source))return;
      code=code.replace(/\r\n/g,'\n');
      if(id.endsWith('/edlDefaults.js')) {
        const pattern=/export const PEPINIERES_DATA = \[[\s\S]*?\];/;
        if(!pattern.test(code))throw new Error('Référentiel privé non identifié : publication bloquée.');
        const reference=path.relative(path.dirname(id),local('reference.ts')).replaceAll('\\','/');
        return code.replace(pattern,`import { pepinieres } from '${reference}';\nexport const PEPINIERES_DATA = pepinieres;`);
      }
      if(id.endsWith('/SaveStatus.tsx'))return code.replace('Sauvegardé localement','Sauvegardé dans Grist');
      if(id.endsWith('/HomePage.tsx'))return code.replace(/\{!Capacitor\.isNativePlatform\(\) && <p>[\s\S]*?<\/p>\}/,'').replace(/<div className="bs-home-support">[\s\S]*?<\/div>/,'').replace(/import \{ SupportPanel \}[^;]+;/,'');
      if(id.endsWith('/AppHeader.tsx'))return code.replace(/import \{ SupportPanel \}[^;]+;/,'').replace('<SupportPanel />','').replace("window.location.pathname !== '/'","window.location.hash !== '#/'");
      if(id.endsWith('/EdlEntryPage.tsx')||id.endsWith('/DiaEntryPage.tsx')) {
        code=code.replace('navigate, queryValue','navigate, queryValue, replaceRoute').replace(/window.history.replaceState\(\{\}, '', (\x60[^\x60]+\x60)\)/g,'replaceRoute($1)');
        if(id.endsWith('/DiaEntryPage.tsx')) {
          code="import { createId } from '../../domain/shared/types';\n"+code;
          code=code.replace('useState(requestedId);',"useState(requestedId || createId('dia'));");
          code=code.replace("setRecordId('');",'');
          code=code.replace("if (!recordId) { const params", "{ const params");
          code=code.replace('const hydrated = useRef(false);', "const hydrated = useRef(false); const [ready,setReady]=useState(!requestedId); const [loadError,setLoadError]=useState('');");
          code=code.replace('if (record) { setDia', "if (!record || record.kind !== 'dia') { setLoadError('Dossier DIA introuvable.'); return; } if (record) { setDia");
          code=code.replace('hydrated.current = true; });', "hydrated.current = true; setReady(true); }).catch(()=>setLoadError('Impossible de charger le DIA. Réessayez avec une connexion.'));");
          code=code.replace("setSaveState('saving');\n    try", "if (!ready) return null; setSaveState('saving');\n    try");
          code=code.replace('[dia, recordId]);','[dia, recordId, ready]);');
          code=code.replace('if (!hydrated.current) return;', 'if (!ready || !hydrated.current) return;');
          code=code.replace('  return <>', "  if (!ready) return <main className=\"bs-page\">{loadError || 'Chargement du DIA…'}</main>;\n  return <>");
        }
        return code;
      }
    }
  },{
    name:'sanitized-source-snapshot',enforce:'pre',
    transform(code,id) {
      const file=id.split('?')[0].replaceAll('\\','/');
      if (file.startsWith(source+'/') && /\.(tsx?|jsx?|css)$/.test(file)) snapshot[file.slice(project.length+1)]=file.endsWith('/edlDefaults.js')?strToU8(readFileSync(file,'utf8').replace(/export const PEPINIERES_DATA = \[[\s\S]*?\];/,'export const PEPINIERES_DATA = [];')):new Uint8Array(readFileSync(file));
    },
    generateBundle() {
      this.emitFile({type:'asset',fileName:'grist-plugin-api.js',source:new Uint8Array(readFileSync(local('grist-plugin-api.js')))});
      snapshot['migration/grist/widget/grist-plugin-api.js']=new Uint8Array(readFileSync(local('grist-plugin-api.js')));
      for (const id of this.getModuleIds()) {
        const file=id.split('?')[0].replaceAll('\\','/');
        if(file.startsWith(source+'/assets/') && /\.(svg|ttf|woff2?|png)$/.test(file)) snapshot[file.slice(project.length+1)]=new Uint8Array(readFileSync(file));
      }
      for(const name of ['App.tsx','NativePhotoTrial.tsx','native-photos.mjs','native-photos.test.mjs','MediaDiagnostic.tsx','attachment-request.mjs','attachment-request.test.mjs','main.tsx','repository.ts','reference.ts','media.mjs','media.test.mjs','journal.mjs','journal.test.mjs','useRoute.ts','widget.css','index.html','vite.config.ts']) snapshot['migration/grist/widget/'+name]=new Uint8Array(readFileSync(local(name)));
      const pkg=JSON.parse(readFileSync(path.resolve(project,'package.json'),'utf8'));
      snapshot['package.json']=strToU8(JSON.stringify({name:'bien-spi-grist',version:'0.2.2',private:true,type:'module',scripts:{build:'vite build --config migration/grist/widget/vite.config.ts',test:'node --test migration/grist/widget/journal.test.mjs migration/grist/widget/media.test.mjs migration/grist/widget/attachment-request.test.mjs migration/grist/widget/native-photos.test.mjs'},dependencies:pkg.dependencies,devDependencies:pkg.devDependencies},null,2));
      snapshot['README.md']=strToU8('# Bien SPI — interface métier Grist\n\nSources sans référentiels internes. Installer Node.js, puis npm install, npm test, npm run build. Résultat : migration/grist/widget/dist. Héberger ce dossier statique sur Pages ou Forge, puis changer l’URL du widget Grist. Ne contient aucun dossier métier. Les référentiels sont lus depuis BienSpi_Referentiels et les images sont stockées comme pièces jointes natives dans BienSpi_Medias. Serveur autorisé pour les pièces jointes : grist.grandlyon.fr. Les formulaires EDL et DIA conservent leurs générateurs PDF. Effectuer une recette sur les tablettes utilisées avant généralisation.\n');
      this.emitFile({type:'asset',fileName:'bien-spi-grist-sources.zip',source:zipSync(snapshot)});
    }
  },react()],
  define:{__APP_VERSION__:JSON.stringify('grist-0.2.2'),__BUILD_DATE__:JSON.stringify(new Date().toISOString())},
  build:{outDir:local('dist'),emptyOutDir:true,sourcemap:false,target:'es2020',rollupOptions:{output:{assetFileNames:'[name]-[hash][extname]',chunkFileNames:'[name]-[hash].js',entryFileNames:'bien-spi-[hash].js'}}}
});
