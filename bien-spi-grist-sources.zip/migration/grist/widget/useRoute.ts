import { useEffect, useState } from 'react';
import { flushAllDrafts } from '../../../src/infrastructure/storage/flushRegistry';
let navigating=false;
function location() { const url=new URL(window.location.hash.slice(1) || '/', 'https://widget.invalid'); return {pathname:url.pathname,search:url.search}; }
export function replaceRoute(path:string) { window.history.replaceState({},'',window.location.pathname+window.location.search+'#'+path); }
export async function navigate(path:string) {
  if(navigating) return;
  navigating=true;
  try { await flushAllDrafts(); window.location.hash=path; window.scrollTo({top:0,behavior:'instant'}); }
  catch { window.alert('Sauvegarde non confirmée dans Grist. Restez sur ce formulaire et utilisez la copie de secours si nécessaire.'); }
  finally { navigating=false; }
}
export function useRoute() {
  const [route,setRoute]=useState(location);
  useEffect(()=>{const update=()=>setRoute(location());window.addEventListener('hashchange',update);return()=>window.removeEventListener('hashchange',update);},[]);
  return route;
}
export function queryValue(search:string,key:string) { return new URLSearchParams(search).get(key) || ''; }

