import {useState} from 'react';
import {createAttachmentRequest} from './attachment-request.mjs';
import {readNativePhotos, TRIAL_DOSSIERS, escapePhotoLegend} from './native-photos.mjs';
import {createVisit} from '../../../src/features/edl/edlVisit';
import {generateEdlPdf} from '../../../src/infrastructure/pdf/EdlPdfService';
import {MetropoleLogo} from '../../../src/components/MetropoleLogo';
type Photo={id:number;row:number;legende:string;src:string};
export function NativePhotoTrial(){
 const [dossier,setDossier]=useState(TRIAL_DOSSIERS[0]);
 const [photos,setPhotos]=useState<Photo[]>([]);
 const [busy,setBusy]=useState(false),[status,setStatus]=useState('Ajoutez une photo dans la vue native, puis lancez la vérification. Aucun dossier métier ne sera modifié.');
 async function read(){
   const request=createAttachmentRequest((options:{readOnly:boolean})=>window.grist.docApi.getAccessToken!(options));
   return await readNativePhotos(window.grist.docApi,(id:number)=>request(`/attachments/${id}/download`),dossier) as Photo[];
 }
 async function check(pdf=false){
   setBusy(true);setPhotos([]);setStatus('Lecture des photos enregistrées dans Grist…');
   try{
     const images=await read();
     if(!images.length)throw new Error('Aucune photo pour ce dossier d’essai. Ajoutez-la dans la colonne Photo de la vue native.');
     // Verify actual decoding, not only the file header, before the PDF renderer sees the image.
     for(const image of images)await new Promise<void>((resolve,reject)=>{const img=new Image();img.onload=()=>resolve();img.onerror=()=>reject(new Error('La photo téléchargée ne peut pas être affichée.'));img.src=image.src;});
     setPhotos(images);
     if(pdf){
       setStatus('Photos relues. Génération de l’EDL fictif…');
       const form=createVisit('appartement','entrant','ESSAI PHOTO');
       form.locataireNom='ESSAI PHOTO — NON CONTRACTUEL';
       form.adresseRue='DOSSIER FICTIF — '+dossier;
       form.photos=images.map(photo=>({src:photo.src,legende:escapePhotoLegend(photo.legende)}));
       const result=await generateEdlPdf(form);
       setStatus(`PDF d’essai généré : ${result.filename}. Vérifiez visuellement la présence des photos dans le fichier téléchargé.`);
     }else setStatus(`${images.length} photo(s) relue(s) et affichable(s). Aucun envoi depuis le widget et aucune écriture dans les dossiers métier.`);
   }catch(error){setStatus(error instanceof Error?error.message:'Lecture des photos impossible.');}
   finally{setBusy(false);}
 }
 return <main className="bs-page"><MetropoleLogo/><h1>Essai photos natives Grist</h1>
 <p>Utilisez uniquement des images fictives pour cet essai. Les signatures et les formulaires habituels sont inchangés.</p>
 <label>Dossier d’essai <select className="bs-button" disabled={busy} value={dossier} onChange={event=>{setDossier(event.target.value);setPhotos([]);setStatus('Dossier sélectionné. Lancez la vérification.');}}>{TRIAL_DOSSIERS.map(id=><option key={id}>{id}</option>)}</select></label>
 <p role="status">{status}</p><div style={{display:'flex',gap:12,flexWrap:'wrap'}}>
 <button className="bs-button" disabled={busy} onClick={()=>void check()}>Vérifier la lecture des photos</button>
 <button className="bs-button is-primary" disabled={busy} onClick={()=>void check(true)}>Créer le PDF d’essai avec photos</button></div>
 {photos.map(photo=><figure key={`${photo.row}-${photo.id}`}><img src={photo.src} alt={photo.legende||'Photo d’essai'} style={{maxWidth:'100%',maxHeight:280}}/><figcaption>{photo.legende}</figcaption></figure>)}
 </main>;
}
