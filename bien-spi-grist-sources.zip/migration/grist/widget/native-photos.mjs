// Read-only trial: native Grist performs uploads. This code never uploads or writes records.
export const NATIVE_PHOTO_TABLE = 'BienSpi_Photos_Essai';
export const TRIAL_DOSSIERS = ['EDL-ESSAI-PHOTOS', 'EDL-ESSAI-TABLETTE'];
export function nativePhotoRows(table, dossier) {
  if (!TRIAL_DOSSIERS.includes(dossier)) throw new Error('Dossier hors du périmètre d’essai.');
  if (!['id', 'Dossier_ID', 'Legende', 'Photo'].every(key => Array.isArray(table[key]) && table[key].length === table.id.length)) throw new Error('Structure de la table photo incompatible.');
  const photos = [];
  for (let i = 0; i < table.id.length; i++) {
    if (table.Dossier_ID[i] !== dossier) continue;
    const cell = table.Photo[i];
    if (cell == null || cell === '') continue;
    if (!Array.isArray(cell) || cell[0] !== 'L' || !cell.slice(1).every(id => Number.isSafeInteger(id) && id > 0)) throw new Error('Référence de photo invalide ou inaccessible.');
    for (const id of new Set(cell.slice(1))) photos.push({ id, row: table.id[i], legende: String(table.Legende[i] || '') });
  }
  if (photos.length > 10) throw new Error('Cet essai accepte au maximum dix photos par dossier.');
  return photos;
}
export function nativeImageDataUrl(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.length > 8 * 1024 * 1024) throw new Error('Photo trop volumineuse pour cet essai (8 Mo maximum).');
  const is = (offset, signature) => signature.every((value, i) => bytes[offset + i] === value);
  const mime = is(0, [137,80,78,71,13,10,26,10]) ? 'image/png'
    : is(0, [255,216,255]) ? 'image/jpeg'
    : bytes.length >= 12 && is(0, [82,73,70,70]) && is(8, [87,69,66,80]) ? 'image/webp' : '';
  if (!mime) throw new Error('Image non prise en charge : utiliser JPEG, PNG ou WebP.');
  let binary = '';
  for (let offset = 0; offset < bytes.length; offset += 8192) binary += String.fromCharCode(...bytes.subarray(offset, offset + 8192));
  return `data:${mime};base64,${btoa(binary)}`;
}
export async function readNativePhotos(api, download, dossier) {
  const refs = nativePhotoRows(await api.fetchTable(NATIVE_PHOTO_TABLE), dossier);
  const photos = [];
  for (const ref of refs) photos.push({ ...ref, src: nativeImageDataUrl(await download(ref.id)) });
  return photos;
}
export function escapePhotoLegend(value) {
  return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}
