import { createRepository, TABLE, columns } from './journal.mjs';
import type { StoredRecord, RecordKind, RecordStatus } from '../../../src/domain/shared/types';
type Api = { fetchTable:(id:string)=>Promise<any>; listTables:()=>Promise<string[]>; applyUserActions:(actions:any[])=>Promise<unknown> };
declare global { interface Window { grist: { docApi:Api; ready:(options:object)=>void; onOptions:(callback:(options:unknown,settings:{accessLevel?:string})=>void)=>void }; } }
let error = '';
const listeners = new Set<()=>void>();
export function message() { return error; }
export function subscribe(fn:()=>void) { listeners.add(fn); return ()=>{listeners.delete(fn);}; }
function notify(value:string) { error=value; listeners.forEach(fn=>fn()); }
const api:Api = {
  fetchTable: id=>window.grist.docApi.fetchTable(id),
  listTables: ()=>window.grist.docApi.listTables(),
  applyUserActions: actions=>window.grist.docApi.applyUserActions(actions)
};
const repository = createRepository(api,notify);
let initializing:Promise<void>|null=null;
export function initialize() {
  if (!initializing) initializing=initializeOnce().catch(error=>{initializing=null;throw error;});
  return initializing;
}
async function initializeOnce() {
  const tables = await api.listTables();
  if (!tables.includes(TABLE)) {
    await api.applyUserActions([['AddTable',TABLE,columns.map(id=>({id,type:['Revision','Schema_Version'].includes(id)?'Int':'Text'}))]]);
  }
  const table = await api.fetchTable(TABLE);
  if (!columns.every(id=>Array.isArray(table[id]))) throw new Error('Structure Grist incompatible. Aucun dossier existant n’a été modifié.');
}
export async function saveRecord<T>(input:{id?:string;kind:RecordKind;bienId?:string;payload:T;status?:RecordStatus;expectedRevision?:number}):Promise<StoredRecord<T>> {
  return repository.saveRecord(input) as Promise<StoredRecord<T>>;
}
export async function loadRecord<T>(id:string):Promise<StoredRecord<T>|null> { return repository.loadRecord(id); }
export async function listRecords<T>(kind:RecordKind,bienId?:string):Promise<StoredRecord<T>[]> { return repository.listRecords(kind,bienId); }
export const reopenRecord = repository.reopenRecord;
export const hasPending = repository.hasPending;
export function downloadEmergency() {
  const blob = new Blob([JSON.stringify({format:'bien-spi-grist-secours-v1',date:new Date().toISOString(),drafts:repository.emergency()},null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob), a=document.createElement('a');
  a.href=url; a.download='Bien-SPI-secours-'+new Date().toISOString().slice(0,10)+'.json'; a.click();
  setTimeout(()=>URL.revokeObjectURL(url),10000);
}
