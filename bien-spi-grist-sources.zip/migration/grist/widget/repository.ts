import { createRepository, TABLE, columns } from './journal.mjs';
import { createMediaStore, MEDIA_TABLE, mediaColumns } from './media.mjs';
import { REFERENCE_TABLE, loadReferences } from './reference';
import type { StoredRecord, RecordKind, RecordStatus } from '../../../src/domain/shared/types';
type Api = { fetchTable:(id:string)=>Promise<any>; listTables:()=>Promise<string[]>; applyUserActions:(actions:any[])=>Promise<unknown>; getAccessToken?:(options:{readOnly:boolean})=>Promise<{baseUrl:string;token:string}> };
declare global { interface Window { grist: { docApi:Api; ready:(options:object)=>void; onOptions:(callback:(options:unknown,settings:{accessLevel?:string})=>void)=>void }; } }
let error = '';
const listeners = new Set<()=>void>();
export function message() { return error; }
export function subscribe(fn:()=>void) { listeners.add(fn); return ()=>{listeners.delete(fn);}; }
function notify(value:string) { error=value; listeners.forEach(fn=>fn()); }
const api:Api = {
  fetchTable: id=>window.grist.docApi.fetchTable(id),
  listTables: ()=>window.grist.docApi.listTables(),
  applyUserActions: actions=>window.grist.docApi.applyUserActions(actions)
};
async function attachmentRequest(path:string,body?:FormData) {
  const grant=await window.grist.docApi.getAccessToken!({readOnly:!body});
  const base=new URL(grant.baseUrl);
  if(base.protocol!=='https:' || base.hostname!=='grist.grandlyon.fr')throw new Error('Serveur de pièces jointes non autorisé.');
  const url=new URL(base.href.replace(/\/$/,'')+path);
  url.searchParams.set('auth',grant.token);
  const controller=new AbortController(), timer=setTimeout(()=>controller.abort(),60000);
  try {
    const response=await fetch(url,{method:body?'POST':'GET',body,credentials:'omit',referrerPolicy:'no-referrer',signal:controller.signal});
    if(!response.ok)throw new Error(`Pièce jointe non transférée (HTTP ${response.status}). Réessayez avec une connexion.`);
    // Read the body before clearing the timeout.
    return body ? await response.json() : new Uint8Array(await response.arrayBuffer());
  } catch(error) {
    throw new Error(error instanceof Error && error.message.startsWith('Pièce jointe')?error.message:'Transfert de pièce jointe interrompu. Votre saisie reste ouverte ; réessayez ou téléchargez une copie de secours.');
  } finally {clearTimeout(timer);}
}
const media=createMediaStore({
  async list() {
    const table=await api.fetchTable(MEDIA_TABLE);
    return table.id.map((_:number,i:number)=>({hash:table.Empreinte[i],mime:table.Mime[i],id:table.Fichier[i]?.[1]})).filter((ref:any)=>ref.hash&&Number.isSafeInteger(ref.id));
  },
  async upload(bytes:Uint8Array,mime:string,hash:string) {
    const body=new FormData();body.append('upload',new Blob([bytes as BlobPart],{type:mime}),`${hash}.${mime.split('/')[1]}`);
    const ids=await attachmentRequest('/attachments',body);return ids[0];
  },
  async register(ref:{id:number;hash:string;mime:string}) {await api.applyUserActions([['AddRecord',MEDIA_TABLE,null,{Empreinte:ref.hash,Mime:ref.mime,Fichier:['L',ref.id]}]]);},
  async download(id:number) {return attachmentRequest(`/attachments/${id}/download`);}
});
const repository = createRepository(api,notify,{encodePayload:media.encode,decodePayload:media.hydrate});
let initializing:Promise<void>|null=null;
export function initialize() {
  if (!initializing) initializing=initializeOnce().catch(error=>{initializing=null;throw error;});
  return initializing;
}
async function initializeOnce() {
  const tables = await api.listTables();
  if (!tables.includes(TABLE)) {
    await api.applyUserActions([['AddTable',TABLE,columns.map(id=>({id,type:['Revision','Schema_Version'].includes(id)?'Int':'Text'}))]]);
  }
  if (!tables.includes(MEDIA_TABLE))await api.applyUserActions([['AddTable',MEDIA_TABLE,mediaColumns]]);
  if (!tables.includes(REFERENCE_TABLE))await api.applyUserActions([['AddTable',REFERENCE_TABLE,[{id:'Nom',type:'Text'},{id:'Donnees_JSON',type:'Text'}]]]);
  const table = await api.fetchTable(TABLE);
  if (!columns.every(id=>Array.isArray(table[id]))) throw new Error('Structure Grist incompatible. Aucun dossier existant n’a été modifié.');
  await loadReferences(api);
}
export async function saveRecord<T>(input:{id?:string;kind:RecordKind;bienId?:string;payload:T;status?:RecordStatus;expectedRevision?:number}):Promise<StoredRecord<T>> {
  return repository.saveRecord(input) as Promise<StoredRecord<T>>;
}
export async function loadRecord<T>(id:string):Promise<StoredRecord<T>|null> { return repository.loadRecord(id); }
export async function listRecords<T>(kind:RecordKind,bienId?:string):Promise<StoredRecord<T>[]> { return repository.listRecords(kind,bienId); }
export const reopenRecord = repository.reopenRecord;
export const hasPending = repository.hasPending;
export function downloadEmergency() {
  const blob = new Blob([JSON.stringify({format:'bien-spi-grist-secours-v1',date:new Date().toISOString(),drafts:repository.emergency()},null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob), a=document.createElement('a');
  a.href=url; a.download='Bien-SPI-secours-'+new Date().toISOString().slice(0,10)+'.json'; a.click();
  setTimeout(()=>URL.revokeObjectURL(url),10000);
}
