import test from 'node:test';
import assert from 'node:assert/strict';
import {createMediaStore} from './media.mjs';
import {createRepository,TABLE,columns} from './journal.mjs';
const photo='data:image/png;base64,aGVsbG8=';
function fixture(){
  const refs=[],files=new Map();let uploads=0;
  const transport={async list(){return refs;},async upload(bytes){files.set(++uploads,bytes);return uploads;},async register(ref){refs.push(ref);},async download(id){return files.get(id);}};
  return {transport,refs,files,uploads:()=>uploads};
}
test('photos et signatures imbriquées : aller-retour exact après recréation du lecteur',async()=>{
  const f=fixture(),a=createMediaStore(f.transport),payload={photos:[{src:photo,legende:'Essai'}],signature:photo,unknown:{keep:true}};
  const encoded=await a.encode(payload);assert.ok(!JSON.stringify(encoded).includes('base64'));assert.equal(f.uploads(),1);
  const b=createMediaStore(f.transport);assert.deepEqual(await b.hydrate(encoded),payload);
});
test('déduplication persistante entre sessions',async()=>{
  const f=fixture();await createMediaStore(f.transport).encode(photo);await createMediaStore(f.transport).encode(photo);assert.equal(f.uploads(),1);
});
test('intégrité vérifiée avant de rendre une image',async()=>{
  const f=fixture(),encoded=await createMediaStore(f.transport).encode(photo);f.files.set(1,new Uint8Array([0]));
  await assert.rejects(createMediaStore(f.transport).hydrate(encoded),/altérée/);
});
test('échec de transfert ne produit aucune référence sauvegardable',async()=>{
  const f=fixture();f.transport.upload=async()=>{throw new Error('réseau');};
  await assert.rejects(createMediaStore(f.transport).encode(photo),/réseau/);assert.equal(f.refs.length,0);
});
test('formats et anciens dossiers sans pièces jointes conservés',async()=>{
  const f=fixture(),m=createMediaStore(f.transport),payload={value:'texte',old:photo,unknown:null};
  assert.deepEqual(await m.hydrate(payload),payload);assert.equal(f.uploads(),0);
});
test('image volumineuse : enveloppe compacte, sauvegarde et relecture intégrales',async()=>{
  const f=fixture(),media=createMediaStore(f.transport),rows=[];
  const api={async fetchTable(){return Object.fromEntries(['id',...columns].map(k=>[k,rows.map(r=>r[k])]));},async applyUserActions(actions){for(const [,table,,fields]of actions){assert.equal(table,TABLE);rows.push({id:rows.length+1,...fields});}}};
  const repo=createRepository(api,()=>{},{encodePayload:media.encode,decodePayload:media.hydrate});
  const payload={photos:['data:image/jpeg;base64,'+'AAAA'.repeat(1_100_000)]};
  await repo.saveRecord({id:'edl-photo',kind:'edl',payload});assert.ok(rows[0].Enveloppe_JSON.length<1000);
  assert.deepEqual((await repo.loadRecord('edl-photo')).payload,payload);
  await repo.saveRecord({id:'edl-photo',kind:'edl',payload});assert.equal(rows.length,1);
});
