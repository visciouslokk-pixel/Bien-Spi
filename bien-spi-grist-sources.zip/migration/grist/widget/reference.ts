export const REFERENCE_TABLE='BienSpi_Referentiels';
// Filled only from the private Grist document, never from public build assets.
export const pepinieres:any[]=[];
export async function loadReferences(api:any) {
  const data=await api.fetchTable(REFERENCE_TABLE);
  const parsed=(data.Donnees_JSON || []).filter(Boolean).map((json:string)=>JSON.parse(json));
  for(const item of parsed) {
    if(!item || typeof item.id!=='string' || typeof item.label!=='string' || !Array.isArray(item.bureaux) || !Array.isArray(item.ateliers))throw new Error('Référentiel LYVE invalide. Vérifiez la table BienSpi_Referentiels.');
  }
  if(new Set(parsed.map((item:any)=>item.id)).size!==parsed.length)throw new Error('Une pépinière est présente deux fois dans le référentiel LYVE.');
  pepinieres.splice(0,pepinieres.length,...parsed);
}
