import {useState} from 'react';
import {verifyMediaTransfer} from './repository';
export function MediaDiagnostic(){
 const [status,setStatus]=useState('Ce contrôle ajoute uniquement une petite image portant TEST BIEN SPI dans les médias du document. Aucun dossier existant n’est modifié.');
 const [busy,setBusy]=useState(false);
 return <main className="bs-page"><h1>Contrôle du transfert des images</h1><p role="status">{status}</p><button className="bs-button" disabled={busy} onClick={async()=>{setBusy(true);setStatus('Envoi puis relecture depuis Grist…');try{setStatus(await verifyMediaTransfer());}catch(error){setStatus(error instanceof Error?error.message:'Échec du transfert');}finally{setBusy(false);}}}>Tester le transfert et la relecture</button></main>;
}
