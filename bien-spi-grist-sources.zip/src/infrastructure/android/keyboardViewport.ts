const TEXT_INPUT_TYPES = new Set([
  'date',
  'datetime-local',
  'email',
  'month',
  'number',
  'password',
  'search',
  'tel',
  'text',
  'time',
  'url',
  'week',
]);

export function isTextEntryElement(target: EventTarget | null): target is HTMLElement {
  if (target instanceof HTMLTextAreaElement) return true;
  if (target instanceof HTMLInputElement) return TEXT_INPUT_TYPES.has(target.type);
  return target instanceof HTMLElement && target.isContentEditable;
}

export function installKeyboardViewportGuard(
  documentRef: Document = document,
  windowRef: Window = window,
) {
  let blurTimer = 0;
  const revealTimers = new Set<number>();

  const clearRevealTimers = () => {
    for (const timer of revealTimers) windowRef.clearTimeout(timer);
    revealTimers.clear();
  };

  const reveal = (element: HTMLElement) => {
    const viewportHeight = windowRef.visualViewport?.height ?? windowRef.innerHeight;
    const rectangle = element.getBoundingClientRect();
    const margin = 20;
    if (rectangle.top < margin || rectangle.bottom > viewportHeight - margin) {
      element.scrollIntoView({ block: 'center', inline: 'nearest' });
    }
  };

  const scheduleReveal = (element: HTMLElement) => {
    clearRevealTimers();
    for (const delay of [80, 320]) {
      const timer = windowRef.setTimeout(() => {
        revealTimers.delete(timer);
        if (documentRef.activeElement === element) reveal(element);
      }, delay);
      revealTimers.add(timer);
    }
  };

  const onFocusIn = (event: FocusEvent) => {
    if (!isTextEntryElement(event.target)) return;
    windowRef.clearTimeout(blurTimer);
    documentRef.documentElement.classList.add('bs-text-entry-active');
    scheduleReveal(event.target);
  };

  const onFocusOut = () => {
    windowRef.clearTimeout(blurTimer);
    blurTimer = windowRef.setTimeout(() => {
      if (!isTextEntryElement(documentRef.activeElement)) {
        documentRef.documentElement.classList.remove('bs-text-entry-active');
        clearRevealTimers();
      }
    }, 80);
  };

  const onViewportResize = () => {
    const activeElement = documentRef.activeElement;
    if (isTextEntryElement(activeElement)) scheduleReveal(activeElement);
  };

  documentRef.addEventListener('focusin', onFocusIn);
  documentRef.addEventListener('focusout', onFocusOut);
  windowRef.visualViewport?.addEventListener('resize', onViewportResize);

  return () => {
    documentRef.removeEventListener('focusin', onFocusIn);
    documentRef.removeEventListener('focusout', onFocusOut);
    windowRef.visualViewport?.removeEventListener('resize', onViewportResize);
    windowRef.clearTimeout(blurTimer);
    clearRevealTimers();
    documentRef.documentElement.classList.remove('bs-text-entry-active');
  };
}
