const MAX_INPUT_BYTES = 25 * 1024 * 1024;
let queue: Promise<unknown> = Promise.resolve();

/** Decode and resize one image at a time to limit concurrent memory use on tablets. */
export function compressImage(file: Blob, maxSide = 1600, quality = 0.82): Promise<{ blob: Blob; width: number; height: number }> {
  const job = queue.catch(() => {}).then(async () => {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('Photo non prise en charge : utilisez JPEG, PNG ou WebP.');
    if (!file.size || file.size > MAX_INPUT_BYTES) throw new Error('Photo vide ou trop volumineuse (limite 25 Mo).');
    const url = URL.createObjectURL(file);
    const image = new Image();
    const canvas = document.createElement('canvas');
    try {
      await new Promise<void>((resolve, reject) => {
        image.onload = () => resolve(); image.onerror = () => reject(new Error('Photo illisible.'));
        image.src = url;
      });
      if (!image.naturalWidth || !image.naturalHeight) throw new Error('Dimensions de photo invalides.');
      const scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
      const width = Math.max(1, Math.round(image.naturalWidth * scale));
      const height = Math.max(1, Math.round(image.naturalHeight * scale));
      canvas.width = width; canvas.height = height;
      const context = canvas.getContext('2d');
      if (!context) throw new Error('Compression indisponible sur ce navigateur.');
      context.fillStyle = '#fff'; context.fillRect(0, 0, width, height);
      context.drawImage(image, 0, 0, width, height);
      const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error('Compression impossible.')), 'image/jpeg', quality));
      if (blob.size > 2 * 1024 * 1024) throw new Error('Photo encore trop volumineuse après compression. Choisissez une image moins détaillée.');
      return { blob, width, height };
    } finally { URL.revokeObjectURL(url); image.src = ''; canvas.width = 0; canvas.height = 0; }
  });
  queue = job;
  return job;
}

export async function compressedPhotoDataUrl(file: Blob, maxSide = 1600, quality = 0.82): Promise<string> {
  const { blob } = await compressImage(file, maxSide, quality);
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Lecture de la photo compressée impossible.'));
    reader.readAsDataURL(blob);
  });
}
