// Adaptateur volontairement minimal : le générateur ERP reste inchangé dans legacy/.
export { genererPDF } from '../../../features/dia/legacy/pdfService.js';
