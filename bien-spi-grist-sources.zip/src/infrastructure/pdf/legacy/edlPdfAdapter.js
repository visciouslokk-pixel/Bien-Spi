// Adaptateur volontairement minimal : le générateur validé reste inchangé dans legacy/.
export { exportEDLPDF } from '../../../features/edl/legacy/utils/edlPDF.js';
