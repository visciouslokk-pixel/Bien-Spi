import type { jsPDF } from 'jspdf';
import logoDataUrl from '../../assets/metropole-lyon.png?inline';

// Reserve a genuine footer before pagination, keeping the body centred and unscaled.
export const PDF_DOCUMENT_MARGINS: [number, number, number, number] = [12, 12, 48, 12];
export const PDF_LOGO_HEIGHT_MM = 12;
const branded = new WeakSet<jsPDF>();

export function applyMetropoleBranding(pdf: jsPDF) {
  if (branded.has(pdf)) return;
  const initialPage = pdf.getCurrentPageInfo().pageNumber;
  for (let page = 1; page <= pdf.getNumberOfPages(); page += 1) {
    pdf.setPage(page);
    const width = pdf.internal.pageSize.getWidth();
    const height = pdf.internal.pageSize.getHeight();

    // Notice V2, pp. 7/9/12: at least 6 mm high before rotation,
    // 90 degrees counterclockwise, original proportions and clear space.
    const logoHeight = PDF_LOGO_HEIGHT_MM;
    const logoWidth = logoHeight * 803 / 281;
    pdf.addImage(logoDataUrl, 'PNG', width - 12, height - 10 - logoHeight,
      logoWidth, logoHeight, 'metropole-lyon', 'FAST', 90);
    // Rasterise only the small footer with the already loaded Roboto font, just
    // like the document body. No system-font substitution in offline Android.
    const footerWidth = width - 42;
    const footer = document.createElement('canvas'); footer.width = Math.round(footerWidth * 8); footer.height = 48;
    const context = footer.getContext('2d');
    if (context) {
      context.fillStyle = '#ffffff'; context.fillRect(0, 0, footer.width, 48);
      context.strokeStyle = '#dfe1e6'; context.beginPath(); context.moveTo(0, 1); context.lineTo(footer.width, 1); context.stroke();
      context.fillStyle = '#4f5561'; context.font = '20px Roboto';
      context.fillText('Bien SPI · Métropole de Lyon', 0, 34);
      context.textAlign = 'right'; context.fillText(`Page ${page} / ${pdf.getNumberOfPages()}`, footer.width - 2, 34);
      pdf.addImage(footer.toDataURL('image/png'), 'PNG', 12, height - 16, footerWidth, 6);
    }
  }
  pdf.setPage(initialPage);
  branded.add(pdf);
}
