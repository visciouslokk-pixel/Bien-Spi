import themeCss from './documentTheme.css?inline';
import regularFont from '../../assets/fonts/Roboto-Regular.ttf?inline';
import mediumFont from '../../assets/fonts/Roboto-Medium.ttf?inline';
import boldFont from '../../assets/fonts/Roboto-Bold.ttf?inline';

const embeddedFonts = [[400, regularFont], [500, mediumFont], [700, boldFont]].map(([weight, source]) =>
  `@font-face {font-family:Roboto;font-style:normal;font-weight:${weight};src:url("${source}") format("truetype");}`).join('\n');

/** Legacy EDL styles must never leak onto the application during export. */
export function scopeLegacyPdfCss(css: string) {
  return css.replace(/@page\s*\{[^}]*\}/g, '').replace(/([^{}]+)\{([^{}]*)\}/g, (_rule, selectors: string, declarations: string) =>
    `${selectors.split(',').map((selector) => selector.trim() === 'body' ? '.bs-pdf-document' : `.bs-pdf-document ${selector.trim()}`).join(',')} {${declarations}}`);
}

export async function preparePdfDocument(container: HTMLElement, kind: string) {
  container.classList.add('bs-pdf-document');
  container.style.fontFamily = 'var(--font-body)';
  container.style.lineHeight = '1.3';
  // html2canvas's about:blank clone may not be controlled by the PWA worker.
  // Copy the shared tokens and inline font bytes: PDF styling must not depend
  // on linked stylesheets being fetched again inside that offline iframe.
  const tokens = getComputedStyle(document.documentElement);
  for (const name of ['--font-body', '--ds-red', '--ds-red-strong', '--ds-red-soft', '--ds-ink', '--ds-muted', '--ds-line', '--ds-background', '--ds-white']) {
    container.style.setProperty(name, tokens.getPropertyValue(name));
  }
  if (kind === 'FICHE BIEN') {
    // html2pdf does not implement break-after:avoid. Keep each short section
    // together so its heading cannot be orphaned at the foot of a page.
    container.querySelectorAll('h2').forEach((heading) => {
      const section = document.createElement('section');
      section.style.breakInside = ['Photos', 'Historique local détaillé', 'Documents et dossiers liés'].includes(heading.textContent || '') ? 'auto' : 'avoid';
      heading.before(section); section.appendChild(heading);
      while (section.nextElementSibling && section.nextElementSibling.tagName !== 'H2') {
        section.appendChild(section.nextElementSibling);
      }
    });
  }
  // Replace decorative legacy fills only; preserve drawings, photos and evaluation states.
  container.querySelectorAll<HTMLElement>('div[style], td[style], th[style]').forEach((element) => {
    if (element.closest('svg') || element.classList.contains('bs-pdf-section-title')) return;
    const fill = element.style.backgroundColor;
    if (fill && !['white', 'transparent', 'rgb(255, 255, 255)'].includes(fill)) {
      element.style.setProperty('background', 'var(--ds-background)', 'important');
      element.style.setProperty('color', 'var(--ds-ink)', 'important');
    }
  });
  const style = document.createElement('style'); style.textContent = embeddedFonts + '\n' + themeCss; container.appendChild(style);
  const eyebrow = document.createElement('p'); eyebrow.className = 'bs-pdf-eyebrow';
  eyebrow.textContent = `BIEN SPI · MÉTROPOLE DE LYON · ${kind}`; container.prepend(eyebrow);
  // html2canvas must use the same bundled font in every export, including the first one offline.
  await Promise.all([400, 500, 700].map((weight) => document.fonts.load(`${weight} 16px Roboto`)));
  await document.fonts.ready;
  await Promise.all(Array.from(container.querySelectorAll('img')).map(async (img) => {
    if (img.complete && img.naturalWidth > 0) return;
    await img.decode();
  }));
}
