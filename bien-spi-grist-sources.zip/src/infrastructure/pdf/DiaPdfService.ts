import { migrateDia } from '../../domain/dia/diaMigration';
import { genererPDF } from './legacy/diaPdfAdapter.js';

export async function generateDiaPdf(payload: unknown, chantier: string) {
  return genererPDF({
    type: 'DIA',
    chantier,
    dateVisite: new Date().toISOString().slice(0, 10),
    dia: migrateDia(payload)
  });
}
