import { exportEDLPDF } from './legacy/edlPdfAdapter.js';
import { edlSchema } from '../../domain/edl/edl.schema';

export async function generateEdlPdf(payload: unknown) {
  return exportEDLPDF(edlSchema.parse(payload));
}
