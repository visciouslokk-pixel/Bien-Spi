type FlushOperation = () => Promise<unknown>;
const operations = new Set<FlushOperation>();

export function registerFlush(operation: FlushOperation) {
  operations.add(operation);
  return () => { operations.delete(operation); };
}

export async function flushAllDrafts() {
  const results = await Promise.allSettled([...operations].map((operation) => operation()));
  const failed = results.filter((result) => result.status === 'rejected' || result.value === null);
  if (failed.length) throw new Error(`${failed.length} brouillon(s) non sauvegardé(s).`);
}

export function registeredFlushCount() { return operations.size; }
