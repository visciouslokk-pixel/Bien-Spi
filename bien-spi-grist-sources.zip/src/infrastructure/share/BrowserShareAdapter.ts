import type { ShareCapability, ShareFile, ShareMessage, SharePort, ShareReceipt } from '../../domain/shared/integrationPorts';

export class BrowserShareAdapter implements SharePort {
  async capabilities(): Promise<ShareCapability[]> {
    const capabilities: ShareCapability[] = ['download', 'prepare-email'];
    if ('share' in navigator) capabilities.splice(1, 0, 'system-share');
    return capabilities;
  }

  async download(file: ShareFile): Promise<ShareReceipt> {
    const url = URL.createObjectURL(file.blob);
    const link = document.createElement('a');
    link.href = url; link.download = file.name;
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    return { channel: 'download', status: 'prepared' };
  }

  async share(file: ShareFile, message: ShareMessage): Promise<ShareReceipt> {
    if (!navigator.share) return this.download(file);
    const nativeFile = new File([file.blob], file.name, { type: file.type });
    if (navigator.canShare && !navigator.canShare({ files: [nativeFile] })) return this.download(file);
    try {
      await navigator.share({ title: message.title, text: message.text, files: [nativeFile] });
      return { channel: 'system-share', status: 'completed' };
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') return { channel: 'system-share', status: 'cancelled' };
      throw error;
    }
  }

  async prepareEmail(message: ShareMessage): Promise<ShareReceipt> {
    const query = new URLSearchParams({ subject: message.subject || message.title, body: message.text });
    window.location.href = `mailto:${encodeURIComponent(message.recipient || '')}?${query}`;
    return { channel: 'prepare-email', status: 'prepared' };
  }
}
