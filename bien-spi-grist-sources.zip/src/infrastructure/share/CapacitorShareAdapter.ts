import { Directory, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { registerPlugin } from '@capacitor/core';
import type { ShareCapability, ShareFile, ShareMessage, SharePort, ShareReceipt } from '../../domain/shared/integrationPorts';

interface NativeFilesystem {
  writeFile(options: {
    path: string;
    data: string;
    directory?: Directory;
    recursive?: boolean;
  }): Promise<{ uri: string }>;
}

interface NativeShare {
  share(options: {
    title?: string;
    text?: string;
    files?: string[];
    dialogTitle?: string;
  }): Promise<unknown>;
}

async function blobToBase64(blob: Blob): Promise<string> {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let binary = '';
  const chunkSize = 0x8000;
  for (let offset = 0; offset < bytes.length; offset += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
  }
  return btoa(binary);
}

interface DocumentExport {
  save(options: { uri: string; name: string; mimeType: string }): Promise<{ status: 'completed' | 'cancelled' }>;
}
const documentExport = registerPlugin<DocumentExport>('DocumentExport');

function safeFileName(name: string): string {
  const sanitized = name.replace(/[^a-zA-Z0-9._-]+/g, '_').replace(/^\.+/, '').slice(-120);
  return sanitized || 'document.pdf';
}

export class CapacitorShareAdapter implements SharePort {
  constructor(
    private readonly filesystem: NativeFilesystem = Filesystem,
    private readonly nativeShare: NativeShare = Share,
    private readonly now: () => number = Date.now,
    private readonly exporter: DocumentExport = documentExport,
  ) {}

  async capabilities(): Promise<ShareCapability[]> {
    return ['download', 'system-share'];
  }

  private async cache(file: ShareFile): Promise<string> {
    const result = await this.filesystem.writeFile({
      path: `bien-spi-share/${this.now()}-${safeFileName(file.name)}`,
      data: await blobToBase64(file.blob),
      directory: Directory.Cache,
      recursive: true,
    });
    return result.uri;
  }

  async download(file: ShareFile): Promise<ShareReceipt> {
    const uri = await this.cache(file);
    const result = await this.exporter.save({ uri, name: safeFileName(file.name), mimeType: file.type });
    return { channel: 'download', status: result.status };
  }

  async share(file: ShareFile, message: ShareMessage): Promise<ShareReceipt> {
    const uri = await this.cache(file);
    try { await this.nativeShare.share({
      title: message.subject || message.title,
      text: message.text,
      files: [uri],
      dialogTitle: 'Partager le document',
    }); } catch (error) {
      const message = error instanceof Error ? error.message : String((error as { message?: string })?.message || '');
      if (/share canceled|share cancelled|aborterror/i.test(message)) return { channel: 'system-share', status: 'cancelled' };
      throw error;
    }
    return { channel: 'system-share', status: 'completed' };
  }

  async prepareEmail(message: ShareMessage): Promise<ShareReceipt> {
    await this.nativeShare.share({
      title: message.subject || message.title,
      text: message.text,
      dialogTitle: 'Choisir une application',
    });
    return { channel: 'prepare-email', status: 'prepared' };
  }
}
