import { Capacitor } from '@capacitor/core';
import type { SharePort } from '../../domain/shared/integrationPorts';
import { BrowserShareAdapter } from './BrowserShareAdapter';
import { CapacitorShareAdapter } from './CapacitorShareAdapter';

export function createShareAdapter(nativePlatform = Capacitor.isNativePlatform()): SharePort {
  return nativePlatform ? new CapacitorShareAdapter() : new BrowserShareAdapter();
}
