import { Capacitor } from '@capacitor/core';
import type { ShareReceipt } from '../../domain/shared/integrationPorts';
import { BrowserShareAdapter } from './BrowserShareAdapter';

/** Preserve PC's one-click export; native destinations require an explicit user action. */
export async function deliverGeneratedPdf(filename: string, blob: Blob) {
  if (!Capacitor.isNativePlatform()) {
    await new BrowserShareAdapter().download({ name: filename, blob, type: 'application/pdf' });
  }
  return { filename, blob };
}

export function pdfReadyMessage() {
  return Capacitor.isNativePlatform()
    ? 'PDF prêt. Choisissez Enregistrer le PDF ou Partager.'
    : 'PDF prêt. Téléchargement déclenché : vérifiez les téléchargements du navigateur.';
}

export function deliveryMessage(receipt: ShareReceipt) {
  if (receipt.status === 'cancelled') return 'Opération annulée. Le document reste disponible ici.';
  if (receipt.channel === 'download') return receipt.status === 'completed'
    ? 'Fichier enregistré dans l’emplacement choisi.'
    : 'Téléchargement déclenché. Vérifiez que le fichier apparaît dans vos téléchargements.';
  if (receipt.channel === 'prepare-email') return 'Messagerie ouverte. Ajoutez la pièce jointe et vérifiez l’envoi dans votre messagerie.';
  return 'Document transmis au partage système. Vérifiez la pièce jointe et l’envoi dans l’application choisie.';
}
