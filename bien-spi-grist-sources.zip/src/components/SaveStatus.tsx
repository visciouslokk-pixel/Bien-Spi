import { CheckCircle2, LoaderCircle, TriangleAlert } from 'lucide-react';

export type SaveState = 'idle' | 'saving' | 'saved' | 'error';

export function SaveStatus({ state, detail }: { state: SaveState; detail?: string }) {
  const content = state === 'saving'
    ? { icon: <LoaderCircle className="spin" />, label: 'Sauvegarde…' }
    : state === 'error'
      ? { icon: <TriangleAlert />, label: detail || 'Échec de sauvegarde' }
      : { icon: <CheckCircle2 />, label: detail || (state === 'saved' ? 'Sauvegardé localement' : 'Prêt') };
  return <span className={`bs-save-state is-${state}`} role="status">{content.icon}{content.label}</span>;
}
