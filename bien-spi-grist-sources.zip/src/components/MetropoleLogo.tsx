import logoUrl from '../assets/metropole-lyon.svg';

export function MetropoleLogo({ className = '' }: { className?: string }) {
  return <img className={`bs-metropole-logo ${className}`} src={logoUrl} alt="Métropole de Lyon — Grand Lyon" width="803" height="281" />;
}
