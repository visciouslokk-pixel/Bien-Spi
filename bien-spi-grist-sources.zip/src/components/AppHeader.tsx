import { ArrowLeft, Home, Wifi, WifiOff } from 'lucide-react';
import { useNetworkStatus } from '../hooks/useNetworkStatus';
import { navigate } from '../hooks/useRoute';
import { MetropoleLogo } from './MetropoleLogo';
import { SupportPanel } from '../features/settings/SupportPanel';

export function AppHeader({ title, backTo = '/', compact = false, beforeNavigate }: { title: string; backTo?: string; compact?: boolean; beforeNavigate?: () => Promise<boolean> }) {
  const online = useNetworkStatus();
  const leave = async (path: string) => { if (!beforeNavigate || await beforeNavigate()) navigate(path); };
  return (
    <header className={`bs-header${compact ? ' bs-header--compact' : ''}`}>
      {window.location.pathname !== '/' && (
        <button className="bs-icon-button" type="button" onClick={() => void leave(backTo)} aria-label="Retour">
          <ArrowLeft aria-hidden="true" />
        </button>
      )}
      <button className="bs-brand" type="button" onClick={() => void leave('/')} aria-label="Accueil Bien SPI">
        <Home aria-hidden="true" />
        <span><strong>Bien SPI</strong><small>{title}</small></span>
      </button>
      <MetropoleLogo />
      <SupportPanel />
      <span className={`bs-network ${online ? 'is-online' : 'is-offline'}`} role="status">
        {online ? <Wifi aria-hidden="true" /> : <WifiOff aria-hidden="true" />}
        {online ? 'En ligne' : 'Hors ligne'}
      </span>
    </header>
  );
}
