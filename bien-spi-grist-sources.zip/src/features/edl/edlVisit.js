import { createDefaultForm } from './legacy/localModel';
import { newPiece, newJardinPiece, isPepiniere } from './legacy/utils/edlDefaults';

export const isSingleVisit = (form) => form.edlLayout === 'single-v1';
export const visitMode = (form) => ['sortant', 'sortie'].includes(form.typeEDL) ? 'sortant' : 'entrant';
export const visitLabel = (form) => isSingleVisit(form) ? (visitMode(form) === 'entrant' ? 'Entrant' : 'Sortant') : 'Historique / comparatif';

// Only explicit phase suffixes are considered, not e.g. the LYVE entrance door portEntree.
export function fieldVisit(name) {
  if (/Sortant|Sortie|IdxS$/.test(name)) return 'sortant';
  if (/Entrant|Entree|IdxE$/.test(name)) return 'entrant';
  return null;
}

export function createVisit(type, mode, agent = 'Agent SPI') {
  if (!['entrant', 'sortant'].includes(mode)) throw new Error('Mode EDL invalide');
  return {
    ...structuredClone(createDefaultForm(type, agent)),
    edlLayout: 'single-v1',
    typeEDL: isPepiniere(type) ? (mode === 'entrant' ? 'entree' : 'sortie') : mode,
    dateEDL: new Date().toISOString().slice(0, 10),
  };
}

// Whitelist: an exit is a new inspection, never a copy of recorded findings.
const IDENTITY_FIELDS = [
  'lotBatiment', 'ug', 'commune', 'adresseRue', 'immeuble', 'allee', 'etage', 'porte', 'copro',
  'habitatType', 'nbPieces', 'nbChambres', 'surface', 'usageLocal', 'referencesCadastrales',
  'parcelle', 'garageNum', 'caveNum', 'grenierNum', 'parkingNum', 'surfaceTerrain',
  'identifiantBien', 'adresseBien', 'cpBien', 'villeBien',
  'pepiniereId', 'localNumero', 'localSurface', 'localBoxNumero',
  'locataireNom', 'locatairePrenom', 'locataireSociete', 'locataireSiren', 'locataireFonction',
  'locataireTelephone', 'locataireEmail', 'locataireAdresse', 'locataireVille', 'locataireCp', 'locataireTel', 'locatairePort',
  'locRaisonSociale', 'locNom', 'locPrenom', 'locFonction', 'locAdresse', 'locVille', 'locCp', 'locTel', 'locPort',
  'locEntreprise', 'locSiren', 'locRepresentant',
  'eauChaudeNum', 'eauFroideNum', 'electNum', 'gazNum',
  'compteurChauffageNum', 'compteurEauNum', 'compteurElecNum',
];

export function prepareExit(source, sourceId) {
  if (!isSingleVisit(source) || visitMode(source) !== 'entrant') throw new Error('Une entrée dédiée est requise');
  const result = createVisit(source.typeBien, 'sortant');
  for (const key of IDENTITY_FIELDS) {
    if (source[key] !== undefined) result[key] = structuredClone(source[key]);
  }
  result.sourceEntryId = sourceId;
  result.pieces = (source.pieces || []).map((piece) => piece.pieceType === 'jardin' ? newJardinPiece(piece.nom) : newPiece(piece.nom));
  result.cles = (source.cles || []).map((key) => ({ libelle: key.libelle, nombre: '', etat: '' }));
  return result;
}
