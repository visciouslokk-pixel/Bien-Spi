// Annotations belong to the legacy templates; projection only affects explicit single visits.
export function projectVisitHtml(html, mode) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll('[data-edl-mode]').forEach((element) => {
    if (element.dataset.edlMode !== mode) element.remove();
    else if (element.matches('td, th')) element.style.removeProperty('width');
  });
  // Each room already has its own title; the redundant phase column is unnecessary.
  doc.querySelectorAll('[data-edl-phase-label]').forEach((element) => element.remove());
  doc.querySelectorAll('table').forEach((table) => {
    const hasRooms = Boolean(table.querySelector('.piece-group'));
    table.querySelectorAll('[colspan]').forEach((cell) => {
      if (hasRooms && cell.colSpan === 7) cell.colSpan = 6;
      else if (!hasRooms && cell.colSpan === 3 && table.querySelector('[data-edl-mode]')) cell.colSpan = 2;
    });
  });
  const title = doc.querySelector('h1');
  if (title && !/ENTRANT|SORTANT|ENTRÉE|SORTIE/.test(title.textContent)) {
    title.textContent += mode === 'entrant' ? ' — ENTRANT' : ' — SORTANT';
  }
  return '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
}
