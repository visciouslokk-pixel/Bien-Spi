import { migrateLegacyEdl, type EdlPayload } from '../../domain/edl/edl.schema';

export interface LegacyEdlImportPreview {
  payload: EdlPayload;
  inlineMediaCount: number;
  warnings: string[];
}

export function inspectLegacyEdlJson(text: string): LegacyEdlImportPreview {
  const parsed = JSON.parse(text) as unknown;
  const payload = migrateLegacyEdl(parsed);
  const serialized = JSON.stringify(payload);
  const inlineMediaCount = (serialized.match(/data:image\//g) ?? []).length;
  return {
    payload,
    inlineMediaCount,
    warnings: inlineMediaCount ? ['Les médias intégrés seront conservés pendant la conversion.'] : []
  };
}
