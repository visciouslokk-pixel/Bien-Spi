interface PdfPages { getNumberOfPages(): number; deletePage(page: number): unknown }

/** html2pdf can round bottom whitespace onto a final blank page. Never remove ink. */
export function trimEmptyPdfPages(pdf: PdfPages, canvas: HTMLCanvasElement, innerRatio: number) {
  const height = Math.floor(canvas.width * innerRatio);
  if (!height || Math.ceil(canvas.height / height) !== pdf.getNumberOfPages()) return;
  try {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    while (pdf.getNumberOfPages() > 1) {
      const page = pdf.getNumberOfPages();
      const top = (page - 1) * height;
      const pixels = ctx.getImageData(0, top, canvas.width, Math.min(height, canvas.height - top)).data;
      for (let i = 0; i < pixels.length; i += 4) {
        if (pixels[i + 3] !== 0 && (pixels[i] !== 255 || pixels[i + 1] !== 255 || pixels[i + 2] !== 255)) return;
      }
      pdf.deletePage(page);
    }
  } catch { /* Unreadable canvas: keep every page rather than risk removing content. */ }
}
