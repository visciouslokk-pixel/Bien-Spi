import { Building2, BriefcaseBusiness, Factory, Home, Map, Warehouse } from 'lucide-react';
import { AppHeader } from '../../components/AppHeader';
import { navigate, queryValue } from '../../hooks/useRoute';

export const EDL_TYPES = [
  { key: 'appartement', label: 'Appartement', icon: Building2 },
  { key: 'maison', label: 'Maison', icon: Home },
  { key: 'terrain', label: 'Terrain', icon: Map },
  { key: 'entrepot', label: 'Local', icon: Warehouse },
  { key: 'pepiniere_atelier', label: 'Atelier LYVE', icon: Factory },
  { key: 'pepiniere_bureau', label: 'Bureau LYVE', icon: BriefcaseBusiness }
] as const;

export function EdlTypePage({ search }: { search: string }) {
  const bienId = queryValue(search, 'bienId');
  return (
    <>
      <AppHeader title="Choisir un EDL" />
      <main className="bs-page bs-edl-choice">
        <div className="bs-page-title"><p>État des lieux</p><h1>Quel type de bien&nbsp;?</h1></div>
        <section className="bs-choice-grid">
          {EDL_TYPES.map(({ key, label, icon: Icon }) => (
            <button key={key} type="button" className="bs-choice-card" onClick={() => navigate(`/edl/mode/${key}${bienId ? `?bienId=${encodeURIComponent(bienId)}` : ''}`)}>
              <Icon aria-hidden="true" /><strong>{label}</strong><span>Choisir Entrant ou Sortant</span>
            </button>
          ))}
        </section>
      </main>
    </>
  );
}
