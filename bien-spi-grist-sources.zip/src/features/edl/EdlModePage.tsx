import { LogIn, LogOut } from 'lucide-react';
import { AppHeader } from '../../components/AppHeader';
import { navigate, queryValue } from '../../hooks/useRoute';
import { typeLabel } from './legacy/localModel';

export function EdlModePage({ type, search }: { type: string; search: string }) {
  const bienId = queryValue(search, 'bienId');
  const open = (mode: string) => navigate(`/edl/new/${type}?${new URLSearchParams({ mode, ...(bienId ? { bienId } : {}) })}`);
  return <>
    <AppHeader title={`EDL · ${typeLabel(type)}`} backTo={`/edl${bienId ? `?bienId=${encodeURIComponent(bienId)}` : ''}`} />
    <main className="bs-page bs-edl-choice">
      <div className="bs-page-title"><p>{typeLabel(type)}</p><h1>Entrée ou sortie ?</h1></div>
      <section className="bs-choice-grid bs-visit-choices" aria-label="Type de visite">
        <button className="bs-choice-card" type="button" onClick={() => open('entrant')}><LogIn aria-hidden="true" /><strong>Entrant</strong><span>État des lieux d’entrée</span></button>
        <button className="bs-choice-card" type="button" onClick={() => open('sortant')}><LogOut aria-hidden="true" /><strong>Sortant</strong><span>État des lieux de sortie</span></button>
      </section>
      <p>Chaque visite dispose de son formulaire et de son PDF dédiés.</p>
    </main>
  </>;
}
