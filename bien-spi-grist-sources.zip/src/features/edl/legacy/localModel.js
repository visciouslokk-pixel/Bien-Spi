import { getInitialByType } from './utils/edlDefaults.js';

export const EDL_TYPE_FILTERS = [
  { value: 'tous', label: 'Tous' },
  { value: 'appartement', label: 'Appartement' },
  { value: 'maison', label: 'Maison' },
  { value: 'entrepot', label: 'Local' },
  { value: 'terrain', label: 'Terrain' },
  { value: 'pepiniere_bureau', label: 'Bureau LYVE' },
  { value: 'pepiniere_atelier', label: 'Atelier LYVE' },
];

export function createDefaultForm(typeBien = 'appartement', agentName = '') {
  const base = getInitialByType(typeBien, agentName);
  return {
    ...base,
    typeBien,
    dateEDL: base.dateEDL || new Date().toISOString().split('T')[0],
    pieces: Array.isArray(base.pieces) ? base.pieces.map((piece) => ({ ...piece })) : [],
    cles: Array.isArray(base.cles) ? base.cles.map((cle) => ({ ...cle })) : [],
    photos: Array.isArray(base.photos) ? [...base.photos] : [],
    partageAvec: [],
  };
}

export function typeLabel(typeBien) {
  return EDL_TYPE_FILTERS.find((item) => item.value === typeBien)?.label || typeBien || 'EDL';
}

export function occupantName(edl) {
  if (edl.typeBien === 'terrain') {
    return [edl.locPrenom, edl.locNom].filter(Boolean).join(' ') || edl.locRaisonSociale || 'Occupant non renseigne';
  }
  if (edl.typeBien === 'pepiniere_bureau' || edl.typeBien === 'pepiniere_atelier') {
    return edl.locEntreprise || edl.locRepresentant || 'Entreprise non renseignee';
  }
  return [edl.locatairePrenom, edl.locataireNom].filter(Boolean).join(' ') || edl.locataireSociete || 'Occupant non renseigne';
}

export function edlAddress(edl) {
  if (edl.typeBien === 'terrain') {
    return [edl.adresseBien, edl.cpBien, edl.villeBien].filter(Boolean).join(', ') || edl.parcelle || 'Terrain non renseigne';
  }
  if (edl.typeBien === 'pepiniere_bureau' || edl.typeBien === 'pepiniere_atelier') {
    return [edl.pepiniereId, edl.localNumero ? `Local ${edl.localNumero}` : ''].filter(Boolean).join(' - ') || 'Pole LYVE';
  }
  return [edl.adresseRue, edl.commune].filter(Boolean).join(', ') || 'Adresse non renseignee';
}

export function normalizeForStorage(form, agentName = '') {
  return {
    ...form,
    creePar: form.creePar || agentName,
    dateEDL: form.dateEDL || new Date().toISOString().split('T')[0],
    pieces: Array.isArray(form.pieces) ? form.pieces : [],
    cles: Array.isArray(form.cles) ? form.cles : [],
    photos: Array.isArray(form.photos) ? form.photos : [],
  };
}

export function searchableText(edl) {
  return [
    typeLabel(edl.typeBien),
    edl.typeEDL,
    occupantName(edl),
    edlAddress(edl),
    edl.locataireEmail,
    edl.locataireTelephone,
    edl.nouvelleAdressePostale,
    edl.locSiren,
    edl.locataireSiren,
    edl.pieces?.map((piece) => `${piece.nom} ${piece.observations || ''} ${piece.entrant?.notes || ''} ${piece.sortant?.notes || ''} ${piece.entrant?.equipements?.observations || ''} ${piece.sortant?.equipements?.observations || ''}`).join(' '),
  ].join(' ').toLowerCase();
}
