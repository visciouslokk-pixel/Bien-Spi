// src/features/edl/components/SignaturePad.jsx
// Composant signature tactile — popup modale avec canvas plein écran mobile
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { X, RotateCcw, Check } from 'lucide-react';

// ── Styles ──────────────────────────────────────────────────────────────────
const overlay = {
  position: 'fixed', inset: 0, zIndex: 9999,
  background: 'rgba(0,0,0,0.6)', display: 'flex',
  alignItems: 'center', justifyContent: 'center',
  padding: '12px',
};
const modal = {
  background: '#fff', borderRadius: '16px', width: '100%', maxWidth: '520px',
  display: 'flex', flexDirection: 'column', overflow: 'hidden',
  boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
};
const header = {
  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
  padding: '14px 16px', borderBottom: '1px solid #e2e8f0',
};
const headerTitle = { fontSize: '15px', fontWeight: '700', color: '#1e293b' };
const canvasWrap = {
  position: 'relative', margin: '12px', border: '2px dashed #cbd5e1',
  borderRadius: '12px', overflow: 'hidden', background: '#fafbfc',
  touchAction: 'none',  // empêcher le scroll mobile pendant la signature
};
const hintText = {
  position: 'absolute', top: '50%', left: '50%',
  transform: 'translate(-50%,-50%)', fontSize: '15px',
  color: '#94a3b8', pointerEvents: 'none', userSelect: 'none',
  textAlign: 'center', lineHeight: '1.4',
};
const footer = {
  display: 'flex', gap: '10px', padding: '12px 16px',
  borderTop: '1px solid #e2e8f0', justifyContent: 'flex-end',
};
const btnBase = {
  padding: '12px 20px', borderRadius: '10px', fontWeight: '700',
  fontSize: '14px', border: 'none', cursor: 'pointer',
  display: 'flex', alignItems: 'center', gap: '6px',
  transition: 'all 0.15s',
};

// ── Bouton de signature (affiché dans le formulaire) ────────────────────────
function SignatureButton({ label, signatureData, onOpen, onClear }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
      <div style={{
        fontSize: '11px', fontWeight: '700', color: 'var(--text-muted, #64748b)',
        textTransform: 'uppercase', letterSpacing: '0.04em',
      }}>{label}</div>

      {signatureData ? (
        <div style={{
          border: '2px solid #2563eb', borderRadius: '10px', padding: '8px',
          background: '#f8fafc', position: 'relative',
        }}>
          <img
            src={signatureData}
            alt="Signature"
            style={{ width: '100%', height: '60px', objectFit: 'contain' }}
          />
          <div style={{ display: 'flex', gap: '8px', marginTop: '6px' }}>
            <button type="button" onClick={onOpen}
              style={{
                ...btnBase, flex: 1, padding: '8px', fontSize: '12px',
                background: '#dbeafe', color: '#1d4ed8',
              }}>
              Modifier
            </button>
            <button type="button" onClick={onClear}
              style={{
                ...btnBase, flex: 1, padding: '8px', fontSize: '12px',
                background: '#fee2e2', color: '#dc2626',
              }}>
              Supprimer
            </button>
          </div>
        </div>
      ) : (
        <button type="button" onClick={onOpen}
          style={{
            width: '100%', padding: '18px 12px', borderRadius: '10px',
            border: '2px dashed #94a3b8', background: '#f8fafc',
            cursor: 'pointer', fontSize: '14px', fontWeight: '600',
            color: '#64748b', display: 'flex', alignItems: 'center',
            justifyContent: 'center', gap: '8px', transition: 'all 0.15s',
          }}>
          ✍️ Signer
        </button>
      )}
    </div>
  );
}

// ── Modale de signature (canvas tactile) ────────────────────────────────────
function SignatureModal({ title, onConfirm, onClose, initialData }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const lastPoint = useRef(null);

  // Canvas height adapté mobile : assez grand pour signer au doigt
  const CANVAS_HEIGHT = 220;

  // ── Init canvas ─────────────────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = CANVAS_HEIGHT * dpr;
    canvas.style.width = rect.width + 'px';
    canvas.style.height = CANVAS_HEIGHT + 'px';

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#1e293b';

    // Recharger signature existante
    if (initialData) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, rect.width, CANVAS_HEIGHT);
        setHasDrawn(true);
      };
      img.src = initialData;
    }
  }, [initialData]);

  // ── Coordonnées (souris + tactile) ──────────────────────────────────────
  const getPos = useCallback((e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const touch = e.touches ? e.touches[0] : e;
    return {
      x: touch.clientX - rect.left,
      y: touch.clientY - rect.top,
    };
  }, []);

  const startDraw = useCallback((e) => {
    e.preventDefault();
    setIsDrawing(true);
    setHasDrawn(true);
    lastPoint.current = getPos(e);
  }, [getPos]);

  const draw = useCallback((e) => {
    e.preventDefault();
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const pos = getPos(e);
    const prev = lastPoint.current;

    ctx.beginPath();
    ctx.moveTo(prev.x, prev.y);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();

    lastPoint.current = pos;
  }, [isDrawing, getPos]);

  const endDraw = useCallback((e) => {
    e.preventDefault();
    setIsDrawing(false);
    lastPoint.current = null;
  }, []);

  // ── Effacer ─────────────────────────────────────────────────────────────
  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    ctx.clearRect(0, 0, canvas.width / dpr, canvas.height / dpr);
    setHasDrawn(false);
  };

  // ── Valider ─────────────────────────────────────────────────────────────
  const confirm = () => {
    const canvas = canvasRef.current;
    // Exporter en PNG base64
    const data = canvas.toDataURL('image/png');
    onConfirm(data);
  };

  return (
    <div style={overlay} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div style={modal}>
        {/* Header */}
        <div style={header}>
          <span style={headerTitle}>{title}</span>
          <button type="button" onClick={onClose}
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '4px', color: '#64748b' }}>
            <X size={22} />
          </button>
        </div>

        {/* Canvas */}
        <div style={canvasWrap}>
          {!hasDrawn && (
            <div style={hintText}>Signez ici avec votre doigt<br />ou votre souris</div>
          )}
          <canvas
            ref={canvasRef}
            style={{ display: 'block', width: '100%', cursor: 'crosshair' }}
            onMouseDown={startDraw}
            onMouseMove={draw}
            onMouseUp={endDraw}
            onMouseLeave={endDraw}
            onTouchStart={startDraw}
            onTouchMove={draw}
            onTouchEnd={endDraw}
          />
        </div>

        {/* Footer */}
        <div style={footer}>
          <button type="button" onClick={clearCanvas}
            style={{ ...btnBase, background: '#f1f5f9', color: '#64748b' }}>
            <RotateCcw size={16} /> Effacer
          </button>
          <button type="button" onClick={confirm} disabled={!hasDrawn}
            style={{
              ...btnBase,
              background: hasDrawn ? '#2563eb' : '#e2e8f0',
              color: hasDrawn ? '#fff' : '#94a3b8',
              cursor: hasDrawn ? 'pointer' : 'not-allowed',
            }}>
            <Check size={16} /> Valider
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Composant principal exporté ─────────────────────────────────────────────
// user       : objet Firebase Auth — identité de l'agent connecté (propriétaire/Métropole)
// signerInfo : { nom, email } — surcharge user pour les signataires externes (locataires)
//              quand fourni, l'identité vient du formulaire et non de Firebase Auth
// onChangeMeta : callback(meta) appelé en plus de onChange(img) lors d'une nouvelle signature
export default function SignaturePad({ label, value, onChange, user, signerInfo, onChangeMeta }) {
  const [modalOpen, setModalOpen] = useState(false);

  const handleConfirm = (imgData) => {
    onChange(imgData);
    // Capturer les métadonnées d'identité au moment exact de la signature
    if (onChangeMeta) {
      const meta = signerInfo
        // Signataire externe (locataire) : identité depuis les champs du formulaire
        ? {
            email:     signerInfo.email || '',
            uid:       '',   // pas de compte Firebase pour les externes
            nom:       signerInfo.nom   || '',
            externe:   true,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
          }
        // Agent connecté (propriétaire / Métropole) : identité Firebase Auth
        : {
            email:     user?.email       || 'Non identifié',
            uid:       user?.uid         || '',
            nom:       user?.displayName || '',
            externe:   false,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
          };
      onChangeMeta(meta);
    }
    setModalOpen(false);
  };

  return (
    <>
      <SignatureButton
        label={label}
        signatureData={value}
        onOpen={() => setModalOpen(true)}
        onClear={() => { onChange(''); onChangeMeta && onChangeMeta(null); }}
      />
      {modalOpen && (
        <SignatureModal
          title={label}
          initialData={value}
          onConfirm={handleConfirm}
          onClose={() => setModalOpen(false)}
        />
      )}
    </>
  );
}
