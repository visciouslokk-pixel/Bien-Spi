import { compressedPhotoDataUrl } from '../../../../infrastructure/media/compressPhoto';
// src/features/edl/components/EDLForm.jsx
import React, { useState, useRef, useEffect, createContext, useContext } from 'react';
import { ChevronDown, ChevronUp, Plus, Trash2, X, Save, ClipboardList, User, MapPin, Settings, Key, BarChart3, Home, PenTool, Camera, Users, Leaf, Landmark, Building2, Search, Package, FileText, Pencil, Gauge, Warehouse, TreePine, Briefcase, Wrench } from 'lucide-react';
import { useImageEditor } from '../../../notes/hooks/useImageEditor';
import { NOTES, NOTE_COLORS, TYPES_BIEN, newPiece, newJardinPiece, JARDIN_CRITERES, COMMUNES_METRO_LYON, getInitialByType, isLocal, PEPINIERES_DATA } from '../utils/edlDefaults';
import SignaturePad from './SignaturePad';
import { fieldVisit, isSingleVisit, visitMode } from '../../edlVisit';

const VisitContext = createContext(null);
function VisitFields({ mode, children }) {
  const active = useContext(VisitContext);
  return active && active !== mode ? null : children;
}

// ── Helpers ──────────────────────────────────────────────────────────────────
const inp = {
  width: '100%', padding: '11px 12px', border: '1px solid var(--border)',
  borderRadius: '10px', fontSize: '16px', boxSizing: 'border-box',
  background: 'var(--bg-card)', color: 'var(--text)', outline: 'none',
};
const label = {
  display: 'block', fontSize: '12px', fontWeight: '700', color: 'var(--text-muted)',
  marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.04em',
};
const section = {
  background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '14px',
  overflow: 'hidden', marginBottom: '12px',
};
const sectionHead = (open) => ({
  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
  padding: '14px 16px', cursor: 'pointer', userSelect: 'none',
  background: open ? 'var(--bg-panel)' : 'var(--bg-card)',
  borderBottom: open ? '1px solid var(--border)' : 'none',
});
const sectionTitle = {
  fontSize: '20px', fontWeight: '700', color: 'var(--text)',
  display: 'flex', alignItems: 'center', gap: '8px',
};
const grid2 = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' };
const pad = { padding: '16px', display: 'flex', flexDirection: 'column', gap: '14px' };

// ── NoteSelector ─────────────────────────────────────────────────────────────
function NoteSelector({ value, onChange }) {
  return (
    <div style={{ display: 'flex', gap: '6px' }}>
      {NOTES.map(n => {
        const c = NOTE_COLORS[n];
        const active = value === n;
        return (
          <button key={n} type="button" aria-pressed={active} onClick={() => onChange(active ? '' : n)}
            style={{
              padding: '6px 12px', borderRadius: '20px', fontWeight: '700',
              fontSize: '13px', border: `2px solid ${c.bg}`, cursor: 'pointer',
              background: active ? c.bg : 'transparent',
              color: active ? '#fff' : c.text,
              transition: 'all 0.15s',
              minWidth: '40px',
            }}
          >{n}</button>
        );
      })}
    </div>
  );
}

// ── Toggle ────────────────────────────────────────────────────────────────────
function Toggle({ checked, onChange, label: lbl }) {
  return (
    <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', userSelect: 'none' }}>
      <div
        onClick={() => onChange(!checked)}
        style={{
          width: '42px', height: '24px', borderRadius: '12px', position: 'relative',
          background: checked ? '#2563eb' : 'var(--border-strong)', transition: 'background 0.2s', flexShrink: 0,
        }}
      >
        <div style={{
          position: 'absolute', top: '3px', left: checked ? '21px' : '3px',
          width: '18px', height: '18px', borderRadius: '50%', background: 'var(--bg-card)',
          transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
        }} />
      </div>
      <span style={{ fontSize: '14px', color: 'var(--text)' }}>{lbl}</span>
    </label>
  );
}

// ── Section accordion ─────────────────────────────────────────────────────────
function Section({ title, icon, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div style={section}>
      <div style={sectionHead(open)} onClick={() => setOpen(o => !o)}>
        <div style={sectionTitle}>{icon} {title}</div>
        {open ? <ChevronUp size={18} color="#94a3b8" /> : <ChevronDown size={18} color="#94a3b8" />}
      </div>
      {open && <div style={pad}>{children}</div>}
    </div>
  );
}

// ── Champ texte ───────────────────────────────────────────────────────────────
function Field({ label: lbl, name, value, onChange, placeholder, type = 'text', textarea, required }) {
  const activeVisit = useContext(VisitContext);
  if (activeVisit && fieldVisit(name) && fieldVisit(name) !== activeVisit) return null;
  return (
    <div>
      <label style={label}>{lbl}{required && ' *'}</label>
      {textarea
        ? <textarea name={name} value={value} onChange={onChange} placeholder={placeholder}
            rows={3} style={{ ...inp, resize: 'vertical' }} />
        : <input type={type} name={name} value={value} onChange={onChange}
            placeholder={placeholder} required={required} style={inp} />
      }
    </div>
  );
}

// ── Radio groupe ──────────────────────────────────────────────────────────────
function RadioGroup({ label: lbl, name, value, onChange, options }) {
  return (
    <div>
      <label style={label}>{lbl}</label>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
        {options.map(opt => (
          <button key={opt.value} type="button"
            onClick={() => onChange({ target: { name, value: opt.value } })}
            style={{
              padding: '8px 16px', borderRadius: '20px', fontWeight: '600', fontSize: '13px',
              border: `2px solid ${value === opt.value ? '#2563eb' : 'var(--border-strong)'}`,
              background: value === opt.value ? '#dbeafe' : 'var(--bg-panel)',
              color: value === opt.value ? '#1d4ed8' : 'var(--text-sub)',
              cursor: 'pointer', transition: 'all 0.15s',
            }}
          >{opt.label}</button>
        ))}
      </div>
    </div>
  );
}

function MultiSelectGroup({ label: lbl, name, value, onChange, options }) {
  const selected = Array.isArray(value) ? value : (value ? [value] : []);
  const toggle = (optionValue) => {
    const next = selected.includes(optionValue)
      ? selected.filter((item) => item !== optionValue)
      : [...selected, optionValue];
    onChange({ target: { name, value: next } });
  };

  return (
    <div>
      <label style={label}>{lbl}</label>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
        {options.map(opt => {
          const active = selected.includes(opt.value);
          return (
            <button key={opt.value} type="button"
              onClick={() => toggle(opt.value)}
              style={{
                padding: '8px 16px', borderRadius: '20px', fontWeight: '600', fontSize: '13px',
                border: `2px solid ${active ? '#2563eb' : 'var(--border-strong)'}`,
                background: active ? '#dbeafe' : 'var(--bg-panel)',
                color: active ? '#1d4ed8' : 'var(--text-sub)',
                cursor: 'pointer', transition: 'all 0.15s',
              }}
            >{opt.label}</button>
          );
        })}
      </div>
    </div>
  );
}

// ── Panel équipements (cases à cocher + nombre) ───────────────────────────────
const EQUIP_ITEMS = [
  { key: 'pointsLumineux', label: 'Points lumineux' },
  { key: 'radiateurs',     label: 'Radiateurs' },
  { key: 'placards',       label: 'Placards' },
  { key: 'occultants',     label: 'Occultants', hasDetails: true },
  { key: 'prisesElec',     label: 'Prises électriques' },
  { key: 'interrupteurs',  label: 'Interrupteurs' },
];

export function EquipementsPanel({ value, onChange }) {
  // Compatibilité ascendante : si ancienne donnée texte, on l'ignore
  const eq = (value && typeof value === 'object') ? value : {};

  const upd = (key, field, val) =>
    onChange({ ...eq, [key]: { ...(eq[key] || {}), [field]: val } });
  const updRoot = (field, val) => onChange({ ...eq, [field]: val });

  return (
    <div>
      <label style={{ display: 'block', fontSize: '11px', fontWeight: '700', color: 'var(--text-muted)', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        Équipements
      </label>
      <div style={{ border: '1px solid var(--border)', borderRadius: '10px', overflow: 'hidden' }}>
        {EQUIP_ITEMS.map(({ key, label: lbl, hasDetails }, idx) => {
          const item = eq[key] || {};
          const isLast = idx === EQUIP_ITEMS.length - 1;
          return (
            <div key={key} style={{
              borderBottom: isLast ? 'none' : '1px solid var(--border)',
              padding: '9px 12px',
            }}>
              {/* Ligne principale : checkbox + label + nombre */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <input
                  type="checkbox"
                  aria-label={lbl}
                  checked={!!item.checked}
                  onChange={e => upd(key, 'checked', e.target.checked)}
                  style={{ width: '16px', height: '16px', cursor: 'pointer', accentColor: '#2563eb' }}
                />
                <span style={{ flex: 1, fontSize: '14px', color: item.checked ? 'var(--text)' : 'var(--text-muted)', transition: 'color 0.15s' }}>
                  {lbl}
                </span>
                {item.checked && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <label style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Nb :</label>
                    <input
                      type="number" min="0" aria-label={`Nombre — ${lbl}`}
                      value={item.nombre ?? ''}
                      onChange={e => upd(key, 'nombre', e.target.value)}
                      style={{ width: '60px', padding: '4px 6px', border: '1px solid var(--border)', borderRadius: '6px', background: 'var(--bg-card)', color: 'var(--text)', fontSize: '13px', textAlign: 'center' }}
                    />
                  </div>
                )}
              </div>
              {item.checked && (
                <div role="group" aria-label={`État — ${lbl}`} style={{ marginTop: '8px', paddingLeft: '26px' }}>
                  <NoteSelector value={item.etat || ''} onChange={val => upd(key, 'etat', val)} />
                </div>
              )}
              {/* Détails occultants */}
              {hasDetails && item.checked && (
                <div style={{ display: 'flex', gap: '12px', marginTop: '8px', paddingLeft: '26px', alignItems: 'center', flexWrap: 'wrap' }}>
                  <select
                    aria-label="Type d’occultants"
                    value={item.type || 'interieur'}
                    onChange={e => upd(key, 'type', e.target.value)}
                    style={{ padding: '4px 8px', border: '1px solid var(--border)', borderRadius: '6px', background: 'var(--bg-card)', color: 'var(--text)', fontSize: '13px' }}
                  >
                    <option value="interieur">Intérieur</option>
                    <option value="exterieur">Extérieur</option>
                    <option value="mixte">Mixte</option>
                  </select>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div style={{ marginTop: '10px', display: 'grid', gap: '10px' }}>
        <textarea
          value={eq.observations || ''}
          onChange={e => updRoot('observations', e.target.value)}
          placeholder="Observations sur les équipements de cette pièce..."
          rows={2}
          style={{ ...inp, resize: 'vertical', fontSize: '13px' }}
        />
      </div>
    </div>
  );
}

function MursOrientationPanel({ value, onChange, fallbackValue }) {
  const zones = value && typeof value === 'object' ? value : {};
  const updateZone = (zone, val) => onChange({ ...zones, [zone]: val });
  const orientations = [
    ['nord', 'Nord'],
    ['sud', 'Sud'],
    ['est', 'Est'],
    ['ouest', 'Ouest'],
  ];

  return (
    <div style={{ display: 'grid', gap: '8px' }}>
      {fallbackValue && !Object.values(zones).some(Boolean) && (
        <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Ancienne valeur : {fallbackValue}</div>
      )}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '10px' }}>
        {orientations.map(([key, lbl]) => (
          <div key={key} style={{ border: '1px solid var(--border)', borderRadius: '10px', padding: '9px' }}>
            <label style={{ ...label, marginBottom: '7px' }}>{lbl}</label>
            <NoteSelector value={zones[key] || ''} onChange={val => updateZone(key, val)} />
          </div>
        ))}
      </div>
    </div>
  );
}

const readPhotoAsDataUrl = (file) => compressedPhotoDataUrl(file, 1200);

function JardinPanel({ value, onChange }) {
  const v = (value && typeof value === 'object') ? value : {};
  const upd = (key, field, val) =>
    onChange({ ...v, [key]: { ...(v[key] || {}), [field]: val } });

  const selStyle = {
    padding: '6px 8px', border: '1px solid var(--border)', borderRadius: '8px',
    background: 'var(--bg-card)', color: 'var(--text)', fontSize: '13px',
  };
  const blockStyle = {
    border: '1px solid var(--border)', borderRadius: '10px', padding: '12px',
    display: 'flex', flexDirection: 'column', gap: '10px',
  };
  const blockTitle = (lbl, presentKey, parentKey) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
      <input
        type="checkbox"
        checked={!!(v[parentKey]?.[presentKey])}
        onChange={e => upd(parentKey, presentKey, e.target.checked)}
        style={{ width: '16px', height: '16px', accentColor: '#2563eb', cursor: 'pointer' }}
      />
      <span style={{ fontWeight: '700', fontSize: '14px', color: 'var(--text)' }}>{lbl}</span>
    </div>
  );

  const cloture = v.cloture || {};
  const portail = v.portail || {};
  const terrasse = v.terrasse || {};
  const piscine = v.piscine || {};
  const abri = v.abriJardin || {};

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>

      {/* ── Clôture ── */}
      <div style={blockStyle}>
        {blockTitle('Clôture', 'presente', 'cloture')}
        {cloture.presente && (
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', paddingLeft: '26px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', color: 'var(--text)', cursor: 'pointer' }}>
              <input type="checkbox" checked={!!cloture.rigide}
                onChange={e => upd('cloture', 'rigide', e.target.checked)}
                style={{ accentColor: '#2563eb' }} />
              Rigide
            </label>
            <select value={cloture.etat || ''} onChange={e => upd('cloture', 'etat', e.target.value)} style={selStyle}>
              {ETAT_JARDIN.map(o => <option key={o} value={o}>{o || '— État —'}</option>)}
            </select>
          </div>
        )}
      </div>

      {/* ── Portail ── */}
      <div style={blockStyle}>
        {blockTitle('Portail', 'present', 'portail')}
        {portail.present && (
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', paddingLeft: '26px' }}>
            <select value={portail.materiau || ''} onChange={e => upd('portail', 'materiau', e.target.value)} style={selStyle}>
              <option value="">— Matériau —</option>
              <option value="bois">Bois</option>
              <option value="pvc">PVC</option>
              <option value="metal">Métal</option>
              <option value="aluminium">Aluminium</option>
              <option value="fer_forge">Fer forgé</option>
            </select>
            <select value={portail.etat || ''} onChange={e => upd('portail', 'etat', e.target.value)} style={selStyle}>
              {ETAT_JARDIN.map(o => <option key={o} value={o}>{o || '— État —'}</option>)}
            </select>
          </div>
        )}
      </div>

      {/* ── Terrasse ── */}
      <div style={blockStyle}>
        {blockTitle('Terrasse', 'presente', 'terrasse')}
        {terrasse.presente && (
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', paddingLeft: '26px' }}>
            <select value={terrasse.type || ''} onChange={e => upd('terrasse', 'type', e.target.value)} style={selStyle}>
              <option value="">— Type —</option>
              <option value="bois">Bois</option>
              <option value="composite">Composite</option>
              <option value="beton">Béton</option>
              <option value="carrelage">Carrelage</option>
              <option value="dallage">Dallage</option>
              <option value="gravier">Gravier</option>
              <option value="gazon">Gazon synthétique</option>
            </select>
            <select value={terrasse.etat || ''} onChange={e => upd('terrasse', 'etat', e.target.value)} style={selStyle}>
              {ETAT_JARDIN.map(o => <option key={o} value={o}>{o || '— État —'}</option>)}
            </select>
          </div>
        )}
      </div>

      {/* ── Piscine ── */}
      <div style={blockStyle}>
        {blockTitle('Piscine', 'presente', 'piscine')}
        {piscine.presente && (
          <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', paddingLeft: '26px' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', color: 'var(--text)', cursor: 'pointer' }}>
              <input type="checkbox" checked={!!piscine.cloturee}
                onChange={e => upd('piscine', 'cloturee', e.target.checked)}
                style={{ accentColor: '#2563eb' }} />
              Clôturée
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', color: 'var(--text)', cursor: 'pointer' }}>
              <input type="checkbox" checked={!!piscine.vide}
                onChange={e => upd('piscine', 'vide', e.target.checked)}
                style={{ accentColor: '#2563eb' }} />
              Vidée
            </label>
          </div>
        )}
      </div>

      {/* ── Abri de jardin ── */}
      <div style={blockStyle}>
        {blockTitle('Abri de jardin', 'present', 'abriJardin')}
        {abri.present && (
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', paddingLeft: '26px' }}>
            <select value={abri.type || ''} onChange={e => upd('abriJardin', 'type', e.target.value)} style={selStyle}>
              <option value="">— Type —</option>
              <option value="bois">Bois</option>
              <option value="metal">Métal</option>
              <option value="pvc">PVC</option>
              <option value="resine">Résine</option>
              <option value="maconnerie">Maçonnerie</option>
            </select>
            <select value={abri.etat || ''} onChange={e => upd('abriJardin', 'etat', e.target.value)} style={selStyle}>
              {ETAT_JARDIN.map(o => <option key={o} value={o}>{o || '— État —'}</option>)}
            </select>
            <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', color: 'var(--text)', cursor: 'pointer' }}>
              <input type="checkbox" checked={!!abri.vide}
                onChange={e => upd('abriJardin', 'vide', e.target.checked)}
                style={{ accentColor: '#2563eb' }} />
              Vide
            </label>
          </div>
        )}
      </div>

      {/* Observations globales jardin */}
      <div>
        <label style={{ display: 'block', fontSize: '11px', fontWeight: '700', color: 'var(--text-muted)', marginBottom: '5px', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Observations
        </label>
        <textarea
          value={v.notes || ''}
          onChange={e => onChange({ ...v, notes: e.target.value })}
          placeholder="Observations générales sur le jardin…"
          rows={3}
          style={{ width: '100%', padding: '10px 12px', border: '1px solid var(--border)', borderRadius: '10px', background: 'var(--bg-card)', color: 'var(--text)', fontSize: '14px', resize: 'vertical', boxSizing: 'border-box' }}
        />
      </div>
    </div>
  );
}

// ── Pièce card ────────────────────────────────────────────────────────────────
function PieceCard({ piece, index, onChange, onRemove, globalTypeEDL }) {
  const [open, setOpen] = useState(index < 2);
  const [tab, setTab] = useState('entrant');

  const isJardin = piece.pieceType === 'jardin';
  const activeTab = globalTypeEDL || tab;

  const updateEval = (typeEdl, field, val) => {
    onChange(index, { ...piece, [typeEdl]: { ...piece[typeEdl], [field]: val } });
  };
  const updateEvalFull = (typeEdl, newEval) => {
    onChange(index, { ...piece, [typeEdl]: newEval });
  };

  const evalCurrent = piece[activeTab] || {};
  const piecePhotos = Array.isArray(evalCurrent.photos) ? evalCurrent.photos : [];
  const photoInputId = `piece-photo-${index}-${activeTab}`;

  const addPiecePhoto = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    try {
      const src = await readPhotoAsDataUrl(file);
      updateEval(activeTab, 'photos', [...piecePhotos, { src, legende: '' }]);
    } catch {
      alert('Impossible de charger la photo de la pièce.');
    }
  };

  const updatePiecePhoto = (photoIndex, changes) => {
    updateEval(activeTab, 'photos', piecePhotos.map((photo, idx) => (
      idx === photoIndex ? { ...photo, ...changes } : photo
    )));
  };

  const removePiecePhoto = (photoIndex) => {
    updateEval(activeTab, 'photos', piecePhotos.filter((_, idx) => idx !== photoIndex));
  };

  const STD_CRITERES = [
    { key: 'plafond',     label: 'Plafond' },
    { key: 'murs',        label: 'Murs' },
    { key: 'sols',        label: 'Sols' },
    { key: 'menuiseries', label: 'Menuiseries' },
  ];

  return (
    <div style={{ border: '1px solid var(--border)', borderRadius: '12px', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '12px 14px', background: open ? 'var(--bg-panel)' : 'var(--bg-card)',
        borderBottom: open ? '1px solid var(--border)' : 'none', cursor: 'pointer',
      }} onClick={() => setOpen(o => !o)}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          {open ? <ChevronUp size={16} color="#94a3b8" /> : <ChevronDown size={16} color="#94a3b8" />}
          <input
            value={piece.nom}
            onClick={e => e.stopPropagation()}
            onChange={e => { e.stopPropagation(); onChange(index, { ...piece, nom: e.target.value }); }}
            placeholder="Nom de la pièce"
            style={{ border: 'none', background: 'transparent', fontSize: '14px', fontWeight: '700', color: 'var(--text)', outline: 'none', width: '180px' }}
          />
          {isJardin && (
            <span style={{ fontSize: '11px', color: '#16a34a', fontWeight: '600', background: '#dcfce7', padding: '2px 7px', borderRadius: '10px' }}>
              Jardin
            </span>
          )}
        </div>
        <button type="button" onClick={e => { e.stopPropagation(); onRemove(index); }}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ef4444', padding: '4px' }}>
          <Trash2 size={14} />
        </button>
      </div>

      {open && (
        <div style={{ padding: '14px' }}>
          {/* Tabs entrant / sortant — masqués si typeEDL global défini */}
          {!globalTypeEDL && (
            <div style={{ display: 'flex', gap: '8px', marginBottom: '14px' }}>
              {['entrant', 'sortant'].map(t => (
                <button key={t} type="button" onClick={() => setTab(t)}
                  style={{
                    flex: 1, padding: '9px', borderRadius: '8px', fontWeight: '600', fontSize: '13px',
                    border: `2px solid ${tab === t ? '#2563eb' : 'var(--border-strong)'}`,
                    background: tab === t ? '#dbeafe' : 'var(--bg-panel)',
                    color: tab === t ? '#1d4ed8' : 'var(--text-sub)', cursor: 'pointer',
                  }}
                >
                  {t === 'entrant' ? '↩ Entrant' : '↪ Sortant'}
                </button>
              ))}
            </div>
          )}

          {isJardin
            ? /* ── Jardin : champs spécifiques ── */
              <JardinPanel
                value={evalCurrent}
                onChange={newEval => updateEvalFull(activeTab, newEval)}
              />
            : /* ── Pièce standard ── */
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {STD_CRITERES.map(({ key, label: lbl }) => (
                  <div key={key}>
                    <label style={{ ...label, marginBottom: '7px' }}>{lbl}</label>
                    {key === 'murs' ? (
                      <MursOrientationPanel
                        value={evalCurrent.mursZones}
                        fallbackValue={evalCurrent.murs}
                        onChange={zones => updateEval(activeTab, 'mursZones', zones)}
                      />
                    ) : (
                      <NoteSelector value={evalCurrent[key]} onChange={val => updateEval(activeTab, key, val)} />
                    )}
                  </div>
                ))}
                <EquipementsPanel
                  value={evalCurrent.equipements}
                  onChange={eq => updateEval(activeTab, 'equipements', eq)}
                />
                <Field label="Observations" value={evalCurrent.notes || ''} textarea
                  placeholder="Observations particulières…"
                  onChange={e => updateEval(activeTab, 'notes', e.target.value)} />
                <div style={{ border: '1px solid var(--border)', borderRadius: '10px', padding: '12px', display: 'grid', gap: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '10px' }}>
                    <label style={{ ...label, marginBottom: 0 }}>Photos de la pièce</label>
                    <button type="button"
                      onClick={() => document.getElementById(photoInputId)?.click()}
                      style={{ padding: '7px 12px', borderRadius: '8px', border: '1px solid var(--border-strong)', background: 'var(--bg-panel)', color: 'var(--text-sub)', fontWeight: '700', fontSize: '12px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <Camera size={13} /> Ajouter
                    </button>
                    <input id={photoInputId} type="file" accept="image/*" capture="environment" hidden onChange={addPiecePhoto} />
                  </div>
                  {piecePhotos.length > 0 && (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '10px' }}>
                      {piecePhotos.map((photo, photoIndex) => (
                        <div key={photoIndex} style={{ border: '1px solid var(--border)', borderRadius: '9px', overflow: 'hidden', background: 'var(--bg-card)' }}>
                          <img src={photo.src} alt={`Photo ${piece.nom || 'piece'} ${photoIndex + 1}`} style={{ width: '100%', height: '105px', objectFit: 'cover', display: 'block' }} />
                          <div style={{ padding: '7px', display: 'grid', gap: '6px' }}>
                            <input
                              value={photo.legende || ''}
                              onChange={e => updatePiecePhoto(photoIndex, { legende: e.target.value })}
                              placeholder="Légende..."
                              style={{ ...inp, padding: '6px 8px', fontSize: '12px' }}
                            />
                            <button type="button" onClick={() => removePiecePhoto(photoIndex)}
                              style={{ padding: '6px', borderRadius: '7px', border: '1px solid #fecaca', background: '#fee2e2', color: '#dc2626', fontWeight: '700', fontSize: '12px', cursor: 'pointer' }}>
                              Supprimer
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
          }
        </div>
      )}
    </div>
  );
}

// ── Champ commune avec datalist des 59 communes de la Métropole de Lyon ──────
// Utilise <datalist> : autocomplétion + saisie libre si la commune n'est pas dans la liste.
const DATALIST_ID = 'communes-metro-lyon';
function CommuneField({ name, value, onChange, label: lbl = 'Commune' }) {
  return (
    <div>
      <label style={label}>{lbl}</label>
      <input
        list={DATALIST_ID}
        name={name}
        value={value}
        onChange={onChange}
        placeholder="Sélectionner ou saisir une commune…"
        style={inp}
        autoComplete="off"
      />
      <datalist id={DATALIST_ID}>
        {COMMUNES_METRO_LYON.map(c => <option key={c} value={c} />)}
      </datalist>
    </div>
  );
}

// ── Options des types de pièces pour le menu déroulant ───────────────────────
const TYPES_PIECES_OPTIONS = [
  { base: 'Chambre',                   alwaysNumbered: true  },
  { base: 'Séjour / Salon',            alwaysNumbered: false },
  { base: 'Cuisine',                   alwaysNumbered: false },
  { base: "Salle de bain / Salle d'eau", alwaysNumbered: false },
  { base: 'Toilettes',                 alwaysNumbered: false },
  { base: 'Bureau',                    alwaysNumbered: true  },
  { base: 'Entrée / Hall',             alwaysNumbered: false },
  { base: 'Couloir',                   alwaysNumbered: false },
  { base: 'Dressing',                  alwaysNumbered: false },
  { base: 'Buanderie',                 alwaysNumbered: false },
  { base: 'Cellier',                   alwaysNumbered: false },
  { base: 'Garage',                    alwaysNumbered: false },
];

// ════════════════════════════════════════════════════════════════════════════
// FORM LOGEMENT
// ════════════════════════════════════════════════════════════════════════════
function FormLogement({ form, onChange, onPiecesChange, user }) {
  const ch = (e) => onChange(e.target.name, e.target.value);
  const cht = (name, val) => onChange(name, val);

  // Menu déroulant "Ajouter une pièce"
  const [showAddMenu, setShowAddMenu] = useState(false);
  const addMenuRef = useRef(null);

  // Fermer le menu si clic en dehors
  useEffect(() => {
    if (!showAddMenu) return;
    const handler = (e) => {
      if (addMenuRef.current && !addMenuRef.current.contains(e.target)) {
        setShowAddMenu(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [showAddMenu]);

  // Calcule le nom suivant en auto-numérotant si nécessaire
  const getNextPieceName = (base, alwaysNumbered) => {
    const count = form.pieces.filter(p => p.nom.startsWith(base)).length;
    if (alwaysNumbered) return `${base} ${count + 1}`;
    return count === 0 ? base : `${base} ${count + 1}`;
  };

  const ajouterPieceType = (base, alwaysNumbered, isJardin = false) => {
    const nom = getNextPieceName(base, alwaysNumbered);
    const piece = isJardin ? newJardinPiece(nom) : newPiece(nom);
    onPiecesChange([...form.pieces, piece]);
    setShowAddMenu(false);
  };

  const modifierPiece = (i, p) => {
    const arr = [...form.pieces]; arr[i] = p; onPiecesChange(arr);
  };
  const supprimerPiece = (i) => onPiecesChange(form.pieces.filter((_, idx) => idx !== i));

  const ENERGIES = [
    { value: 'gaz', label: 'Gaz' }, { value: 'fioul', label: 'Fioul' },
    { value: 'electrique', label: 'Électrique' }, { value: 'autre', label: 'Autre' },
  ];
  const OUI_NON = [{ value: 'oui', label: 'Oui' }, { value: 'non', label: 'Non' }];
  const ETAT_ANNEXE = [
    { value: 'vide', label: 'Vide' }, { value: 'non_debarrasse', label: 'Non débarrassé' }
  ];
  const ABOpts = [
    { value: 'service', label: 'En service' }, { value: 'resilie', label: 'Résilié' }
  ];

  const isMaison = form.typeBien === 'maison';

  return (
    <>
      {/* Type d'état des lieux */}
      <Section title="Type d'état des lieux" icon={<ClipboardList size={16} />} defaultOpen>
        <div style={{ display: 'flex', gap: '10px' }}>
          {[
            { value: 'entrant', label: '↩ Entrant' },
            { value: 'sortant', label: '↪ Sortant' },
          ].filter(opt => !isSingleVisit(form) || opt.value === form.typeEDL).map(opt => (
            <button key={opt.value} type="button"
              onClick={() => cht('typeEDL', opt.value)}
              style={{
                flex: 1, padding: '14px', borderRadius: '12px', border: '2px solid',
                borderColor: form.typeEDL === opt.value ? '#2563eb' : 'var(--border-strong)',
                background: form.typeEDL === opt.value ? '#dbeafe' : 'var(--bg-panel)',
                color: form.typeEDL === opt.value ? '#1d4ed8' : 'var(--text-sub)',
                cursor: 'pointer', fontWeight: '700', fontSize: '15px', transition: 'all 0.15s',
              }}
            >{opt.label}</button>
          ))}
        </div>
      </Section>

      {/* Adresse du bien */}
      <Section title="Adresse du bien" icon={<MapPin size={16} />} defaultOpen>
        <Field label="Rue / Adresse" name="adresseRue" value={form.adresseRue} onChange={ch} placeholder="12 rue de la Paix" />
        <div style={grid2}>
          <CommuneField name="commune" value={form.commune} onChange={ch} />
          <Field label="UG" name="ug" value={form.ug} onChange={ch} placeholder="UG" />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
          <Field label="Immeuble" name="immeuble" value={form.immeuble} onChange={ch} placeholder="Bât A" />
          <Field label="Étage" name="etage" value={form.etage} onChange={ch} placeholder="3ème" />
          <Field label="Porte" name="porte" value={form.porte} onChange={ch} placeholder="12" />
        </div>
        <div style={grid2}>
          <Field label="Lot bâtiment" name="lotBatiment" value={form.lotBatiment} onChange={ch} placeholder="Lot 42" />
          <Field label="Allée" name="allee" value={form.allee} onChange={ch} placeholder="Allée des Pins" />
        </div>
      </Section>

      {/* Locataire */}
      <Section title="Locataire" icon={<User size={16} />}>
        <div style={grid2}>
          <Field label="Nom" name="locataireNom" value={form.locataireNom} onChange={ch} placeholder="Dupont" />
          <Field label="Prénom" name="locatairePrenom" value={form.locatairePrenom} onChange={ch} placeholder="Jean" />
        </div>
        <Field label="Société / Association" name="locataireSociete" value={form.locataireSociete} onChange={ch} placeholder="Optionnel" />
        <div style={grid2}>
          <Field label="Téléphone" name="locataireTelephone" value={form.locataireTelephone} onChange={ch} placeholder="04 00 00 00 00" />
          <Field label="Adresse mail" name="locataireEmail" value={form.locataireEmail} onChange={ch} placeholder="nom@exemple.fr" />
        </div>
        {form.typeEDL === 'sortant' && (
          <Field label="Nouvelle adresse postale" name="nouvelleAdressePostale" value={form.nouvelleAdressePostale} onChange={ch} textarea placeholder="Adresse de relogement ou nouvelle adresse connue..." />
        )}
      </Section>

      {/* Informations générales */}
      <Section title="Informations générales" icon={<Settings size={16} />}>
        <div style={grid2}>
          <Field label="Nb de pièces" name="nbPieces" value={form.nbPieces} onChange={ch} placeholder="Ex: 3" />
          <Field label="Dont chambres" name="nbChambres" value={form.nbChambres} onChange={ch} placeholder="Ex: 2" />
        </div>
        <Field label="Surface (m²)" name="surface" value={form.surface} onChange={ch} placeholder="Ex: 65" />
        <RadioGroup label="Attestation d'assurance" name="assurance" value={form.assurance} onChange={ch}
          options={OUI_NON} />
        <div style={grid2}>
          <Field label="Copro / Syndic" name="copro" value={form.copro} onChange={ch} placeholder="Nom syndic" />
          <Field label="Date EDL" name="dateEDL" type="date" value={form.dateEDL} onChange={ch} />
        </div>
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: '12px', display: 'grid', gap: '12px' }}>
          <label style={label}>Annexes et remise des clés</label>
          {[
            { numKey: 'garageNum', etatKey: 'garageEtat', label: 'Garage n°' },
            { numKey: 'caveNum', etatKey: 'caveEtat', label: 'Cave n°' },
            { numKey: 'grenierNum', etatKey: 'grenierEtat', label: 'Grenier n°' },
          ].map(({ numKey, etatKey, label: lbl }) => (
            <div key={numKey} style={{ display: 'flex', gap: '10px', alignItems: 'flex-end' }}>
              <div style={{ flex: '0 0 120px' }}>
                <Field label={lbl} name={numKey} value={form[numKey]} onChange={ch} placeholder="—" />
              </div>
              <div style={{ flex: 1 }}>
                <RadioGroup label="État" name={etatKey} value={form[etatKey]} onChange={ch} options={ETAT_ANNEXE} />
              </div>
            </div>
          ))}
          <div>
            <label style={label}>Visite réalisée</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
              {[
                { key: 'visiteEau', label: 'Avec eau' },
                { key: 'visiteElec', label: 'Avec électricité' },
                { key: 'visiteGaz', label: 'Avec gaz' },
              ].map(({ key, label: lbl }) => (
                <Toggle key={key} checked={form[key]} onChange={v => cht(key, v)} label={lbl} />
              ))}
            </div>
          </div>
          <div style={grid2}>
            <Toggle checked={form.remiseCles} onChange={v => cht('remiseCles', v)} label="Remise des clés" />
            <Field label="Nombre de clés remises" name="nombreClesRemises" value={form.nombreClesRemises} onChange={ch} placeholder="Ex: 4" />
          </div>
        </div>
      </Section>

      {/* Équipements */}
      <Section title="Équipements collectifs" icon={<Settings size={16} />}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          {[
            { key: 'ascenseur', label: 'Ascenseur' },
            { key: 'interphone', label: 'Interphone' },
            { key: 'antenneTv', label: 'Antenne TV' },
            { key: 'digicode', label: 'Digicode' },
            { key: 'eauFroideCollective', label: 'Eau froide collective' },
            { key: 'eauChaudeCollective', label: 'Eau chaude collective' },
          ].map(({ key, label: lbl }) => (
            <Toggle key={key} checked={form[key]} onChange={v => cht(key, v)} label={lbl} />
          ))}
        </div>

        <RadioGroup label="Mode de chauffage" name="chauffageMode" value={form.chauffageMode} onChange={ch}
          options={[{ value: 'individuel', label: 'Individuel' }, { value: 'collectif', label: 'Collectif' }]} />
        <MultiSelectGroup label="Énergie" name="chauffageEnergie" value={form.chauffageEnergie} onChange={ch}
          options={ENERGIES} />
        {(Array.isArray(form.chauffageEnergie) ? form.chauffageEnergie : [form.chauffageEnergie]).includes('autre') && (
          <Field label="Précision énergie autre" name="chauffageEnergieAutre" value={form.chauffageEnergieAutre} onChange={ch} placeholder="Ex: réseau urbain, pompe à chaleur..." />
        )}
        <div style={grid2}>
          <RadioGroup label="Justificatif entretien" name="chauffageJustificatif"
            value={form.chauffageJustificatif ? 'oui' : 'non'}
            onChange={e => cht('chauffageJustificatif', e.target.value === 'oui')}
            options={OUI_NON} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            <RadioGroup label="Chauffage purgé" name="chauffagePurge" value={form.chauffagePurge} onChange={ch}
              options={OUI_NON} />
            <RadioGroup label="Chauffage testé" name="chauffageTeste" value={form.chauffageTeste} onChange={ch}
              options={OUI_NON} />
          </div>
        </div>
      </Section>

      {/* Compteurs */}
      <Section title="Relevés compteurs" icon={<BarChart3 size={16} />}>
        <div style={grid2}>
          <Field label="Date d'entrée" name="dateEntree" type="date" value={form.dateEntree} onChange={ch} />
          <Field label="Date de sortie" name="dateSortie" type="date" value={form.dateSortie} onChange={ch} />
        </div>
        {[
          { prefix: 'eauChaude', label: 'Eau chaude' },
          { prefix: 'eauFroide', label: 'Eau froide' },
          { prefix: 'elect', label: 'Électricité' },
          { prefix: 'gaz', label: 'Gaz' },
        ].map(({ prefix, label: lbl }) => (
          <div key={prefix} style={{ border: '1px solid var(--border)', borderRadius: '10px', padding: '12px' }}>
            <div style={{ fontSize: '13px', fontWeight: '700', color: 'var(--text-sub)', marginBottom: '10px' }}>{lbl}</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
              <Field label="N° compteur" name={`${prefix}Num`} value={form[`${prefix}Num`]} onChange={ch} placeholder="—" />
              <RadioGroup label="Abonnement" name={`${prefix}Abo`} value={form[`${prefix}Abo`]} onChange={ch} options={ABOpts} />
              <Field label="Index entrée" name={`${prefix}IdxE`} value={form[`${prefix}IdxE`]} onChange={ch} placeholder="0" />
              <Field label="Index sortie" name={`${prefix}IdxS`} value={form[`${prefix}IdxS`]} onChange={ch} placeholder="0" />
            </div>
          </div>
        ))}
      </Section>

      {/* Pièces */}
      <Section title={`Pièces (${form.pieces.length})`} icon={<Home size={16} />} defaultOpen>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {form.pieces.map((p, i) => (
            <PieceCard key={i} piece={p} index={i}
              onChange={modifierPiece} onRemove={supprimerPiece}
              globalTypeEDL={form.typeEDL || null} />
          ))}
        </div>

        {/* Bouton + menu déroulant "Ajouter une pièce" */}
        <div ref={addMenuRef} style={{ position: 'relative' }}>
          <button type="button" onClick={() => setShowAddMenu(m => !m)}
            style={{
              width: '100%', padding: '12px', borderRadius: '10px', border: '2px dashed var(--border-strong)',
              background: 'var(--bg-panel)', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '14px',
              fontWeight: '600', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
            }}
          >
            <Plus size={16} /> Ajouter une pièce
          </button>

          {showAddMenu && (
            <div style={{
              position: 'absolute', bottom: 'calc(100% + 6px)', left: 0, right: 0,
              background: 'var(--bg-card)', border: '1px solid var(--border-strong)',
              borderRadius: '12px', boxShadow: '0 8px 24px rgba(0,0,0,0.18)',
              zIndex: 200, overflow: 'hidden',
            }}>
              {TYPES_PIECES_OPTIONS.map(({ base, alwaysNumbered }) => {
                const nom = getNextPieceName(base, alwaysNumbered);
                return (
                  <button key={base} type="button"
                    onClick={() => ajouterPieceType(base, alwaysNumbered)}
                    style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      width: '100%', padding: '11px 16px', background: 'none', border: 'none',
                      borderBottom: '1px solid var(--border)', cursor: 'pointer',
                      textAlign: 'left', fontSize: '14px', color: 'var(--text)',
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-panel)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'none'}
                  >
                    <span>{base}</span>
                    <span style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: '600' }}>→ {nom}</span>
                  </button>
                );
              })}

              {/* Jardin — seulement pour Maison */}
              {isMaison && (
                <button type="button"
                  onClick={() => ajouterPieceType('Jardin', false, true)}
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    width: '100%', padding: '11px 16px', background: 'none', border: 'none',
                    cursor: 'pointer', textAlign: 'left', fontSize: '14px', color: '#16a34a', fontWeight: '600',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-panel)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'none'}
                >
                  <span>Jardin</span>
                  <span style={{ fontSize: '12px', color: '#16a34a', fontWeight: '600' }}>
                    → {getNextPieceName('Jardin', false)}
                  </span>
                </button>
              )}
            </div>
          )}
        </div>
      </Section>

      {/* Signatures */}
      <Section title="Signatures" icon={<PenTool size={16} />}>
        <div style={grid2}>
          <Field label="Date signature entrante" name="dateSignatureEntrant" type="date" value={form.dateSignatureEntrant} onChange={ch} />
          <Field label="Date signature sortante" name="dateSignatureSortant" type="date" value={form.dateSignatureSortant} onChange={ch} />
        </div>
        <VisitFields mode="entrant"><div style={grid2}>
          <Field label="Propriétaire (entrée)" name="sigProprietaireEntrant" value={form.sigProprietaireEntrant} onChange={ch} placeholder="Nom" />
          <Field label="Locataire (entrée)" name="sigLocataireEntrant" value={form.sigLocataireEntrant} onChange={ch} placeholder="Nom" />
        </div></VisitFields>
        <VisitFields mode="entrant"><div style={grid2}>
          <SignaturePad label="Signature propriétaire (entrée)" value={form.sigImgProprietaireEntrant || ''} onChange={v => cht('sigImgProprietaireEntrant', v)} user={user} onChangeMeta={m => cht('sigMetaProprietaireEntrant', m)} />
          <SignaturePad label="Signature locataire (entrée)" value={form.sigImgLocataireEntrant || ''} onChange={v => cht('sigImgLocataireEntrant', v)} user={user} signerInfo={{ nom: form.sigLocataireEntrant || form.locataireNom || '' }} onChangeMeta={m => cht('sigMetaLocataireEntrant', m)} />
        </div></VisitFields>
        <VisitFields mode="sortant"><div style={grid2}>
          <Field label="Propriétaire (sortie)" name="sigProprietaireSortant" value={form.sigProprietaireSortant} onChange={ch} placeholder="Nom" />
          <Field label="Locataire (sortie)" name="sigLocataireSortant" value={form.sigLocataireSortant} onChange={ch} placeholder="Nom" />
        </div></VisitFields>
        <VisitFields mode="sortant"><div style={grid2}>
          <SignaturePad label="Signature propriétaire (sortie)" value={form.sigImgProprietaireSortant || ''} onChange={v => cht('sigImgProprietaireSortant', v)} user={user} onChangeMeta={m => cht('sigMetaProprietaireSortant', m)} />
          <SignaturePad label="Signature locataire (sortie)" value={form.sigImgLocataireSortant || ''} onChange={v => cht('sigImgLocataireSortant', v)} user={user} signerInfo={{ nom: form.sigLocataireSortant || form.locataireNom || '' }} onChangeMeta={m => cht('sigMetaLocataireSortant', m)} />
        </div></VisitFields>
      </Section>
    </>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// FORM LOCAL (commercial / stockage / ICPE / atelier)
// ════════════════════════════════════════════════════════════════════════════

// Types de zones spécifiques aux locaux non-résidentiels
const TYPES_ZONES_LOCAL = [
  { base: 'Espace principal',          alwaysNumbered: false },
  { base: 'Bureau',                    alwaysNumbered: true  },
  { base: 'Sas d\'entrée',            alwaysNumbered: false },
  { base: 'Sanitaires / WC',          alwaysNumbered: true  },
  { base: 'Vestiaires',               alwaysNumbered: false },
  { base: 'Zone de stockage',         alwaysNumbered: true  },
  { base: 'Mezzanine',                alwaysNumbered: true  },
  { base: 'Quai / Zone de livraison', alwaysNumbered: false },
  { base: 'Local technique',          alwaysNumbered: true  },
  { base: 'Show-room / Vitrine',      alwaysNumbered: false },
  { base: 'Zone ICPE / Zone à risque',alwaysNumbered: true  },
  { base: 'Couloir / Dégagement',     alwaysNumbered: false },
  { base: 'Archives',                 alwaysNumbered: false },
];

const USAGES_LOCAL = [
  { value: 'commercial',  label: 'Commercial'       },
  { value: 'stockage',    label: 'Stockage'          },
  { value: 'icpe',        label: 'ICPE'              },
  { value: 'atelier',     label: 'Atelier / Artisanal' },
  { value: 'bureau',      label: 'Bureau'            },
  { value: 'mixte',       label: 'Mixte'             },
  { value: 'autre',       label: 'Autre'             },
];

function FormLocal({ form, onChange, onPiecesChange, user }) {
  const ch  = (e) => onChange(e.target.name, e.target.value);
  const cht = (name, val) => onChange(name, val);

  const [showAddMenu, setShowAddMenu] = useState(false);
  const addMenuRef = useRef(null);

  useEffect(() => {
    if (!showAddMenu) return;
    const handler = (e) => {
      if (addMenuRef.current && !addMenuRef.current.contains(e.target)) setShowAddMenu(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [showAddMenu]);

  const getNextZoneName = (base, alwaysNumbered) => {
    const count = (form.pieces || []).filter(p => p.nom.startsWith(base)).length;
    if (alwaysNumbered) return `${base} ${count + 1}`;
    return count === 0 ? base : `${base} ${count + 1}`;
  };

  const ajouterZone = (base, alwaysNumbered) => {
    const nom = getNextZoneName(base, alwaysNumbered);
    onPiecesChange([...(form.pieces || []), newPiece(nom)]);
    setShowAddMenu(false);
  };

  const modifierPiece = (i, p) => {
    const arr = [...(form.pieces || [])]; arr[i] = p; onPiecesChange(arr);
  };
  const supprimerPiece = (i) => onPiecesChange((form.pieces || []).filter((_, idx) => idx !== i));

  const OUI_NON = [{ value: 'oui', label: 'Oui' }, { value: 'non', label: 'Non' }];
  const ETAT_ANNEXE = [
    { value: 'vide', label: 'Vide' }, { value: 'non_debarrasse', label: 'Non débarrassé' }
  ];
  const ABOpts = [
    { value: 'service', label: 'En service' }, { value: 'resilie', label: 'Résilié' }
  ];
  const ENERGIES_LOCAL = [
    { value: 'electrique', label: 'Électrique' }, { value: 'gaz', label: 'Gaz' },
    { value: 'fioul', label: 'Fioul' }, { value: 'autre', label: 'Autre' },
  ];

  return (
    <>
      {/* Type d'état des lieux */}
      <Section title="Type d'état des lieux" icon={<ClipboardList size={16} />} defaultOpen>
        <div style={{ display: 'flex', gap: '10px' }}>
          {[
            { value: 'entrant', label: '↩ Entrant' },
            { value: 'sortant', label: '↪ Sortant' },
          ].filter(opt => !isSingleVisit(form) || opt.value === form.typeEDL).map(opt => (
            <button key={opt.value} type="button"
              onClick={() => cht('typeEDL', opt.value)}
              style={{
                flex: 1, padding: '14px', borderRadius: '12px', border: '2px solid',
                borderColor: form.typeEDL === opt.value ? '#2563eb' : 'var(--border-strong)',
                background: form.typeEDL === opt.value ? '#dbeafe' : 'var(--bg-panel)',
                color: form.typeEDL === opt.value ? '#1d4ed8' : 'var(--text-sub)',
                cursor: 'pointer', fontWeight: '700', fontSize: '15px', transition: 'all 0.15s',
              }}
            >{opt.label}</button>
          ))}
        </div>
      </Section>

      {/* Adresse du local */}
      <Section title="Adresse du local" icon={<MapPin size={16} />} defaultOpen>
        <Field label="Rue / Adresse" name="adresseRue" value={form.adresseRue}
          onChange={ch} placeholder="12 rue de la Paix" />
        <div style={grid2}>
          <CommuneField name="commune" value={form.commune} onChange={ch} />
          <Field label="UG" name="ug" value={form.ug} onChange={ch} placeholder="UG" />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
          <Field label="Bâtiment" name="immeuble" value={form.immeuble} onChange={ch} placeholder="Bât A" />
          <Field label="Étage / Niveau" name="etage" value={form.etage} onChange={ch} placeholder="RDC" />
          <Field label="Porte / Cellule" name="porte" value={form.porte} onChange={ch} placeholder="12" />
        </div>
        <div style={grid2}>
          <Field label="Lot / Cellule n°" name="lotBatiment" value={form.lotBatiment} onChange={ch} placeholder="Lot 42" />
          <Field label="Allée / Zone" name="allee" value={form.allee} onChange={ch} placeholder="Zone A" />
        </div>
      </Section>

      {/* Locataire / Occupant */}
      <Section title="Locataire / Occupant" icon={<User size={16} />}>
        <Field label="Raison sociale / Société" name="locataireSociete" value={form.locataireSociete}
          onChange={ch} placeholder="SARL Dupont, Auto-entrepreneur..." />
        <div style={grid2}>
          <Field label="SIREN" name="locataireSiren" value={form.locataireSiren}
            onChange={ch} placeholder="123 456 789" />
          <Field label="Fonction / Qualité" name="locataireFonction" value={form.locataireFonction}
            onChange={ch} placeholder="Gérant, Président..." />
        </div>
        <div style={grid2}>
          <Field label="Nom" name="locataireNom" value={form.locataireNom} onChange={ch} placeholder="Dupont" />
          <Field label="Prénom" name="locatairePrenom" value={form.locatairePrenom} onChange={ch} placeholder="Jean" />
        </div>
        <Field label="Adresse" name="locataireAdresse" value={form.locataireAdresse}
          onChange={ch} placeholder="12 rue de la Paix" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '12px' }}>
          <Field label="Code postal" name="locataireCp" value={form.locataireCp} onChange={ch} placeholder="69001" />
          <Field label="Ville" name="locataireVille" value={form.locataireVille} onChange={ch} placeholder="Lyon" />
        </div>
        <div style={grid2}>
          <Field label="Téléphone" name="locataireTel" value={form.locataireTel}
            onChange={ch} placeholder="04 xx xx xx xx" type="tel" />
          <Field label="Portable" name="locatairePort" value={form.locatairePort}
            onChange={ch} placeholder="06 xx xx xx xx" type="tel" />
        </div>
      </Section>

      {/* Descriptif du local */}
      <Section title="Descriptif du local" icon={<Settings size={16} />}>
        {/* Usage */}
        <div>
          <label style={label}>Nature / Usage du local</label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '6px' }}>
            {USAGES_LOCAL.map(u => {
              const active = form.usageLocal === u.value;
              return (
                <button key={u.value} type="button"
                  onClick={() => cht('usageLocal', active ? '' : u.value)}
                  style={{
                    padding: '7px 14px', borderRadius: '20px', border: '2px solid',
                    borderColor: active ? '#2563eb' : 'var(--border-strong)',
                    background: active ? '#dbeafe' : 'var(--bg-panel)',
                    color: active ? '#1d4ed8' : 'var(--text-sub)',
                    cursor: 'pointer', fontWeight: active ? '700' : '500', fontSize: '13px',
                    transition: 'all 0.15s',
                  }}
                >{u.label}</button>
              );
            })}
          </div>
        </div>
        <div style={grid2}>
          <Field label="Surface (m²)" name="surface" value={form.surface} onChange={ch} placeholder="Ex: 120" />
          <Field label="Date EDL" name="dateEDL" type="date" value={form.dateEDL} onChange={ch} />
        </div>
        <Field label="Références cadastrales" name="referencesCadastrales" value={form.referencesCadastrales}
          onChange={ch} placeholder="Ex: AB 0042" />
        <RadioGroup label="Attestation d'assurance" name="assurance" value={form.assurance}
          onChange={ch} options={OUI_NON} />
      </Section>

      {/* Équipements & accès */}
      <Section title="Équipements & accès" icon={<Key size={16} />}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          {[
            { key: 'digicode',          label: 'Digicode' },
            { key: 'interphone',        label: 'Interphone / Visiophone' },
            { key: 'alarme',            label: 'Alarme / Télésurveillance' },
            { key: 'triPhase',          label: 'Triphasé / Prise de force' },
            { key: 'ventilationForcee', label: 'Ventilation forcée (VMC/extracteur)' },
          ].map(({ key, label: lbl }) => (
            <Toggle key={key} checked={!!form[key]} onChange={v => cht(key, v)} label={lbl} />
          ))}
        </div>
        <RadioGroup label="Mode de chauffage" name="chauffageMode" value={form.chauffageMode} onChange={ch}
          options={[{ value: 'individuel', label: 'Individuel' }, { value: 'collectif', label: 'Collectif' }, { value: 'aucun', label: 'Aucun' }]} />
        <RadioGroup label="Énergie de chauffage" name="chauffageEnergie" value={form.chauffageEnergie}
          onChange={ch} options={ENERGIES_LOCAL} />
      </Section>

      {/* Annexes */}
      <Section title="Annexes" icon={<Package size={16} />}>
        {[
          { numKey: 'parkingNum', etatKey: 'parkingEtat', label: 'Parking n°' },
          { numKey: 'caveNum',    etatKey: 'caveEtat',    label: 'Cave / Débarras n°' },
        ].map(({ numKey, etatKey, label: lbl }) => (
          <div key={numKey} style={{ display: 'flex', gap: '10px', alignItems: 'flex-end' }}>
            <div style={{ flex: '0 0 140px' }}>
              <Field label={lbl} name={numKey} value={form[numKey]} onChange={ch} placeholder="—" />
            </div>
            <div style={{ flex: 1 }}>
              <RadioGroup label="État" name={etatKey} value={form[etatKey]} onChange={ch} options={ETAT_ANNEXE} />
            </div>
          </div>
        ))}
        <Toggle checked={!!form.remiseCles} onChange={v => cht('remiseCles', v)} label="Remise des clés" />
      </Section>

      {/* Relevés compteurs */}
      <Section title="Relevés compteurs" icon={<BarChart3 size={16} />}>
        <div style={grid2}>
          <Field label="Date d'entrée" name="dateEntree" type="date" value={form.dateEntree} onChange={ch} />
          <Field label="Date de sortie" name="dateSortie" type="date" value={form.dateSortie} onChange={ch} />
        </div>
        {[
          { prefix: 'eauFroide', label: 'Eau' },
          { prefix: 'elect',     label: 'Électricité' },
          { prefix: 'gaz',       label: 'Gaz' },
        ].map(({ prefix, label: lbl }) => (
          <div key={prefix} style={{ border: '1px solid var(--border)', borderRadius: '10px', padding: '12px' }}>
            <div style={{ fontSize: '13px', fontWeight: '700', color: 'var(--text-sub)', marginBottom: '10px' }}>{lbl}</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
              <Field label="N° compteur" name={`${prefix}Num`} value={form[`${prefix}Num`]} onChange={ch} placeholder="—" />
              <RadioGroup label="Abonnement" name={`${prefix}Abo`} value={form[`${prefix}Abo`]} onChange={ch} options={ABOpts} />
              <Field label="Index entrée" name={`${prefix}IdxE`} value={form[`${prefix}IdxE`]} onChange={ch} placeholder="0" />
              <Field label="Index sortie" name={`${prefix}IdxS`} value={form[`${prefix}IdxS`]} onChange={ch} placeholder="0" />
            </div>
          </div>
        ))}
      </Section>

      {/* Zones / Espaces */}
      <Section title={`Zones / Espaces (${(form.pieces || []).length})`} icon={<Warehouse size={16} />} defaultOpen>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {(form.pieces || []).map((p, i) => (
            <PieceCard key={i} piece={p} index={i}
              onChange={modifierPiece} onRemove={supprimerPiece}
              globalTypeEDL={form.typeEDL || null} />
          ))}
        </div>

        <div ref={addMenuRef} style={{ position: 'relative' }}>
          <button type="button" onClick={() => setShowAddMenu(m => !m)}
            style={{
              width: '100%', padding: '12px', borderRadius: '10px', border: '2px dashed var(--border-strong)',
              background: 'var(--bg-panel)', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '14px',
              fontWeight: '600', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
            }}
          >
            <Plus size={16} /> Ajouter une zone
          </button>

          {showAddMenu && (
            <div style={{
              position: 'absolute', bottom: 'calc(100% + 6px)', left: 0, right: 0,
              background: 'var(--bg-card)', border: '1px solid var(--border-strong)',
              borderRadius: '12px', boxShadow: '0 8px 24px rgba(0,0,0,0.18)',
              zIndex: 200, overflow: 'hidden',
            }}>
              {TYPES_ZONES_LOCAL.map(({ base, alwaysNumbered }) => {
                const nom = getNextZoneName(base, alwaysNumbered);
                return (
                  <button key={base} type="button"
                    onClick={() => ajouterZone(base, alwaysNumbered)}
                    style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      width: '100%', padding: '11px 16px', background: 'none', border: 'none',
                      borderBottom: '1px solid var(--border)', cursor: 'pointer',
                      textAlign: 'left', fontSize: '14px', color: 'var(--text)',
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-panel)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'none'}
                  >
                    <span>{base}</span>
                    <span style={{ fontSize: '12px', color: 'var(--text-muted)', fontWeight: '600' }}>→ {nom}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </Section>

      {/* Observations */}
      <Section title="Observations particulières" icon={<FileText size={16} />}>
        <Field label="Observations à l'entrée" name="observationsEntree" value={form.observationsEntree || ''}
          onChange={ch} textarea placeholder="Remarques spécifiques, réserves, état général..." />
        <Field label="Observations à la sortie" name="observationsSortie" value={form.observationsSortie || ''}
          onChange={ch} textarea placeholder="Remarques spécifiques, réserves, état général..." />
      </Section>

      {/* Signatures */}
      <Section title="Signatures" icon={<PenTool size={16} />}>
        <div style={grid2}>
          <Field label="Date signature entrante" name="dateSignatureEntrant" type="date"
            value={form.dateSignatureEntrant} onChange={ch} />
          <Field label="Date signature sortante" name="dateSignatureSortant" type="date"
            value={form.dateSignatureSortant} onChange={ch} />
        </div>
        <VisitFields mode="entrant"><div style={grid2}>
          <Field label="Propriétaire / Bailleur (entrée)" name="sigProprietaireEntrant"
            value={form.sigProprietaireEntrant} onChange={ch} placeholder="Nom" />
          <Field label="Occupant / Locataire (entrée)" name="sigLocataireEntrant"
            value={form.sigLocataireEntrant} onChange={ch} placeholder="Nom" />
        </div></VisitFields>
        <VisitFields mode="entrant"><div style={grid2}>
          <SignaturePad label="Signature propriétaire (entrée)" value={form.sigImgProprietaireEntrant || ''}
            onChange={v => cht('sigImgProprietaireEntrant', v)} user={user}
            onChangeMeta={m => cht('sigMetaProprietaireEntrant', m)} />
          <SignaturePad label="Signature occupant (entrée)" value={form.sigImgLocataireEntrant || ''}
            onChange={v => cht('sigImgLocataireEntrant', v)} user={user}
            signerInfo={{ nom: form.sigLocataireEntrant || form.locataireNom || '' }}
            onChangeMeta={m => cht('sigMetaLocataireEntrant', m)} />
        </div></VisitFields>
        <VisitFields mode="sortant"><div style={grid2}>
          <Field label="Propriétaire / Bailleur (sortie)" name="sigProprietaireSortant"
            value={form.sigProprietaireSortant} onChange={ch} placeholder="Nom" />
          <Field label="Occupant / Locataire (sortie)" name="sigLocataireSortant"
            value={form.sigLocataireSortant} onChange={ch} placeholder="Nom" />
        </div></VisitFields>
        <VisitFields mode="sortant"><div style={grid2}>
          <SignaturePad label="Signature propriétaire (sortie)" value={form.sigImgProprietaireSortant || ''}
            onChange={v => cht('sigImgProprietaireSortant', v)} user={user}
            onChangeMeta={m => cht('sigMetaProprietaireSortant', m)} />
          <SignaturePad label="Signature occupant (sortie)" value={form.sigImgLocataireSortant || ''}
            onChange={v => cht('sigImgLocataireSortant', v)} user={user}
            signerInfo={{ nom: form.sigLocataireSortant || form.locataireNom || '' }}
            onChangeMeta={m => cht('sigMetaLocataireSortant', m)} />
        </div></VisitFields>
      </Section>
    </>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// FORM TERRAIN
// ════════════════════════════════════════════════════════════════════════════
function FormTerrain({ form, onChange, user }) {
  const ch = (e) => onChange(e.target.name, e.target.value);
  const [legacyTab, setTabFluides] = useState('entree');
  const tabFluides = isSingleVisit(form) ? (visitMode(form) === 'entrant' ? 'entree' : 'sortie') : legacyTab;

  const fluides = [
    { key: 'gaz', label: '🔥 Gaz' },
    { key: 'elec', label: '⚡ Électricité' },
    { key: 'eau', label: '💧 Eau' },
    { key: 'autre', label: '➕ Autre' },
  ];
  const autres = [
    { key: 'cloture', label: '🚧 Clôture' },
    { key: 'portail', label: '🚪 Portail' },
    { key: 'bati', label: '🏗️ Bâti' },
    { key: 'encombr', label: '📦 Encombrant' },
  ];

  return (
    <>
      {/* Locataire terrain */}
      <Section title="Informations locataire" icon={<User size={16} />} defaultOpen>
        <Field label="Raison sociale" name="locRaisonSociale" value={form.locRaisonSociale} onChange={ch} placeholder="Société ou association" />
        <div style={grid2}>
          <Field label="Nom" name="locNom" value={form.locNom} onChange={ch} placeholder="Dupont" />
          <Field label="Prénom" name="locPrenom" value={form.locPrenom} onChange={ch} placeholder="Jean" />
        </div>
        <Field label="Fonction (personne morale)" name="locFonction" value={form.locFonction} onChange={ch} placeholder="Gérant, Président..." />
        <Field label="Adresse" name="locAdresse" value={form.locAdresse} onChange={ch} placeholder="12 rue de la Paix" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '12px' }}>
          <Field label="Code postal" name="locCp" value={form.locCp} onChange={ch} placeholder="69001" />
          <Field label="Ville" name="locVille" value={form.locVille} onChange={ch} placeholder="Lyon" />
        </div>
        <div style={grid2}>
          <Field label="Téléphone" name="locTel" value={form.locTel} onChange={ch} placeholder="04 xx xx xx xx" type="tel" />
          <Field label="Portable" name="locPort" value={form.locPort} onChange={ch} placeholder="06 xx xx xx xx" type="tel" />
        </div>
      </Section>

      {/* Descriptif du bien */}
      <Section title="Descriptif du bien" icon={<MapPin size={16} />}>
        <div style={grid2}>
          <Field label="Parcelle(s) n°" name="parcelle" value={form.parcelle} onChange={ch} placeholder="AB 0012" />
          <Field label="Garage n°" name="garageNum" value={form.garageNum} onChange={ch} placeholder="—" />
        </div>
        <Field label="Surface (m²)" name="surfaceTerrain" value={form.surfaceTerrain} onChange={ch} placeholder="Ex: 500" />
        <Field label="Identifiant du bien" name="identifiantBien" value={form.identifiantBien} onChange={ch} placeholder="Référence interne" />
        <Field label="Adresse du bien" name="adresseBien" value={form.adresseBien} onChange={ch} placeholder="Lieu-dit, route..." />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '12px' }}>
          <Field label="Code postal" name="cpBien" value={form.cpBien} onChange={ch} placeholder="69001" />
          <CommuneField name="villeBien" value={form.villeBien} onChange={ch} label="Ville / Commune" />
        </div>
        <div style={grid2}>
          <Field label="Date d'entrée" name="dateEntree" type="date" value={form.dateEntree} onChange={ch} />
          <Field label="Date de sortie" name="dateSortie" type="date" value={form.dateSortie} onChange={ch} />
        </div>
      </Section>

      {/* Fluides — tabs entrée/sortie */}
      <Section title="Fluides" icon={<Gauge size={16} />}>
        <div style={{ display: 'flex', gap: '8px', marginBottom: '14px' }}>
          {[['entree', '↩ Entrée'], ['sortie', '↪ Sortie']].filter(([value]) => !isSingleVisit(form) || value === tabFluides).map(([tabVal, lbl]) => (
            <button key={tabVal} type="button" onClick={() => setTabFluides(tabVal)}
              style={{
                flex: 1, padding: '9px', borderRadius: '8px', fontWeight: '600', fontSize: '13px',
                border: `2px solid ${tabFluides === tabVal ? '#2563eb' : 'var(--border-strong)'}`,
                background: tabFluides === tabVal ? '#dbeafe' : 'var(--bg-panel)',
                color: tabFluides === tabVal ? '#1d4ed8' : 'var(--text-sub)', cursor: 'pointer',
              }}
            >{lbl}</button>
          ))}
        </div>
        {fluides.map(({ key, label: lbl }) => {
          const fieldName = `${key}${tabFluides === 'entree' ? 'Entree' : 'Sortie'}Desc`;
          return (
            <Field key={key} label={lbl} name={fieldName} value={form[fieldName]} onChange={ch}
              textarea placeholder="Descriptif et état..." />
          );
        })}
      </Section>

      {/* Autres éléments */}
      <Section title="Autres éléments" icon={<Settings size={16} />}>
        <div style={{ display: 'flex', gap: '8px', marginBottom: '14px' }}>
          {[['entree', '↩ Entrée'], ['sortie', '↪ Sortie']].filter(([value]) => !isSingleVisit(form) || value === tabFluides).map(([val, lbl]) => (
            <button key={val} type="button"
              onClick={() => setTabFluides(val)}
              style={{
                flex: 1, padding: '9px', borderRadius: '8px', fontWeight: '600', fontSize: '13px',
                border: `2px solid ${tabFluides === val ? '#2563eb' : 'var(--border-strong)'}`,
                background: tabFluides === val ? '#dbeafe' : 'var(--bg-panel)',
                color: tabFluides === val ? '#1d4ed8' : 'var(--text-sub)', cursor: 'pointer',
              }}
            >{lbl}</button>
          ))}
        </div>
        {autres.map(({ key, label: lbl }) => {
          const suffix = tabFluides === 'entree' ? 'Entree' : 'Sortie';
          const fieldName = `${key}${suffix}Desc`;
          return (
            <Field key={key} label={lbl} name={fieldName} value={form[fieldName]} onChange={ch}
              textarea placeholder="Descriptif et état..." />
          );
        })}
        <div style={grid2}>
          <Field label="Nombre de clés (entrée)" name="cleNbEntree" value={form.cleNbEntree} onChange={ch} placeholder="Ex: 2" />
          <Field label="Nombre de clés (sortie)" name="cleNbSortie" value={form.cleNbSortie} onChange={ch} placeholder="Ex: 2" />
        </div>
      </Section>

      {/* Observations */}
      <Section title="Observations particulières" icon={<FileText size={16} />}>
        <Field label="Observations entrée" name="observationsEntree" value={form.observationsEntree}
          onChange={ch} textarea placeholder="Observations à l'entrée..." />
        <Field label="Observations sortie" name="observationsSortie" value={form.observationsSortie}
          onChange={ch} textarea placeholder="Observations à la sortie..." />
      </Section>

      {/* Signatures terrain */}
      <Section title="Signatures" icon={<PenTool size={16} />}>
        <VisitFields mode="entrant"><div style={grid2}>
          <Field label="Grand-Lyon / Propriétaire (entrée)" name="sigEntreeProprietaire"
            value={form.sigEntreeProprietaire} onChange={ch} placeholder="Nom" />
          <Field label="Locataire (entrée)" name="sigEntreeLocataire"
            value={form.sigEntreeLocataire} onChange={ch} placeholder="Nom" />
        </div></VisitFields>
        <VisitFields mode="entrant"><div style={grid2}>
          <SignaturePad label="Signature propriétaire (entrée)" value={form.sigImgEntreeProprietaire || ''} onChange={v => onChange('sigImgEntreeProprietaire', v)} user={user} onChangeMeta={m => onChange('sigMetaEntreeProprietaire', m)} />
          <SignaturePad label="Signature locataire (entrée)" value={form.sigImgEntreeLocataire || ''} onChange={v => onChange('sigImgEntreeLocataire', v)} user={user} signerInfo={{ nom: form.sigEntreeLocataire || form.locNom || '' }} onChangeMeta={m => onChange('sigMetaEntreeLocataire', m)} />
        </div></VisitFields>
        <VisitFields mode="sortant"><div style={grid2}>
          <Field label="Grand-Lyon / Propriétaire (sortie)" name="sigSortieProprietaire"
            value={form.sigSortieProprietaire} onChange={ch} placeholder="Nom" />
          <Field label="Locataire (sortie)" name="sigSortieLocataire"
            value={form.sigSortieLocataire} onChange={ch} placeholder="Nom" />
        </div></VisitFields>
        <VisitFields mode="sortant"><div style={grid2}>
          <SignaturePad label="Signature propriétaire (sortie)" value={form.sigImgSortieProprietaire || ''} onChange={v => onChange('sigImgSortieProprietaire', v)} user={user} onChangeMeta={m => onChange('sigMetaSortieProprietaire', m)} />
          <SignaturePad label="Signature locataire (sortie)" value={form.sigImgSortieLocataire || ''} onChange={v => onChange('sigImgSortieLocataire', v)} user={user} signerInfo={{ nom: form.sigSortieLocataire || form.locNom || '' }} onChangeMeta={m => onChange('sigMetaSortieLocataire', m)} />
        </div></VisitFields>
      </Section>
    </>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// COMPOSANTS PÉPINIÈRE
// ════════════════════════════════════════════════════════════════════════════

// Labels des options de constatation
const OPT_LABELS = {
  tresbon: 'TB', bon: 'Bon', usure: 'Usure normale', refaire: 'À refaire',
  casse: 'Cassé(e)', remplacer: 'À remplacer', reparer: 'À réparer',
};

// ── Ligne de constatation (étiquette + boutons d'état + note) ─────────────
function ConstatationRow({ itemLabel, value = { etat: '', note: '' }, onChange, options }) {
  return (
    <div style={{ borderBottom: '1px solid var(--border)', paddingBottom: '10px', marginBottom: '10px' }}>
      <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: '8px', marginBottom: '6px' }}>
        <span style={{ fontSize: '14px', fontWeight: '600', color: 'var(--text)', minWidth: '140px' }}>
          {itemLabel}
        </span>
        <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
          {options.map(opt => (
            <button key={opt} type="button"
              onClick={() => onChange({ ...value, etat: value.etat === opt ? '' : opt })}
              style={{
                padding: '4px 10px', borderRadius: '16px', fontSize: '12px', fontWeight: '600',
                border: `2px solid ${value.etat === opt ? '#2563eb' : 'var(--border-strong)'}`,
                background: value.etat === opt ? '#dbeafe' : 'var(--bg-panel)',
                color: value.etat === opt ? '#1d4ed8' : 'var(--text-sub)',
                cursor: 'pointer', transition: 'all 0.12s',
              }}
            >{OPT_LABELS[opt]}</button>
          ))}
        </div>
      </div>
      <input
        type="text"
        value={value.note || ''}
        onChange={e => onChange({ ...value, note: e.target.value })}
        placeholder="Observations…"
        style={{ ...inp, fontSize: '13px', padding: '7px 10px' }}
      />
    </div>
  );
}

// ── Tableau clés / badges ─────────────────────────────────────────────────
function ClesTable({ cles, onChange }) {
  const update = (i, field, val) => {
    const arr = [...cles];
    arr[i] = { ...arr[i], [field]: val };
    onChange(arr);
  };
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
        <thead>
          <tr style={{ background: 'var(--bg-panel)' }}>
            <th style={{ textAlign: 'left', padding: '8px 10px', borderBottom: '2px solid var(--border)', fontWeight: '700', color: 'var(--text)' }}>Désignation</th>
            <th style={{ textAlign: 'center', padding: '8px 10px', borderBottom: '2px solid var(--border)', fontWeight: '700', color: 'var(--text)', width: '90px' }}>Nombre</th>
            <th style={{ textAlign: 'left', padding: '8px 10px', borderBottom: '2px solid var(--border)', fontWeight: '700', color: 'var(--text)', width: '120px' }}>État</th>
          </tr>
        </thead>
        <tbody>
          {cles.map((cle, i) => (
            <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
              <td style={{ padding: '6px 10px', color: 'var(--text)' }}>{cle.libelle}</td>
              <td style={{ padding: '4px 6px', textAlign: 'center' }}>
                <input type="number" min="0" value={cle.nombre}
                  onChange={e => update(i, 'nombre', e.target.value)}
                  style={{ ...inp, textAlign: 'center', padding: '5px', width: '60px' }} />
              </td>
              <td style={{ padding: '4px 6px' }}>
                <input type="text" value={cle.etat} placeholder="—"
                  onChange={e => update(i, 'etat', e.target.value)}
                  style={{ ...inp, padding: '5px 8px', fontSize: '13px' }} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Entête fixe Métropole (texte légal) ───────────────────────────────────
function BlockMetropole({ representant, onRepresentantChange }) {
  return (
    <div style={{ fontSize: '13px', lineHeight: '1.6', color: 'var(--text)' }}>
      <p style={{ margin: '0 0 8px' }}>
        <strong>La Métropole de Lyon,</strong> collectivité territoriale à statut particulier, identifiée
        sous le numéro SIREN <strong>200 046 977</strong>, ayant son siège social Hôtel de la Métropole,
        20 rue du Lac, 69003 Lyon.
      </p>
      <div>
        <label style={label}>Représentée par *</label>
        <input
          type="text"
          value={representant}
          onChange={e => onRepresentantChange(e.target.value)}
          placeholder="Prénom NOM, Direction Patrimoine et Maintenance, Gestion Locative"
          style={inp}
        />
      </div>
    </div>
  );
}

// ── Items de constatation par type ─────────────────────────────────────────
const ITEMS_BUREAU = [
  { key: 'portEntree',      label: "Porte d'entrée",        opts: ['tresbon','bon','usure','refaire']    },
  { key: 'videophone',      label: 'Vidéophone',             opts: ['tresbon','bon','reparer','remplacer'] },
  { key: 'sol',             label: 'Sol',                    opts: ['tresbon','bon','usure','refaire']    },
  { key: 'murs',            label: 'Murs',                   opts: ['tresbon','bon','usure','refaire']    },
  { key: 'plafond',         label: 'Plafond',                opts: ['tresbon','bon','usure','refaire']    },
  { key: 'plinthes',        label: 'Plinthes',               opts: ['tresbon','bon','usure','refaire']    },
  { key: 'fenetre',         label: 'Fenêtre',                opts: ['tresbon','bon','casse','remplacer']  },
  { key: 'store',           label: 'Store',                  opts: ['tresbon','bon','casse','remplacer']  },
  { key: 'tabletteFenetre', label: 'Tablettes de fenêtres',  opts: ['tresbon','bon','usure','refaire']    },
  { key: 'interrupteurs',   label: 'Interrupteurs',          opts: ['tresbon','bon','usure','remplacer']  },
  { key: 'prisesCourant',   label: 'Prises de courant',      opts: ['tresbon','bon','usure','remplacer']  },
  { key: 'radiateur',       label: 'Radiateur',              opts: ['tresbon','bon','reparer','remplacer'] },
  { key: 'boiteAuxLettres', label: 'Boîtes à lettres',       opts: ['tresbon','bon','reparer','remplacer'] },
];

const ITEMS_ATELIER = [
  { key: 'sol',              label: 'Sol',                opts: ['tresbon','bon','usure','refaire']    },
  { key: 'murs',             label: 'Murs',               opts: ['tresbon','bon','usure','refaire']    },
  { key: 'plafond',          label: 'Plafond',            opts: ['tresbon','bon','usure','refaire']    },
  { key: 'fenetre',          label: 'Fenêtre',            opts: ['tresbon','bon','casse','remplacer']  },
  { key: 'portEntree',       label: "Porte d'entrée",     opts: ['tresbon','bon','reparer','remplacer']},
  { key: 'porteSectionnelle',label: 'Porte sectionnelle', opts: ['tresbon','bon','reparer','remplacer']},
  { key: 'portail',          label: 'Portail',            opts: ['tresbon','bon','reparer','remplacer']},
  { key: 'interrupteurs',    label: 'Interrupteurs',      opts: ['tresbon','bon','reparer','remplacer']},
  { key: 'prisesCourant',    label: 'Prises de courant',  opts: ['tresbon','bon','reparer','remplacer']},
  { key: 'aerotherme',       label: 'Aérotherme',         opts: ['tresbon','bon','casse','remplacer']  },
  { key: 'vidoirs',          label: 'Vidoirs',            opts: ['tresbon','bon','casse','remplacer']  },
  { key: 'sousCompteurs',    label: 'Sous-compteurs',     opts: ['tresbon','bon','casse','remplacer']  },
];

const ITEMS_BUREAU_ATELIER = [
  { key: 'sol',           label: 'Sol',               opts: ['tresbon','bon','usure','refaire']   },
  { key: 'murs',          label: 'Murs',              opts: ['tresbon','bon','usure','refaire']   },
  { key: 'plafond',       label: 'Plafond',           opts: ['tresbon','bon','usure','refaire']   },
  { key: 'plinthes',      label: 'Plinthes',          opts: ['tresbon','bon','usure','remplacer'] },
  { key: 'vitres',        label: 'Vitres',            opts: ['tresbon','bon','casse','remplacer'] },
  { key: 'interrupteurs', label: 'Interrupteurs',     opts: ['tresbon','bon','usure','remplacer'] },
  { key: 'prisesCourant', label: 'Prises de courant', opts: ['tresbon','bon','usure','remplacer'] },
  { key: 'portEntree',    label: "Porte d'entrée",    opts: ['tresbon','bon','usure','refaire']   },
];

// ── Bloc commun : locataire + généralités (identique pour bureau & atelier) ─
function BlockLocataire({ form, onChange }) {
  const ch = (name, val) => onChange(name, val);
  const OUI_NON = [{ value: 'entree', label: '↩ Entrée' }, { value: 'sortie', label: '↪ Sortie' }];

  // Un seul appel — le reset de localNumero/localSurface est géré dans handleField du parent
  const handlePepiniere = (id) => {
    ch('pepiniereId', id);
  };

  return (
    <>
      {/* Type d'EDL */}
      <Section title="Type d'état des lieux" icon={<ClipboardList size={16} />} defaultOpen>
        <div style={{ display: 'flex', gap: '10px' }}>
          {OUI_NON.filter(opt => !isSingleVisit(form) || opt.value === form.typeEDL).map(opt => (
            <button key={opt.value} type="button"
              onClick={() => ch('typeEDL', opt.value)}
              style={{
                flex: 1, padding: '14px', borderRadius: '12px', border: '2px solid',
                borderColor: form.typeEDL === opt.value ? '#2563eb' : 'var(--border-strong)',
                background: form.typeEDL === opt.value ? '#dbeafe' : 'var(--bg-panel)',
                color: form.typeEDL === opt.value ? '#1d4ed8' : 'var(--text-sub)',
                cursor: 'pointer', fontWeight: '700', fontSize: '15px',
                transition: 'all 0.15s',
              }}
            >{opt.label}</button>
          ))}
        </div>
        <div style={grid2}>
          <Field label="Date de l'EDL" name="dateEDL" type="date" value={form.dateEDL}
            onChange={e => ch('dateEDL', e.target.value)} />
          <Field label="Lieu de signature" name="lieuSignature" value={form.lieuSignature || 'Lyon'}
            onChange={e => ch('lieuSignature', e.target.value)} />
        </div>
      </Section>

      {/* Pôle */}
      <Section title="Pôle LYVE" icon={<Leaf size={16} />} defaultOpen>
        <div>
          <label style={label}>Choisir le pôle</label>
          <select
            value={form.pepiniereId || ''}
            onChange={e => handlePepiniere(e.target.value)}
            style={inp}
          >
            <option value="">— Sélectionner une pépinière —</option>
            {PEPINIERES_DATA.map(p => (
              <option key={p.id} value={p.id}>{p.label} — {p.adresse}</option>
            ))}
          </select>
        </div>
      </Section>

      {/* Métropole */}
      <Section title="La Métropole de Lyon" icon={<Landmark size={16} />} defaultOpen>
        <BlockMetropole
          representant={form.metropoleRepresentant}
          onRepresentantChange={v => ch('metropoleRepresentant', v)}
        />
      </Section>

      {/* Locataire */}
      <Section title="Entité locative" icon={<Building2 size={16} />} defaultOpen>
        <Field label="Nom de l'entreprise" name="locEntreprise" value={form.locEntreprise}
          onChange={e => ch('locEntreprise', e.target.value)} placeholder="Raison sociale" />
        <div style={grid2}>
          <Field label="N° SIREN" name="locSiren" value={form.locSiren}
            onChange={e => ch('locSiren', e.target.value)} placeholder="000 000 000" />
          <Field label="Représentant(e)" name="locRepresentant" value={form.locRepresentant}
            onChange={e => ch('locRepresentant', e.target.value)} placeholder="Prénom NOM" />
        </div>
        <Field label="Adresse" name="locAdresse" value={form.locAdresse}
          onChange={e => ch('locAdresse', e.target.value)} placeholder="N° rue" />
        <div style={grid2}>
          <Field label="Code postal" name="locCp" value={form.locCp}
            onChange={e => ch('locCp', e.target.value)} placeholder="69000" />
          <Field label="Ville" name="locVille" value={form.locVille}
            onChange={e => ch('locVille', e.target.value)} placeholder="Lyon" />
        </div>
      </Section>
    </>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// FORM PÉPINIÈRE — BUREAU
// ════════════════════════════════════════════════════════════════════════════
function FormPepiniereBureau({ form, onChange, user }) {
  const ch = (name, val) => onChange(name, val);

  const updateConstat = (key, val) =>
    ch('constatations', { ...form.constatations, [key]: val });

  const isSortie = form.typeEDL === 'sortie';
  const pepiniere = PEPINIERES_DATA.find(p => p.id === form.pepiniereId) || null;

  const handleBureau = (num) => {
    ch('localNumero', num); // surface auto-remplie dans handleField
  };

  return (
    <>
      <BlockLocataire form={form} onChange={ch} />

      {/* Descriptif du local */}
      <Section title="Descriptif du local" icon={<MapPin size={16} />}>
        {pepiniere ? (
          <div style={grid2}>
            <div>
              <label style={label}>Bureau</label>
              <select style={inp} value={form.localNumero || ''} onChange={e => handleBureau(e.target.value)}>
                <option value="">— Choisir un bureau —</option>
                {pepiniere.bureaux.map(b => (
                  <option key={b.num} value={b.num}>
                    Bureau {b.num} — {b.surface} m²
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label style={label}>Surface (m²)</label>
              <div style={{
                ...inp, background: 'var(--bg-panel)', color: '#166534',
                fontWeight: '700', borderColor: form.localSurface ? '#16a34a' : 'var(--border)',
              }}>
                {form.localSurface ? `${form.localSurface} m²` : '— sélectionner un bureau'}
              </div>
            </div>
          </div>
        ) : (
          <div style={grid2}>
            <Field label="Numéro du bureau" name="localNumero" value={form.localNumero}
              onChange={e => ch('localNumero', e.target.value)} placeholder="Ex : 8" />
            <Field label="Surface (m²)" name="localSurface" value={form.localSurface}
              onChange={e => ch('localSurface', e.target.value)} placeholder="Ex : 95" />
          </div>
        )}
        {isSortie && (
          <Field label="Nouvelle adresse du locataire" name="nouvelleAdresse"
            value={form.nouvelleAdresse} textarea
            onChange={e => ch('nouvelleAdresse', e.target.value)}
            placeholder="Adresse complète après déménagement…" />
        )}
      </Section>

      {/* Constatations */}
      <Section title={`Constatations — Local bureau n°${form.localNumero || '…'}`} icon={<Search size={16} />} defaultOpen>
        {ITEMS_BUREAU.map(({ key, label: lbl, opts }) => (
          <ConstatationRow
            key={key}
            itemLabel={lbl}
            value={form.constatations?.[key]}
            options={opts}
            onChange={val => updateConstat(key, val)}
          />
        ))}
        <div>
          <label style={label}>Autres équipements / modifications</label>
          <textarea
            value={form.autresEquipements || ''}
            onChange={e => ch('autresEquipements', e.target.value)}
            placeholder="Décrire tout autre équipement ou modification constatée…"
            rows={3}
            style={{ ...inp, resize: 'vertical' }}
          />
        </div>
      </Section>

      {/* Clés / Badges */}
      <Section title="Clés / Badges / Accès" icon={<Key size={16} />}>
        <ClesTable cles={form.cles || []} onChange={v => ch('cles', v)} />
      </Section>

      {/* Signatures */}
      <Section title="Signatures" icon={<PenTool size={16} />}>
        <div style={grid2}>
          <Field label="L'occupant (entreprise)" name="sigLocataire" value={form.sigLocataire}
            onChange={e => ch('sigLocataire', e.target.value)} placeholder="Nom & prénom" />
          <Field label="La Métropole de Lyon" name="sigMetropole" value={form.sigMetropole}
            onChange={e => ch('sigMetropole', e.target.value)} placeholder="Nom & prénom" />
        </div>
        <div style={grid2}>
          <SignaturePad label="Signature occupant" value={form.sigImgLocataire || ''} onChange={v => ch('sigImgLocataire', v)} user={user} signerInfo={{ nom: form.sigLocataire || form.locRepresentant || form.locEntreprise || '' }} onChangeMeta={m => ch('sigMetaLocataire', m)} />
          <SignaturePad label="Signature Métropole" value={form.sigImgMetropole || ''} onChange={v => ch('sigImgMetropole', v)} user={user} onChangeMeta={m => ch('sigMetaMetropole', m)} />
        </div>
      </Section>
    </>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// FORM PÉPINIÈRE — ATELIER
// ════════════════════════════════════════════════════════════════════════════
function FormPepinieraAtelier({ form, onChange, user }) {
  const ch = (name, val) => onChange(name, val);

  const updateConstatAtelier = (key, val) =>
    ch('constatationsAtelier', { ...form.constatationsAtelier, [key]: val });

  const updateConstatBureau = (key, val) =>
    ch('constatationsBureau', { ...form.constatationsBureau, [key]: val });

  const isSortie = form.typeEDL === 'sortie';
  const pepiniere = PEPINIERES_DATA.find(p => p.id === form.pepiniereId) || null;

  const handleAtelier = (num) => {
    ch('localNumero', num); // surface auto-remplie dans handleField
  };

  return (
    <>
      <BlockLocataire form={form} onChange={ch} />

      {/* Descriptif du local */}
      <Section title="Descriptif du local" icon={<MapPin size={16} />}>
        {pepiniere ? (
          <div style={grid2}>
            <div>
              <label style={label}>Atelier</label>
              <select style={inp} value={form.localNumero || ''} onChange={e => handleAtelier(e.target.value)}>
                <option value="">— Choisir un atelier —</option>
                {pepiniere.ateliers.map(a => (
                  <option key={a.num} value={a.num}>
                    Atelier {a.num} — {a.surface} m²
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label style={label}>Surface (m²)</label>
              <div style={{
                ...inp, background: 'var(--bg-panel)', color: '#166534',
                fontWeight: '700', borderColor: form.localSurface ? '#16a34a' : 'var(--border)',
              }}>
                {form.localSurface ? `${form.localSurface} m²` : '— sélectionner un atelier'}
              </div>
            </div>
          </div>
        ) : (
          <div style={grid2}>
            <Field label="Numéro de l'atelier" name="localNumero" value={form.localNumero}
              onChange={e => ch('localNumero', e.target.value)} placeholder="Ex : 8" />
            <Field label="Surface (m²)" name="localSurface" value={form.localSurface}
              onChange={e => ch('localSurface', e.target.value)} placeholder="Ex : 95" />
          </div>
        )}
        {isSortie && (
          <Field label="Nouvelle adresse du locataire" name="nouvelleAdresse"
            value={form.nouvelleAdresse} textarea
            onChange={e => ch('nouvelleAdresse', e.target.value)}
            placeholder="Adresse complète après déménagement…" />
        )}
      </Section>

      {/* Constatations Atelier */}
      <Section title={`Constatations — Atelier n°${form.localNumero || '…'}`} icon={<Search size={16} />} defaultOpen>
        {ITEMS_ATELIER.map(({ key, label: lbl, opts }) => (
          <ConstatationRow
            key={key}
            itemLabel={lbl}
            value={form.constatationsAtelier?.[key]}
            options={opts}
            onChange={val => updateConstatAtelier(key, val)}
          />
        ))}
        <div>
          <label style={label}>Autres équipements / modifications (atelier)</label>
          <textarea
            value={form.autresEquipementsAtelier || ''}
            onChange={e => ch('autresEquipementsAtelier', e.target.value)}
            placeholder="Décrire tout autre équipement ou modification…"
            rows={3}
            style={{ ...inp, resize: 'vertical' }}
          />
        </div>
      </Section>

      {/* Constatations Bureau de l'atelier */}
      <Section title={`Bureau de l'atelier n°${form.localNumero || '…'}`} icon={<Search size={16} />} defaultOpen>
        {ITEMS_BUREAU_ATELIER.map(({ key, label: lbl, opts }) => (
          <ConstatationRow
            key={key}
            itemLabel={lbl}
            value={form.constatationsBureau?.[key]}
            options={opts}
            onChange={val => updateConstatBureau(key, val)}
          />
        ))}
        <div>
          <label style={label}>Autres équipements / modifications (bureau)</label>
          <textarea
            value={form.autresEquipementsBureau || ''}
            onChange={e => ch('autresEquipementsBureau', e.target.value)}
            placeholder="Décrire tout autre équipement ou modification…"
            rows={3}
            style={{ ...inp, resize: 'vertical' }}
          />
        </div>
      </Section>

      {/* Clés / Badges */}
      <Section title="Clés / Badges / Accès" icon={<Key size={16} />}>
        <ClesTable cles={form.cles || []} onChange={v => ch('cles', v)} />
      </Section>

      {/* Relevé des compteurs */}
      <Section title="Relevé des compteurs" icon={<BarChart3 size={16} />}>
        <Field label="Date de lecture" name="dateLectureCompteurs" type="date"
          value={form.dateLectureCompteurs}
          onChange={e => ch('dateLectureCompteurs', e.target.value)} />
        {[
          { prefix: 'compteurChauffage', label: 'Chauffage', unite: 'kWh' },
          { prefix: 'compteurEau',       label: 'Eau',        unite: 'm³'  },
          { prefix: 'compteurElec',      label: 'Électricité', unite: 'kWh' },
        ].map(({ prefix, label: lbl, unite }) => (
          <div key={prefix} style={{ border: '1px solid var(--border)', borderRadius: '10px', padding: '12px' }}>
            <div style={{ fontSize: '13px', fontWeight: '700', color: 'var(--text-sub)', marginBottom: '10px' }}>
              {lbl}
            </div>
            <div style={grid2}>
              <Field label={`N° compteur`} name={`${prefix}Num`} value={form[`${prefix}Num`] || ''}
                onChange={e => ch(`${prefix}Num`, e.target.value)} placeholder="—" />
              <Field label={`Index (${unite})`} name={`${prefix}Val`} value={form[`${prefix}Val`] || ''}
                onChange={e => ch(`${prefix}Val`, e.target.value)} placeholder="0" />
            </div>
          </div>
        ))}
      </Section>

      {/* Local box */}
      <Section title="Local box" icon={<Package size={16} />}>
        <div style={grid2}>
          <Field label="Numéro du box" name="localBoxNumero" value={form.localBoxNumero || ''}
            onChange={e => ch('localBoxNumero', e.target.value)} placeholder="Ex : 8" />
          <div />
        </div>
        <ConstatationRow
          itemLabel="État du local box"
          value={form.localBoxEtat || { etat: '', note: '' }}
          options={['bon', 'usure', 'refaire']}
          onChange={val => ch('localBoxEtat', val)}
        />
      </Section>

      {/* Signatures */}
      <Section title="Signatures" icon={<PenTool size={16} />}>
        <div style={grid2}>
          <Field label="L'occupant (entreprise)" name="sigLocataire" value={form.sigLocataire}
            onChange={e => ch('sigLocataire', e.target.value)} placeholder="Nom & prénom" />
          <Field label="La Métropole de Lyon" name="sigMetropole" value={form.sigMetropole}
            onChange={e => ch('sigMetropole', e.target.value)} placeholder="Nom & prénom" />
        </div>
        <div style={grid2}>
          <SignaturePad label="Signature occupant" value={form.sigImgLocataire || ''} onChange={v => ch('sigImgLocataire', v)} user={user} signerInfo={{ nom: form.sigLocataire || form.locRepresentant || form.locEntreprise || '' }} onChangeMeta={m => ch('sigMetaLocataire', m)} />
          <SignaturePad label="Signature Métropole" value={form.sigImgMetropole || ''} onChange={v => ch('sigImgMetropole', v)} user={user} onChangeMeta={m => ch('sigMetaMetropole', m)} />
        </div>
      </Section>
    </>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN FORM EXPORT
// ════════════════════════════════════════════════════════════════════════════
export default function EDLForm({ form, onChange, onSave, onCancel, isEditing, utilisateurs, userProfile, user }) {
  const isTerrain   = form.typeBien === 'terrain';
  const isBureau    = form.typeBien === 'pepiniere_bureau';
  const isAtelier   = form.typeBien === 'pepiniere_atelier';
  const isLocalType = isLocal(form.typeBien);

  // ── Hook éditeur photo (annotations) ────────────────────────────────────
  const sauvegarderStub = () => {};
  const {
    isEditorOpen, setIsEditorOpen, imgSize, setImgSize,
    canvasRef, setIsDrawing, penColor, setPenColor,
    effacerDessin, draw, handleMouseDown, ouvrirEditeur,
  } = useImageEditor(sauvegarderStub);
  const [photoEnCours, setPhotoEnCours] = useState(null);
  const [photoZoom, setPhotoZoom] = useState(null);

  const ouvrirAnnotation = (index) => {
    setPhotoEnCours(index);
    const imgEl = document.createElement('img');
    imgEl.src = form.photos[index].src;
    ouvrirEditeur(imgEl);
  };

  const validerAnnotation = () => {
    if (photoEnCours !== null && canvasRef.current) {
      const newSrc = canvasRef.current.toDataURL('image/jpeg', 0.85);
      const photos = [...(form.photos || [])];
      photos[photoEnCours] = { ...photos[photoEnCours], src: newSrc };
      onChange({ ...form, photos });
    }
    setIsEditorOpen(false);
    setPhotoEnCours(null);
  };

  // Groupes de types ayant des modèles de données compatibles entre eux
  const LOGEMENT_TYPES = ['maison', 'appartement'];

  const handleField = (name, value) => {
    if (isSingleVisit(form) && (name === 'typeEDL' || name === 'typeBien')) return;
    if (name === 'typeBien') {
      const wasLogement = LOGEMENT_TYPES.includes(form.typeBien);
      const isLogement  = LOGEMENT_TYPES.includes(value);
      if (wasLogement && isLogement) {
        // Même famille : on garde toutes les données, on change juste le type
        onChange({ ...form, typeBien: value });
      } else {
        // Changement de famille : réinitialiser avec les valeurs par défaut du nouveau type
        const newInitial = getInitialByType(value, userProfile);
        onChange({ ...newInitial, partageAvec: form.partageAvec || [] });
      }
    } else if (name === 'pepiniereId') {
      // Changement de pépinière : réinitialiser le local + compteurs en une seule mise à jour atomique
      const pepReset = { pepiniereId: value, localNumero: '', localSurface: '' };
      if (form.typeBien === 'pepiniere_atelier') {
        pepReset.compteurEauNum = '';
        pepReset.compteurElecNum = '';
      }
      onChange({ ...form, ...pepReset });
    } else if (name === 'localNumero') {
      // Auto-fill surface + compteurs depuis les données pépinière — mise à jour atomique
      const pep = PEPINIERES_DATA.find(p => p.id === form.pepiniereId);
      const updates = { localNumero: value, localSurface: '' };
      if (pep && value) {
        const isAtelier = form.typeBien === 'pepiniere_atelier';
        const items = isAtelier ? pep.ateliers : pep.bureaux;
        const found = items.find(i => i.num === value);
        if (found) {
          updates.localSurface = String(found.surface);
          // Auto-remplir les numéros de compteurs pour les ateliers
          if (isAtelier) {
            if (found.compteurEau) updates.compteurEauNum = found.compteurEau;
            if (found.pdlElec)     updates.compteurElecNum = found.pdlElec;
          }
        }
      }
      // Si on vide la sélection, réinitialiser aussi les compteurs
      if (!value && form.typeBien === 'pepiniere_atelier') {
        updates.compteurEauNum = '';
        updates.compteurElecNum = '';
      }
      onChange({ ...form, ...updates });
    } else if (name.startsWith('sigImg')) {
      // Auto-remplir la date de signature si elle n'est pas encore renseignée
      const today = new Date().toISOString().split('T')[0];
      const updates = { [name]: value };
      if ((name === 'sigImgLocataire' || name === 'sigImgMetropole') && !form.dateSignature) {
        updates.dateSignature = today;
      } else if ((name === 'sigImgProprietaireEntrant' || name === 'sigImgLocataireEntrant') && !form.dateSignatureEntrant) {
        updates.dateSignatureEntrant = today;
      } else if ((name === 'sigImgProprietaireSortant' || name === 'sigImgLocataireSortant') && !form.dateSignatureSortant) {
        updates.dateSignatureSortant = today;
      }
      // Si la signature est effacée, supprimer aussi les métadonnées associées
      // Si la signature est effacée, supprimer aussi les métadonnées associées
      if (!value) {
        const metaKey = name.replace('sigImg', 'sigMeta');
        updates[metaKey] = null;
      }
      // ⚠️ Mise à jour fonctionnelle : évite l'écrasement par onChangeMeta appelé juste après
      onChange(prev => ({ ...prev, ...updates }));
    } else {
      // ⚠️ Mise à jour fonctionnelle : garantit qu'on part toujours du dernier état
      onChange(prev => ({ ...prev, [name]: value }));
    }
  };
  const handlePieces = (pieces) => onChange(prev => ({ ...prev, pieces }));

  // ── Gestion des photos ────────────────────────────────────────────────────
  const compresserImage = (file) => compressedPhotoDataUrl(file, 1400, 0.8);

  const ajouterPhoto = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    e.target.value = '';
    try {
      const src = await compresserImage(file);
      onChange(prev => ({ ...prev, photos: [...(Array.isArray(prev.photos) ? prev.photos : []), { src, legende: '' }] }));
    } catch {
      alert('Impossible de charger la photo.');
    }
  };

  const supprimerPhoto = (index) => {
    const photos = (form.photos || []).filter((_, i) => i !== index);
    onChange({ ...form, photos });
  };

  const modifierLegende = (index, legende) => {
    const photos = (form.photos || []).map((p, i) => i === index ? { ...p, legende } : p);
    onChange({ ...form, photos });
  };

  return (
    <VisitContext.Provider value={isSingleVisit(form) ? visitMode(form) : null}>
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0' }}>
      {/* En-tête dans le flux : ne masque pas les champs pendant la saisie. */}
      <div style={{
        position: 'static',
        background: '#0f1629', padding: '12px 16px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        borderBottom: '1px solid #1e293b',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button type="button" onClick={onCancel}
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '4px' }}>
            <X size={20} />
          </button>
          <span style={{ color: '#f1f5f9', fontWeight: '700', fontSize: '15px' }}>
            {isEditing ? "Modifier l'EDL" : 'Nouvel EDL'}
          </span>
        </div>
        <button type="button" onClick={onSave}
          style={{
            display: 'flex', alignItems: 'center', gap: '7px',
            padding: '9px 18px', background: '#2563eb', color: 'white',
            border: 'none', borderRadius: '10px', cursor: 'pointer',
            fontWeight: '700', fontSize: '14px',
          }}
        >
          <Save size={15} /> {isEditing ? 'Mettre à jour' : 'Enregistrer'}
        </button>
      </div>

      {/* Corps du formulaire */}
      <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '0' }}>

        {/* Sélecteur historique uniquement : le type dédié est déjà indiqué dans le bandeau. */}
        {!isSingleVisit(form) && <div style={{ ...section, marginBottom: '12px' }}>
          <div style={{ padding: '16px' }}>
            <label style={label}>Type de bien *</label>
            {(() => {
              const ICONS = { maison: Home, appartement: Building2, entrepot: Warehouse, terrain: TreePine };
              return (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginTop: '8px' }}>
                  {TYPES_BIEN.filter(t => t.groupe !== 'pepiniere' && (!isSingleVisit(form) || t.value === form.typeBien)).map(t => {
                    const active = form.typeBien === t.value;
                    const TIcon = ICONS[t.value];
                    return (
                      <button key={t.value} type="button"
                        onClick={() => handleField('typeBien', t.value)}
                        style={{
                          padding: '12px 8px', borderRadius: '12px', border: '2px solid',
                          borderColor: active ? '#2563eb' : 'var(--border-strong)',
                          background: active ? 'rgba(37,99,235,0.12)' : 'var(--bg-panel)',
                          color: active ? '#60a5fa' : 'var(--text-sub)',
                          cursor: 'pointer', fontWeight: '700', fontSize: '13px',
                          transition: 'all 0.15s', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px',
                        }}
                      >
                        {TIcon && <TIcon size={15} />}{t.label}
                      </button>
                    );
                  })}
                </div>
              );
            })()}
            <div style={{ marginTop: '6px', fontSize: '11px', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: '4px' }}>
              Pépinière d'entreprises
            </div>
            {(() => {
              const PEP_ICONS = { pepiniere_bureau: Briefcase, pepiniere_atelier: Wrench };
              return (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                  {TYPES_BIEN.filter(t => t.groupe === 'pepiniere' && (!isSingleVisit(form) || t.value === form.typeBien)).map(t => {
                    const active = form.typeBien === t.value;
                    const TIcon = PEP_ICONS[t.value];
                    return (
                      <button key={t.value} type="button"
                        onClick={() => handleField('typeBien', t.value)}
                        style={{
                          padding: '12px 8px', borderRadius: '12px', border: '2px solid',
                          borderColor: active ? '#059669' : 'var(--border-strong)',
                          background: active ? 'rgba(6,95,70,0.12)' : 'var(--bg-panel)',
                          color: active ? '#34d399' : 'var(--text-sub)',
                          cursor: 'pointer', fontWeight: '700', fontSize: '13px',
                          transition: 'all 0.15s', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px',
                        }}
                      >
                        {TIcon && <TIcon size={15} />}{t.label}
                      </button>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        </div>}

        {isBureau
          ? <FormPepiniereBureau form={form} onChange={handleField} user={user} />
          : isAtelier
            ? <FormPepinieraAtelier form={form} onChange={handleField} user={user} />
            : isTerrain
              ? <FormTerrain form={form} onChange={handleField} user={user} />
              : isLocalType
                ? <FormLocal form={form} onChange={handleField} onPiecesChange={handlePieces} user={user} />
                : <FormLogement form={form} onChange={handleField} onPiecesChange={handlePieces} user={user} />
        }

        {/* ── Photos ──────────────────────────────────────────────────────── */}
        <Section title="Photos" icon={<Camera size={16} />}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
            <span style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
              {(form.photos || []).length} photo{(form.photos || []).length !== 1 ? 's' : ''}
            </span>
            <button type="button"
              style={{
                padding: '8px 16px', background: '#2563eb', color: 'white',
                border: 'none', borderRadius: '8px', cursor: 'pointer',
                fontSize: '13px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px',
              }}
              onClick={() => document.getElementById('edlPhotoInput').click()}>
              <Camera size={13} /> Ajouter une photo
            </button>
            <input
              type="file" id="edlPhotoInput" accept="image/*" capture="environment"
              style={{ display: 'none' }} onChange={ajouterPhoto}
            />
          </div>
          {(form.photos || []).length > 0 && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '12px' }}>
              {form.photos.map((photo, index) => (
                <div key={index} style={{ border: '1px solid var(--border)', borderRadius: '10px', overflow: 'hidden', background: 'var(--bg-card)' }}>
                  <div style={{ position: 'relative' }}>
                    <img src={photo.src} alt={`Photo ${index + 1}`}
                      style={{ width: '100%', height: '140px', objectFit: 'cover', display: 'block', cursor: 'pointer' }}
                      title="Cliquez pour agrandir · Double-cliquez pour annoter"
                      onClick={() => setPhotoZoom(index)}
                      onDoubleClick={(e) => { e.stopPropagation(); setPhotoZoom(null); ouvrirAnnotation(index); }} />
                    <div style={{ position: 'absolute', top: '6px', right: '6px', display: 'flex', gap: '4px' }}>
                      <button type="button" onClick={() => ouvrirAnnotation(index)}
                        style={{ background: 'rgba(0,0,0,0.55)', border: 'none', borderRadius: '6px', color: 'white', cursor: 'pointer', padding: '5px 7px', fontSize: '11px' }}
                        title="Annoter">
                        <Pencil size={13} />
                      </button>
                      <button type="button" onClick={() => supprimerPhoto(index)}
                        style={{ background: 'rgba(239,68,68,0.85)', border: 'none', borderRadius: '6px', color: 'white', cursor: 'pointer', padding: '5px 7px', fontSize: '11px' }}
                        title="Supprimer">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                  <div style={{ padding: '6px 8px' }}>
                    <input
                      type="text" value={photo.legende || ''}
                      onChange={e => modifierLegende(index, e.target.value)}
                      placeholder={`Légende photo ${index + 1}…`}
                      style={{
                        width: '100%', border: 'none', borderBottom: '1px solid var(--border)',
                        outline: 'none', fontSize: '12px', padding: '3px 0',
                        background: 'transparent', boxSizing: 'border-box', color: 'var(--text)',
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Section>

        {/* Partage */}
        {utilisateurs?.length > 0 && (
          <Section title="Partager avec" icon={<Users size={16} />}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {utilisateurs.map(u => {
                const sel = Array.isArray(form.partageAvec) && form.partageAvec.includes(u);
                return (
                  <button key={u} type="button"
                    onClick={() => {
                      const arr = Array.isArray(form.partageAvec) ? form.partageAvec : [];
                      handleField('partageAvec', sel ? arr.filter(x => x !== u) : [...arr, u]);
                    }}
                    style={{
                      padding: '8px 16px', borderRadius: '20px', border: '2px solid',
                      borderColor: sel ? '#2563eb' : 'var(--border-strong)',
                      background: sel ? '#dbeafe' : 'var(--bg-panel)',
                      color: sel ? '#1d4ed8' : 'var(--text-sub)',
                      cursor: 'pointer', fontWeight: sel ? '700' : '400', fontSize: '13px',
                    }}
                  >{u}</button>
                );
              })}
            </div>
          </Section>
        )}

        {/* Bouton save mobile bas */}
        <button type="button" onClick={onSave}
          style={{
            width: '100%', padding: '15px', background: '#2563eb', color: 'white',
            border: 'none', borderRadius: '12px', cursor: 'pointer',
            fontWeight: '700', fontSize: '16px', marginTop: '8px',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
          }}
        >
          <Save size={18} /> {isEditing ? "Mettre à jour l'EDL" : "Enregistrer l'EDL"}
        </button>
      </div>

      {/* ── Modal zoom photo ──────────────────────────────────────────── */}
      {photoZoom !== null && form.photos?.[photoZoom] && (
        <div
          style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            background: 'rgba(0,0,0,0.85)', zIndex: 3000,
            display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column',
          }}
          onClick={() => setPhotoZoom(null)}
        >
          <img
            src={form.photos[photoZoom].src}
            alt={`Photo ${photoZoom + 1}`}
            style={{ maxWidth: '90vw', maxHeight: '80vh', borderRadius: '8px', objectFit: 'contain' }}
            onClick={e => e.stopPropagation()}
          />
          {form.photos[photoZoom].legende && (
            <p style={{ color: 'white', marginTop: '12px', fontSize: '14px' }}>{form.photos[photoZoom].legende}</p>
          )}
          <div style={{ position: 'absolute', top: '16px', right: '16px', display: 'flex', gap: '8px' }}>
            <button type="button" onClick={(e) => { e.stopPropagation(); setPhotoZoom(null); ouvrirAnnotation(photoZoom); }}
              style={{ background: 'rgba(255,255,255,0.15)', border: 'none', borderRadius: '8px', color: 'white', cursor: 'pointer', padding: '8px 14px', fontSize: '13px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Pencil size={14} /> Annoter
            </button>
            <button type="button" onClick={() => setPhotoZoom(null)}
              style={{ background: 'rgba(255,255,255,0.15)', border: 'none', borderRadius: '8px', color: 'white', cursor: 'pointer', padding: '8px 14px', fontSize: '18px' }}>
              <X size={18} />
            </button>
          </div>
        </div>
      )}

      {/* ── Éditeur d'annotation photo ────────────────────────────────── */}
      {isEditorOpen && (
        <div style={{
          position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
          background: 'rgba(0,0,0,0.8)', zIndex: 3100,
          display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column',
        }}>
          <div style={{
            background: 'var(--bg-card)', padding: '20px', borderRadius: '12px',
            display: 'flex', flexDirection: 'column', gap: '15px', maxWidth: '90vw',
            border: '1px solid var(--border)',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ margin: 0, color: 'var(--text)', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Pencil size={18} /> Annoter la photo
              </h3>
              <button type="button" onClick={() => { setIsEditorOpen(false); setPhotoEnCours(null); }}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: '4px' }}>
                <X size={22} />
              </button>
            </div>
            <div style={{ display: 'flex', gap: '15px', alignItems: 'center', flexWrap: 'wrap' }}>
              <label style={{ color: 'var(--text-sub)', fontSize: '13px' }}>Taille :</label>
              <input type="range" min="10" max="100" value={imgSize} onChange={e => setImgSize(e.target.value)} />
              <span style={{ color: 'var(--text-sub)', fontSize: '13px' }}>{imgSize}%</span>
              <div style={{ width: '2px', height: '20px', background: 'var(--border-strong)' }} />
              <label style={{ color: 'var(--text-sub)', fontSize: '13px' }}>Stylo :</label>
              <input type="color" value={penColor} onChange={e => setPenColor(e.target.value)} />
              <button type="button" onClick={effacerDessin}
                style={{
                  padding: '5px 12px', fontSize: '12px', borderRadius: '6px',
                  border: '1px solid var(--border-strong)', background: 'var(--bg-panel)',
                  color: 'var(--text-sub)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px',
                }}>
                <Trash2 size={12} /> Effacer
              </button>
            </div>
            <div style={{ border: '2px dashed var(--border-strong)', overflow: 'auto', maxHeight: '60vh', borderRadius: '6px' }}>
              <canvas ref={canvasRef} style={{ cursor: 'crosshair', maxWidth: '100%', width: `${imgSize}%` }}
                onMouseDown={handleMouseDown} onMouseMove={draw}
                onMouseUp={() => setIsDrawing(false)} onMouseOut={() => setIsDrawing(false)} />
            </div>
            <button type="button" onClick={validerAnnotation}
              style={{
                padding: '10px 20px', background: '#2563eb', color: 'white',
                border: 'none', borderRadius: '8px', cursor: 'pointer',
                fontWeight: '700', fontSize: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px',
              }}>
              <Save size={15} /> Valider l'annotation
            </button>
          </div>
        </div>
      )}
    </div>
    </VisitContext.Provider>
  );
}
