// src/features/edl/utils/edlDefaults.js

// ── 59 communes de la Métropole de Lyon (ordre alphabétique) ──────────────────
export const COMMUNES_METRO_LYON = [
  'Albigny-sur-Saône',
  'Bron',
  'Caluire-et-Cuire',
  "Champagne-au-Mont-d'Or",
  'Charbonnières-les-Bains',
  'Charly',
  'Chassieu',
  "Collonges-au-Mont-d'Or",
  'Corbas',
  "Couzon-au-Mont-d'Or",
  'Craponne',
  "Curis-au-Mont-d'Or",
  'Dardilly',
  'Décines-Charpieu',
  'Écully',
  'Feyzin',
  'Fleurieu-sur-Saône',
  'Fontaines-Saint-Martin',
  'Fontaines-sur-Saône',
  'Francheville',
  'Genay',
  'Givors',
  'Grigny',
  'Irigny',
  'Jonage',
  'Jons',
  'La Mulatière',
  'La Tour-de-Salvagny',
  'Limonest',
  'Lissieu',
  'Lyon 1er',
  'Lyon 2e',
  'Lyon 3e',
  'Lyon 4e',
  'Lyon 5e',
  'Lyon 6e',
  'Lyon 7e',
  'Lyon 8e',
  'Lyon 9e',
  "Marcy-l'Étoile",
  'Meyzieu',
  'Mions',
  'Montanay',
  'Neuville-sur-Saône',
  'Neyron',
  'Oullins',
  'Pierre-Bénite',
  "Poleymieux-au-Mont-d'Or",
  'Quincieux',
  'Rillieux-la-Pape',
  'Rochetaillée-sur-Saône',
  "Saint-Cyr-au-Mont-d'Or",
  "Saint-Didier-au-Mont-d'Or",
  'Saint-Fons',
  'Saint-Genis-Laval',
  'Saint-Genis-les-Ollières',
  "Saint-Germain-au-Mont-d'Or",
  'Saint-Priest',
  "Saint-Romain-au-Mont-d'Or",
  'Sainte-Foy-lès-Lyon',
  'Sathonay-Camp',
  'Sathonay-Village',
  'Solaize',
  'Tassin-la-Demi-Lune',
  'Vaulx-en-Velin',
  'Vénissieux',
  'Vernaison',
  'Villeurbanne',
];

// ── Données des 3 pépinières (bureaux et ateliers avec superficies réelles) ──
export const PEPINIERES_DATA = [];

export const TYPES_BIEN = [
  { value: 'maison',             label: 'Maison',             groupe: 'logement'   },
  { value: 'appartement',        label: 'Appartement',        groupe: 'logement'   },
  { value: 'entrepot',           label: 'Local',              groupe: 'logement'   },
  { value: 'terrain',            label: 'Terrain',            groupe: 'terrain'    },
  { value: 'pepiniere_bureau',   label: 'Pôle LYVE — Bureau', groupe: 'pepiniere'  },
  { value: 'pepiniere_atelier',  label: 'Pôle LYVE — Atelier',groupe: 'pepiniere'  },
];

export const NOTES = ['TB', 'B', 'P', 'M'];
export const NOTE_COLORS = {
  TB: { bg: '#16a34a', light: '#dcfce7', text: '#166534' },
  B:  { bg: '#2563eb', light: '#dbeafe', text: '#1d4ed8' },
  P:  { bg: '#d97706', light: '#fef3c7', text: '#92400e' },
  M:  { bg: '#dc2626', light: '#fee2e2', text: '#991b1b' },
};

// ── Équipements structurés pour chaque pièce ──────────────────────────────
const emptyEquipements = () => ({
  pointsLumineux:  { checked: false, nombre: '' },
  radiateurs:      { checked: false, nombre: '' },
  placards:        { checked: false, nombre: '' },
  occultants:      { checked: false, nombre: '', bonEtat: true, type: 'interieur' },
  prisesElec:      { checked: false, nombre: '' },
  interrupteurs:   { checked: false, nombre: '' },
  etat: '',
  observations: '',
});

const emptyMursZones = () => ({ nord: '', sud: '', est: '', ouest: '' });
const emptyPieceEval = () => ({
  plafond: '',
  murs: '',
  mursZones: emptyMursZones(),
  sols: '',
  menuiseries: '',
  equipements: emptyEquipements(),
  notes: '',
  photos: [],
});

export const newPiece = (nom = '') => ({
  nom,
  entrant: emptyPieceEval(),
  sortant: emptyPieceEval(),
});

// ── Pièce spéciale Jardin ──────────────────────────────────────────────────
// (JARDIN_CRITERES conservé pour compatibilité ascendante, non utilisé en UI)
export const JARDIN_CRITERES = [];

const emptyJardinEval = () => ({
  cloture:    { presente: false, rigide: false, etat: '' },
  portail:    { present: false,  materiau: '',  etat: '' },
  terrasse:   { presente: false, type: '',      etat: '' },
  piscine:    { presente: false, cloturee: false, vide: false },
  abriJardin: { present: false,  type: '',      etat: '', vide: false },
  notes: '',
});

export const newJardinPiece = (nom = 'Jardin') => ({
  nom,
  pieceType: 'jardin',
  entrant: emptyJardinEval(),
  sortant: emptyJardinEval(),
});

const PIECES_DEFAUT = [
  'Cuisine',
  "Salle de bain / Salle d'eau",
  'Séjour / Salon',
  'Chambre 1',
];

export const EDL_LOGEMENT_INITIAL = {
  typeBien: 'appartement',
  dateEDL: new Date().toISOString().split('T')[0],
  // Locataire
  locataireNom: '', locatairePrenom: '', locataireSociete: '',
  locataireTelephone: '', locataireEmail: '', nouvelleAdressePostale: '',
  // Adresse bien
  lotBatiment: '', ug: '', commune: '', adresseRue: '',
  immeuble: '', allee: '', etage: '', porte: '', copro: '',
  // Infos générales
  typeEDL: 'entrant',
  assurance: 'non',
  habitatType: 'individuel',
  nbPieces: '', nbChambres: '', surface: '',
  // Équipements
  ascenseur: false, interphone: false, antenneTv: false, digicode: false,
  eauFroideCollective: false, eauChaudeCollective: false,
  chauffageMode: 'individuel', chauffageEnergie: ['gaz'], chauffageEnergieAutre: '',
  chauffageJustificatif: false, chauffagePurge: 'non', chauffageTeste: 'non',
  // Annexes
  garageNum: '', garageEtat: 'vide',
  caveNum: '', caveEtat: 'vide',
  grenierNum: '', grenierEtat: 'vide',
  visiteEau: true, visiteElec: true, visiteGaz: true,
  // Compteurs
  dateEntree: '', dateSortie: '',
  eauChaudeNum: '', eauChaudeIdxE: '', eauChaudeIdxS: '', eauChaudeAbo: 'service',
  eauFroideNum: '', eauFroideIdxE: '', eauFroideIdxS: '', eauFroideAbo: 'service',
  electNum: '', electIdxE: '', electIdxS: '', electAbo: 'service',
  gazNum: '', gazIdxE: '', gazIdxS: '', gazAbo: 'service',
  remiseCles: false, nombreClesRemises: '',
  // Pièces
  pieces: PIECES_DEFAUT.map(nom => newPiece(nom)),
  // Signatures
  dateSignatureEntrant: '', dateSignatureSortant: '',
  sigProprietaireEntrant: '', sigLocataireEntrant: '',
  sigProprietaireSortant: '', sigLocataireSortant: '',
  // Signatures manuscrites (base64 PNG)
  sigImgProprietaireEntrant: '', sigImgLocataireEntrant: '',
  sigImgProprietaireSortant: '', sigImgLocataireSortant: '',
  // Partage
  partageAvec: [],
};

export const EDL_TERRAIN_INITIAL = {
  typeBien: 'terrain',
  // Locataire
  locRaisonSociale: '', locNom: '', locPrenom: '', locFonction: '',
  locAdresse: '', locVille: '', locCp: '', locTel: '', locPort: '',
  // Bien
  parcelle: '', garageNum: '', surfaceTerrain: '',
  identifiantBien: '', adresseBien: '', cpBien: '', villeBien: '',
  // Dates
  dateEntree: '', dateSortie: '',
  // Fluides Entrée
  gazEntreeDesc: '', elecEntreeDesc: '', eauEntreeDesc: '', autreEntreeDesc: '',
  // Fluides Sortie
  gazSortieDesc: '', elecSortieDesc: '', eauSortieDesc: '', autreSortieDesc: '',
  // Autres Entrée
  clotureEntreeDesc: '', portailEntreeDesc: '', cleNbEntree: '',
  batiEntreeDesc: '', encombrEntreeDesc: '',
  // Autres Sortie
  clotureSortieDesc: '', portailSortieDesc: '', cleNbSortie: '',
  batiSortieDesc: '', encombrSortieDesc: '',
  // Observations
  observationsEntree: '', observationsSortie: '',
  // Signatures
  sigEntreeProprietaire: '', sigEntreeLocataire: '',
  sigSortieProprietaire: '', sigSortieLocataire: '',
  // Signatures manuscrites (base64 PNG)
  sigImgEntreeProprietaire: '', sigImgEntreeLocataire: '',
  sigImgSortieProprietaire: '', sigImgSortieLocataire: '',
  // Partage
  partageAvec: [],
};

// ── Helper interne pour constatation vide ──────────────────────────────────
const cEtat = () => ({ etat: '', note: '' });

// ── EDL Pépinière Bureau ───────────────────────────────────────────────────
export const EDL_PEPINIERE_BUREAU_INITIAL = {
  typeBien: 'pepiniere_bureau',
  typeEDL: 'sortie',
  dateEDL: new Date().toISOString().split('T')[0],
  // Pépinière
  pepiniereId: '',
  // Métropole — représentant à renseigner (pré-rempli depuis profil utilisateur)
  metropoleRepresentant: '',
  // Locataire (à remplir)
  locEntreprise: '', locSiren: '', locRepresentant: '', locAdresse: '', locVille: '', locCp: '',
  // Descriptif du local
  localNumero: '', localSurface: '',
  // Nouvelle adresse (EDL sortie)
  nouvelleAdresse: '',
  // Constatations
  constatations: {
    portEntree: cEtat(), videophone: cEtat(),
    sol: cEtat(), murs: cEtat(), plafond: cEtat(), plinthes: cEtat(),
    fenetre: cEtat(), store: cEtat(), tabletteFenetre: cEtat(),
    interrupteurs: cEtat(), prisesCourant: cEtat(), radiateur: cEtat(),
    boiteAuxLettres: cEtat(),
  },
  autresEquipements: '',
  // Clés / Badges
  cles: [
    { libelle: "Badge d'accès immeuble", nombre: '', etat: '' },
    { libelle: "Clé d'accès bureau", nombre: '', etat: '' },
    { libelle: "Clé d'accès atelier", nombre: '', etat: '' },
    { libelle: "Clé accès box stockage", nombre: '', etat: '' },
    { libelle: "Clé de boîte aux lettres", nombre: '', etat: '' },
    { libelle: "Télécommande d'accès au parking", nombre: '', etat: '' },
  ],
  // Dépôt de garantie
  depotGarantie: true,
  // Signatures
  dateSignature: '', lieuSignature: 'Lyon', sigLocataire: '', sigMetropole: '',
  // Signatures manuscrites (base64 PNG)
  sigImgLocataire: '', sigImgMetropole: '',
  // Partage
  partageAvec: [],
};

// ── EDL Pépinière Atelier ──────────────────────────────────────────────────
export const EDL_PEPINIERE_ATELIER_INITIAL = {
  typeBien: 'pepiniere_atelier',
  typeEDL: 'sortie',
  dateEDL: new Date().toISOString().split('T')[0],
  // Pépinière
  pepiniereId: '',
  // Métropole
  metropoleRepresentant: '',
  // Locataire (à remplir)
  locEntreprise: '', locSiren: '', locRepresentant: '', locAdresse: '', locVille: '', locCp: '',
  // Descriptif du local
  localNumero: '', localSurface: '',
  // Nouvelle adresse (EDL sortie)
  nouvelleAdresse: '',
  // Constatations zone atelier
  constatationsAtelier: {
    sol: cEtat(), murs: cEtat(), plafond: cEtat(), fenetre: cEtat(),
    portEntree: cEtat(), porteSectionnelle: cEtat(), portail: cEtat(),
    interrupteurs: cEtat(), prisesCourant: cEtat(),
    aerotherme: cEtat(), vidoirs: cEtat(), sousCompteurs: cEtat(),
  },
  autresEquipementsAtelier: '',
  // Constatations bureau de l'atelier
  constatationsBureau: {
    sol: cEtat(), murs: cEtat(), plafond: cEtat(), plinthes: cEtat(),
    vitres: cEtat(), interrupteurs: cEtat(), prisesCourant: cEtat(), portEntree: cEtat(),
  },
  autresEquipementsBureau: '',
  // Clés / Badges
  cles: [
    { libelle: "Badge d'accès immeuble", nombre: '', etat: '' },
    { libelle: "Clé d'accès atelier étage", nombre: '', etat: '' },
    { libelle: "Clé accès bureau de l'atelier", nombre: '', etat: '' },
    { libelle: "Clé accès box stockage", nombre: '', etat: '' },
    { libelle: "Clé de boîte aux lettres", nombre: '', etat: '' },
    { libelle: "Télécommande d'accès au parking", nombre: '', etat: '' },
  ],
  // Relevé des compteurs
  compteurChauffageNum: '', compteurChauffageVal: '',
  compteurEauNum: '',       compteurEauVal: '',
  compteurElecNum: '',      compteurElecVal: '',
  dateLectureCompteurs: '',
  // Local box
  localBoxNumero: '', localBoxEtat: cEtat(),
  // Dépôt de garantie
  depotGarantie: true,
  // Signatures
  dateSignature: '', lieuSignature: 'Lyon', sigLocataire: '', sigMetropole: '',
  // Signatures manuscrites (base64 PNG)
  sigImgLocataire: '', sigImgMetropole: '',
  // Partage
  partageAvec: [],
};

// ── EDL Local (commercial / stockage / ICPE / atelier / artisanal) ────────────

// ── EDL Local (commercial / stockage / ICPE / atelier / artisanal) ────────────
const PIECES_DEFAUT_LOCAL = ['Espace principal'];

export const EDL_LOCAL_INITIAL = {
  typeBien: 'entrepot',
  dateEDL: new Date().toISOString().split('T')[0],
  typeEDL: 'entrant',
  // Nature du local
  usageLocal: '',
  // Locataire / Occupant
  locataireSociete: '', locataireSiren: '',
  locataireNom: '', locatairePrenom: '',
  locataireFonction: '',
  locataireAdresse: '', locataireVille: '', locataireCp: '',
  locataireTel: '', locatairePort: '',
  // Adresse du local
  lotBatiment: '', ug: '', commune: '', adresseRue: '',
  immeuble: '', allee: '', etage: '', porte: '',
  // Descriptif
  surface: '', referencesCadastrales: '',
  assurance: 'non',
  // Accès / Équipements
  digicode: false, interphone: false, alarme: false,
  triPhase: false, ventilationForcee: false,
  chauffageMode: 'individuel', chauffageEnergie: 'electrique',
  // Annexes
  parkingNum: '', parkingEtat: 'vide',
  caveNum: '',    caveEtat: 'vide',
  // Dates + compteurs
  dateEntree: '', dateSortie: '',
  eauFroideNum: '', eauFroideIdxE: '', eauFroideIdxS: '', eauFroideAbo: 'service',
  electNum: '',     electIdxE: '',     electIdxS: '',     electAbo: 'service',
  gazNum: '',       gazIdxE: '',       gazIdxS: '',       gazAbo: 'service',
  remiseCles: false,
  // Zones / Espaces
  pieces: PIECES_DEFAUT_LOCAL.map(nom => newPiece(nom)),
  // Observations libres
  observationsEntree: '', observationsSortie: '',
  // Signatures
  dateSignatureEntrant: '', dateSignatureSortant: '',
  sigProprietaireEntrant: '', sigLocataireEntrant: '',
  sigProprietaireSortant: '', sigLocataireSortant: '',
  sigImgProprietaireEntrant: '', sigImgLocataireEntrant: '',
  sigImgProprietaireSortant: '', sigImgLocataireSortant: '',
  // Partage
  partageAvec: [],
};

export function getInitialByType(typeBien, userProfile = '') {
  if (typeBien === 'terrain') return { ...EDL_TERRAIN_INITIAL };
  if (typeBien === 'entrepot') return { ...EDL_LOCAL_INITIAL };
  if (typeBien === 'pepiniere_bureau') {
    return { ...EDL_PEPINIERE_BUREAU_INITIAL, metropoleRepresentant: userProfile || '' };
  }
  if (typeBien === 'pepiniere_atelier') {
    return { ...EDL_PEPINIERE_ATELIER_INITIAL, metropoleRepresentant: userProfile || '' };
  }
  return { ...EDL_LOGEMENT_INITIAL, typeBien };
}

export function labelType(typeBien) {
  return TYPES_BIEN.find(t => t.value === typeBien)?.label || typeBien;
}

export function isPepiniere(typeBien) {
  return typeBien === 'pepiniere_bureau' || typeBien === 'pepiniere_atelier';
}

export function isLocal(typeBien) {
  return typeBien === 'entrepot';
}
