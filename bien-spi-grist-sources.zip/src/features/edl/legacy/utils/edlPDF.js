// src/features/edl/utils/edlPDF.js
// Génère un PDF fidèle aux documents d'origine via html2pdf.js

import { isSingleVisit, visitMode, fieldVisit } from '../../edlVisit';
import { projectVisitHtml } from '../../visitPdf';
import { trimEmptyPdfPages } from '../../trimEmptyPdfPages';
import { labelType, PEPINIERES_DATA } from './edlDefaults.js';
import { preparePdfDocument, scopeLegacyPdfCss } from '../../../../infrastructure/pdf/documentTheme';

const getPepiniere = (id) => PEPINIERES_DATA.find(p => p.id === id) || null;

// ── Helpers ──────────────────────────────────────────────────────────────────
const v = (val, fallback = '…………………') => (val && String(val).trim()) ? String(val).trim() : fallback;
const d = (dateStr) => {
  if (!dateStr) return '__ /__ /______';
  const dt = new Date(dateStr);
  return dt.toLocaleDateString('fr-FR');
};
const checked = (bool) => bool ? '☑' : '☐';
const sigImg = (base64) => base64
  ? `<img src="${base64}" style="max-width:100%;max-height:50px;width:auto;height:auto;display:block;margin-top:3px" />`
  : '<div class="sig-box"></div>';
const noteClass = (note) => ['TB', 'B', 'P', 'M'].includes(note) ? `note-${note}` : '';
const formatMurs = (evalData = {}) => {
  const zones = evalData.mursZones && typeof evalData.mursZones === 'object' ? evalData.mursZones : {};
  const labels = { nord: 'Nord', sud: 'Sud', est: 'Est', ouest: 'Ouest' };
  const lines = Object.entries(labels)
    .filter(([key]) => zones[key])
    .map(([key, label]) => `${label}: ${zones[key]}`);
  return lines.length ? lines.join('\n') : (evalData.murs || '—');
};
const formatEnergie = (value, autre = '') => {
  const labels = { gaz: 'Gaz', fioul: 'Fioul', electrique: 'Électrique', autre: 'Autre' };
  const values = Array.isArray(value) ? value : (value ? [value] : []);
  if (!values.length) return '—';
  return values.map((item) => item === 'autre' && autre ? `Autre (${autre})` : (labels[item] || item)).join(', ');
};
const photosInlineHTML = (photos = []) => {
  if (!Array.isArray(photos) || !photos.length) return '';
  return photos.map((photo) => `
    <div style="display:inline-block;width:31%;vertical-align:top;margin:0 1% 6px 0;border:1px solid #ddd;border-radius:4px;overflow:hidden">
      <img src="${photo.src}" style="max-width:100%;max-height:85px;width:auto;height:auto;display:block;margin:0 auto" />
      ${photo.legende ? `<div style="font-size:7pt;text-align:center;padding:3px;border-top:1px solid #eee">${photo.legende}</div>` : ''}
    </div>`).join('');
};

// ── Équipements helper ────────────────────────────────────────────────────────
const EQUIP_LABELS = {
  pointsLumineux: 'Pts lumineux',
  radiateurs:     'Radiateurs',
  placards:       'Placards',
  occultants:     'Occultants',
  prisesElec:     'Prises élec.',
  interrupteurs:  'Interrupteurs',
};

const formatEquipements = (eq) => {
  if (!eq || typeof eq !== 'object') return eq ? String(eq) : '—';
  const lignes = Object.entries(eq)
    .filter(([key, val]) => !['etat', 'observations'].includes(key) && val && val.checked)
    .map(([key, val]) => {
      const label = EQUIP_LABELS[key] || key;
      const nb    = val.nombre !== '' && val.nombre != null ? ` ×${val.nombre}` : '';
      const note = ['TB', 'B', 'P', 'M'].includes(val.etat) ? ` — ${val.etat}` : ' — état non renseigné';
      let extra = '';
      if (key === 'occultants') {
        const typ = val.type ? `(${val.type})` : '';
        const etat = !val.etat && val.bonEtat === false ? '(ancien constat : mauvais état)' : '';
        extra = [typ, etat].filter(Boolean).join(' ');
        if (extra) extra = ' ' + extra;
      }
      return `${label}${nb}${note}${extra}`;
    });
  if (eq.etat) lignes.push(`Ancienne appréciation globale : ${eq.etat}`);
  if (eq.observations) lignes.push(`Obs.: ${eq.observations}`);
  return lignes.length ? lignes.join('\n') : '—';
};

// ── Jardin helper ──────────────────────────────────────────────────────────────
const MAT_PORTAIL  = { bois:'Bois', pvc:'PVC', metal:'Métal', aluminium:'Aluminium', fer_forge:'Fer forgé' };
const TYP_TERRASSE = { bois:'Bois', composite:'Composite', beton:'Béton', carrelage:'Carrelage', dallage:'Dallage', gravier:'Gravier', gazon:'Gazon synthétique' };
const TYP_ABRI     = { bois:'Bois', metal:'Métal', pvc:'PVC', resine:'Résine', maconnerie:'Maçonnerie' };

const formatJardinEval = (ev) => {
  if (!ev || typeof ev !== 'object') return '—';
  const lines = [];
  const { cloture, portail, terrasse, piscine, abriJardin, notes } = ev;

  if (cloture?.presente) {
    let t = 'Clôture';
    if (cloture.rigide) t += ' — rigide';
    if (cloture.etat)   t += ` — ${cloture.etat}`;
    lines.push(t);
  }
  if (portail?.present) {
    let t = 'Portail';
    if (portail.materiau) t += ` — ${MAT_PORTAIL[portail.materiau] || portail.materiau}`;
    if (portail.etat)     t += ` — ${portail.etat}`;
    lines.push(t);
  }
  if (terrasse?.presente) {
    let t = 'Terrasse';
    if (terrasse.type) t += ` — ${TYP_TERRASSE[terrasse.type] || terrasse.type}`;
    if (terrasse.etat) t += ` — ${terrasse.etat}`;
    lines.push(t);
  }
  if (piscine?.presente) {
    let t = 'Piscine';
    if (piscine.cloturee) t += ' — clôturée';
    if (piscine.vide)     t += ' — vidée';
    lines.push(t);
  }
  if (abriJardin?.present) {
    let t = 'Abri de jardin';
    if (abriJardin.type) t += ` — ${TYP_ABRI[abriJardin.type] || abriJardin.type}`;
    if (abriJardin.etat) t += ` — ${abriJardin.etat}`;
    if (abriJardin.vide) t += ' — vide';
    lines.push(t);
  }
  if (notes) lines.push(`Obs. : ${notes}`);

  return lines.length ? lines.join('\n') : 'Aucun élément renseigné';
};

// ── Photos helper ─────────────────────────────────────────────────────────────
const photosHTML = (photos) => {
  if (!Array.isArray(photos) || photos.length === 0) return '';
  const items = photos.map(p => `
    <div style="width:calc(33.33% - 6px);display:inline-block;vertical-align:top;
                border:1px solid #ccc;border-radius:4px;overflow:hidden;
                page-break-inside:avoid;margin-bottom:8px">
      <img src="${p.src}" style="max-width:100%;max-height:110px;width:auto;height:auto;display:block;margin:0 auto" />
      ${p.legende ? `<div style="font-size:7.5pt;padding:3px 5px;color:#555;text-align:center;
                                  border-top:1px solid #e5e7eb">${p.legende}</div>` : ''}
    </div>`).join('');
  return `
<h2>Photos</h2>
<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px">
  ${items}
</div>`;
};

// ── CSS commun ────────────────────────────────────────────────────────────────
const CSS = `
  @page { margin: 15mm; }
  * { box-sizing: border-box; color: #000 !important; }
  body { font-family: Arial, Helvetica, sans-serif; font-size: 9pt; color: #000; margin: 0; background: #fff !important; }
  h1 { font-size: 12pt; text-align: center; margin: 0 0 8px; border-bottom: 2px solid #000; padding-bottom: 4px; color: #000 !important; }
  h2 { font-size: 10pt; background: #1e3a5f !important; color: white !important; padding: 4px 8px; margin: 10px 0 5px; page-break-after: avoid; }
  h3 { font-size: 9pt; background: #e8edf5 !important; padding: 3px 6px; margin: 8px 0 4px; border-left: 3px solid #2563eb; color: #000 !important; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 6px; }
  .constat-table { table-layout: fixed; }
  td, th { border: 1px solid #ccc; padding: 3px 5px; vertical-align: top; font-size: 8.5pt; color: #000 !important; background: #fff !important; word-wrap: break-word; overflow-wrap: break-word; }
  th { background: #e8edf5 !important; font-weight: bold; }
  tr { page-break-inside: avoid; }
  .row { display: flex; gap: 16px; margin-bottom: 6px; }
  .field { flex: 1; }
  .field-label { font-size: 7.5pt; font-weight: bold; color: #555 !important; text-transform: uppercase; }
  .field-val { border-bottom: 1px solid #888; min-height: 16px; padding: 1px 2px; font-size: 9pt; color: #000 !important; }
  .sig-box { border: 1px solid #999; height: 40px; margin-top: 3px; background: #fff !important; }
  .note-TB { color: #16a34a !important; font-weight: bold; }
  .note-B  { color: #2563eb !important; font-weight: bold; }
  .note-P  { color: #d97706 !important; font-weight: bold; }
  .note-M  { color: #dc2626 !important; font-weight: bold; }
  .recomm  { font-size: 8pt; font-style: italic; border: 1px solid #aaa; padding: 6px; margin: 8px 0; page-break-inside: avoid; background: #fff !important; }
  .footer-sig { display: flex; gap: 10px; margin-top: 6px; }
  .footer-sig-item { flex: 1; }
  .section-signatures { page-break-inside: avoid; margin-top: 10px; }
  .piece-group { page-break-inside: avoid; }
  .section-block { page-break-inside: avoid; }
`;

// ════════════════════════════════════════════════════════════════════════════
// PDF LOGEMENT
// ════════════════════════════════════════════════════════════════════════════
function buildLogementHTML(edl) {
  const typeLabel = labelType(edl.typeBien);
  const pieces = Array.isArray(edl.pieces) ? edl.pieces : [];

  const equipRow = (items) => items.map(([k, lbl]) =>
    `<td>${checked(edl[k])} ${lbl}</td>`
  ).join('');

  const noteCell = (n) => `<td style="text-align:center;white-space:pre-line" class="${noteClass(n)}">${n || '—'}</td>`;

  const compteurRow = (prefix, label) => `
    <tr>
      <td>${label}</td>
      <td>${v(edl[prefix + 'Num'], '—')}</td>
      <td data-edl-mode="entrant">${v(edl[prefix + 'IdxE'], '—')}</td>
      <td data-edl-mode="sortant">${v(edl[prefix + 'IdxS'], '—')}</td>
      <td style="text-align:center">${edl[prefix + 'Abo'] === 'resilie' ? 'Résilié' : 'En service'}</td>
    </tr>`;

  const piecesHTML = pieces.map(p => {
    const isJardin = p.pieceType === 'jardin';
    const e = p.entrant || {};
    const s = p.sortant || {};

    if (isJardin) {
      // Pièce Jardin : structure spécifique (cloture, portail, terrasse, piscine, abriJardin, notes)
      return `
        <tbody class="piece-group">
        <tr>
          <td colspan="7" style="font-weight:bold;background:#dcfce7 !important;padding:4px 6px;color:#166534">
            🌿 ${v(p.nom, 'Jardin')}
          </td>
        </tr>
        <tr data-edl-mode="entrant">
          <td data-edl-phase-label style="white-space:nowrap">Entrant</td>
          <td colspan="6" style="font-size:8pt;white-space:pre-line">${formatJardinEval(e)}</td>
        </tr>
        <tr data-edl-mode="sortant">
          <td data-edl-phase-label style="white-space:nowrap">Sortant</td>
          <td colspan="6" style="font-size:8pt;white-space:pre-line">${formatJardinEval(s)}</td>
        </tr>
        </tbody>`;
    }

    const photoRow = [
      ['Entrant', e.photos],
      ['Sortant', s.photos],
    ].filter(([, photos]) => Array.isArray(photos) && photos.length)
      .map(([label, photos]) => `
        <tr data-edl-mode="${label === 'Entrant' ? 'entrant' : 'sortant'}">
          <td data-edl-phase-label>${label}</td>
          <td colspan="6">${photosInlineHTML(photos)}</td>
        </tr>`).join('');

    // Pièce standard
    return `
      <tbody class="piece-group">
      <tr style="background:#f9fafb">
        <td colspan="7" style="font-weight:bold;background:#dbeafe !important;padding:4px 6px">${v(p.nom, 'Pièce')}</td>
      </tr>
      <tr data-edl-mode="entrant">
        <td data-edl-phase-label>Entrant</td>
        ${noteCell(e.plafond)}${noteCell(formatMurs(e))}${noteCell(e.sols)}${noteCell(e.menuiseries)}
        <td style="font-size:7.5pt;white-space:pre-line">${formatEquipements(e.equipements)}</td>
        <td style="font-size:7.5pt;white-space:pre-line">${v(e.notes, '—')}</td>
      </tr>
      <tr data-edl-mode="sortant">
        <td data-edl-phase-label>Sortant</td>
        ${noteCell(s.plafond)}${noteCell(formatMurs(s))}${noteCell(s.sols)}${noteCell(s.menuiseries)}
        <td style="font-size:7.5pt;white-space:pre-line">${formatEquipements(s.equipements)}</td>
        <td style="font-size:7.5pt;white-space:pre-line">${v(s.notes, '—')}</td>
      </tr>
      ${photoRow}
      </tbody>`;
  }).join('');

  return `<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><style>${CSS}</style></head>
<body>

<h1>MÉTROPOLE DE LYON — ÉTAT DES LIEUX — ${typeLabel.toUpperCase()}</h1>

<!-- Identification du bien -->
<div class="section-block">
<h2>Identification du bien</h2>
<div class="row">
  <div class="field"><div class="field-label">Lot bâtiment</div><div class="field-val">${v(edl.lotBatiment)}</div></div>
  <div class="field"><div class="field-label">UG</div><div class="field-val">${v(edl.ug)}</div></div>
  <div class="field"><div class="field-label">Commune</div><div class="field-val">${v(edl.commune)}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Adresse</div><div class="field-val">${v(edl.adresseRue)}</div></div>
  <div class="field"><div class="field-label">Immeuble</div><div class="field-val">${v(edl.immeuble)}</div></div>
  <div class="field"><div class="field-label">Allée</div><div class="field-val">${v(edl.allee)}</div></div>
  <div class="field"><div class="field-label">Étage</div><div class="field-val">${v(edl.etage)}</div></div>
  <div class="field"><div class="field-label">Porte</div><div class="field-val">${v(edl.porte)}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Locataire</div><div class="field-val">${v(edl.locataireNom)} ${v(edl.locatairePrenom, '')}</div></div>
  <div class="field"><div class="field-label">Société / Association</div><div class="field-val">${v(edl.locataireSociete, '—')}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Téléphone</div><div class="field-val">${v(edl.locataireTelephone, '—')}</div></div>
  <div class="field"><div class="field-label">Adresse mail</div><div class="field-val">${v(edl.locataireEmail, '—')}</div></div>
</div>
${edl.typeEDL === 'sortant' && edl.nouvelleAdressePostale ? `
<div class="row">
  <div class="field"><div class="field-label">Nouvelle adresse postale</div><div class="field-val">${v(edl.nouvelleAdressePostale, '—')}</div></div>
</div>` : ''}
<div class="row">
  <div class="field"><div class="field-label">Attestation assurance</div><div class="field-val">${edl.assurance === 'oui' ? '☑ Oui  ☐ Non' : '☐ Oui  ☑ Non'}</div></div>
  <div class="field"><div class="field-label">Copro / Syndic</div><div class="field-val">${v(edl.copro, '—')}</div></div>
  <div class="field"><div class="field-label">Date EDL</div><div class="field-val">${d(edl.dateEDL)}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Nb pièces</div><div class="field-val">${v(edl.nbPieces)} pièce(s) dont ${v(edl.nbChambres, '?')} chambre(s) — ${v(edl.surface, '?')} m²</div></div>
</div>
</div>

<!-- Équipements -->
<div class="section-block">
<h2>Équipements collectifs &amp; Chauffage</h2>
<table>
  <tr>
    ${equipRow([['ascenseur','Ascenseur'],['eauFroideCollective','Eau froide collective'],['eauChaudeCollective','Eau chaude collective']])}
  </tr>
  <tr>
    ${equipRow([['interphone','Interphone'],['antenneTv','Antenne TV'],['digicode','Digicode']])}
  </tr>
</table>
<table>
  <tr>
    <th>Mode chauffage</th><th>Énergie</th><th>Justificatif entretien</th><th>Purgé</th><th>Testé</th>
  </tr>
  <tr>
    <td>${edl.chauffageMode === 'individuel' ? '☑ Individuel  ☐ Collectif' : '☐ Individuel  ☑ Collectif'}</td>
    <td>${formatEnergie(edl.chauffageEnergie, edl.chauffageEnergieAutre)}</td>
    <td style="text-align:center">${edl.chauffageJustificatif ? '☑ Oui' : '☐ Non'}</td>
    <td style="text-align:center">${edl.chauffagePurge === 'oui' ? '☑ Oui' : '☐ Non'}</td>
    <td style="text-align:center">${edl.chauffageTeste === 'oui' ? '☑ Oui' : '☐ Non'}</td>
  </tr>
</table>
</div>

<!-- Annexes -->
<div class="section-block">
<h2>Annexes</h2>
<table>
  <tr><th>Annexe</th><th>N°</th><th>État</th><th>Visite</th></tr>
  <tr><td>Garage</td><td>${v(edl.garageNum,'—')}</td><td>${edl.garageEtat === 'vide' ? 'Vide' : 'Non débarrassé'}</td>
      <td rowspan="3">${checked(edl.visiteEau)} Avec eau &nbsp; ${checked(edl.visiteElec)} Avec électricité &nbsp; ${checked(edl.visiteGaz)} Avec gaz</td></tr>
  <tr><td>Cave</td><td>${v(edl.caveNum,'—')}</td><td>${edl.caveEtat === 'vide' ? 'Vide' : 'Non débarrassé'}</td></tr>
  <tr><td>Grenier</td><td>${v(edl.grenierNum,'—')}</td><td>${edl.grenierEtat === 'vide' ? 'Vide' : 'Non débarrassé'}</td></tr>
</table>
<div><strong>Remise des clés :</strong> ${checked(edl.remiseCles)} Oui &nbsp; ${checked(!edl.remiseCles)} Non &nbsp; <strong>Nombre :</strong> ${v(edl.nombreClesRemises, '—')}</div>
</div>

<!-- Compteurs -->
<div class="section-block">
<h2>Relevés compteurs</h2>
<div class="row" style="margin-bottom:6px">
  <div data-edl-mode="entrant" class="field"><div class="field-label">Date entrée</div><div class="field-val">${d(edl.dateEntree)}</div></div>
  <div data-edl-mode="sortant" class="field"><div class="field-label">Date sortie</div><div class="field-val">${d(edl.dateSortie)}</div></div>
</div>
<table>
  <tr><th>Fluide</th><th>N° compteur</th><th data-edl-mode="entrant">Index entrée</th><th data-edl-mode="sortant">Index sortie</th><th>Abonnement</th></tr>
  ${compteurRow('eauChaude', 'Eau chaude')}
  ${compteurRow('eauFroide', 'Eau froide')}
  ${compteurRow('elect', 'Électricité')}
  ${compteurRow('gaz', 'Gaz')}
</table>
</div>

<!-- Recommandations -->
<div class="recomm">
  <strong>Recommandations importantes :</strong> Les lieux doivent être restitués vides de tout mobilier et objets personnels,
  nettoyés y compris les annexes (balcon, garage, cave, etc.), les vitres propres ; les menues réparations exécutées :
  remplacement des appareillages détériorés, les joints usés refaits, moquettes shampouinées, cuvette WC détartrée, etc.
  Les trous de chevilles doivent être rebouchés. Prévoyez de justifier le certificat récent de l'entretien chaudière ou
  chauffe-eau. N'oubliez pas de procéder à la résiliation des contrats de fourniture d'énergie.
</div>

<!-- Pièces -->
<div class="section-block">
<h2>Description pièce par pièce — TB : Très bon · B : Bon · P : Passable · M : Mauvais</h2>
<table>
  <tr style="background:#1e3a5f;color:white">
    <th data-edl-phase-label>Pièce / EDL</th><th>Plafond</th><th>Murs</th><th>Sols</th><th>Menuiseries</th>
    <th>Équipements</th><th>Observations</th>
  </tr>
  ${piecesHTML}
</table>
</div>

${photosHTML(edl.photos)}

<!-- Signatures -->
<div class="section-signatures">
<h2>Signatures</h2>
<div style="display:flex;gap:20px">
  <div data-edl-mode="entrant" style="flex:1">
    <div style="font-weight:bold;margin-bottom:4px">EDL Entrant — ${d(edl.dateSignatureEntrant)}</div>
    <div class="footer-sig">
      <div class="footer-sig-item">
        <div class="field-label">Pour le propriétaire</div>
        <div class="field-val" style="margin-bottom:3px">${v(edl.sigProprietaireEntrant,'')}</div>
        ${sigImg(edl.sigImgProprietaireEntrant)}
      </div>
      <div class="footer-sig-item">
        <div class="field-label">Pour le locataire</div>
        <div class="field-val" style="margin-bottom:3px">${v(edl.sigLocataireEntrant,'')}</div>
        ${sigImg(edl.sigImgLocataireEntrant)}
      </div>
    </div>
  </div>
  <div data-edl-mode="sortant" style="flex:1">
    <div style="font-weight:bold;margin-bottom:4px">EDL Sortant — ${d(edl.dateSignatureSortant)}</div>
    <div class="footer-sig">
      <div class="footer-sig-item">
        <div class="field-label">Pour le propriétaire</div>
        <div class="field-val" style="margin-bottom:3px">${v(edl.sigProprietaireSortant,'')}</div>
        ${sigImg(edl.sigImgProprietaireSortant)}
      </div>
      <div class="footer-sig-item">
        <div class="field-label">Pour le locataire</div>
        <div class="field-val" style="margin-bottom:3px">${v(edl.sigLocataireSortant,'')}</div>
        ${sigImg(edl.sigImgLocataireSortant)}
      </div>
    </div>
  </div>
</div>

<p style="font-size:8pt;margin-top:10px;font-style:italic">
  Le présent état des lieux, établi contradictoirement et accepté par les parties fait partie intégrante du contrat de location auquel il est joint.
</p>
</div>

</body></html>`;
}

// ════════════════════════════════════════════════════════════════════════════
// PDF TERRAIN
// ════════════════════════════════════════════════════════════════════════════
function buildTerrainHTML(edl) {
  const col = (entreeVal, sortieVal, libelle) => `
    <tr>
      <td style="font-weight:bold;background:#f1f5f9;width:18%">${libelle}</td>
      <td data-edl-mode="entrant" style="white-space:pre-line;width:41%">${v(entreeVal,'—')}</td>
      <td data-edl-mode="sortant" style="white-space:pre-line;width:41%">${v(sortieVal,'—')}</td>
    </tr>`;

  return `<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><style>${CSS}</style></head>
<body>

<h1>MÉTROPOLE DE LYON — ÉTAT DES LIEUX — TERRAIN / PARCELLE</h1>

<!-- Locataire -->
<div class="section-block">
<h2>Informations locataire</h2>
<div class="row">
  <div class="field"><div class="field-label">Raison sociale</div><div class="field-val">${v(edl.locRaisonSociale)}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Nom</div><div class="field-val">${v(edl.locNom)}</div></div>
  <div class="field"><div class="field-label">Prénom</div><div class="field-val">${v(edl.locPrenom)}</div></div>
  <div class="field"><div class="field-label">Fonction</div><div class="field-val">${v(edl.locFonction,'—')}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Adresse</div><div class="field-val">${v(edl.locAdresse)}</div></div>
  <div class="field"><div class="field-label">Code Postal</div><div class="field-val">${v(edl.locCp)}</div></div>
  <div class="field"><div class="field-label">Ville</div><div class="field-val">${v(edl.locVille)}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Téléphone</div><div class="field-val">${v(edl.locTel,'—')}</div></div>
  <div class="field"><div class="field-label">Portable</div><div class="field-val">${v(edl.locPort,'—')}</div></div>
</div>
</div>

<!-- Descriptif du bien -->
<div class="section-block">
<h2>Descriptif du bien</h2>
<div class="row">
  <div class="field"><div class="field-label">Parcelle(s) n°</div><div class="field-val">${v(edl.parcelle)}</div></div>
  <div class="field"><div class="field-label">Garage n°</div><div class="field-val">${v(edl.garageNum,'—')}</div></div>
  <div class="field"><div class="field-label">Surface</div><div class="field-val">${v(edl.surfaceTerrain,'—')} m²</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Identifiant du bien</div><div class="field-val">${v(edl.identifiantBien)}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Adresse</div><div class="field-val">${v(edl.adresseBien)}</div></div>
  <div class="field"><div class="field-label">Code Postal</div><div class="field-val">${v(edl.cpBien)}</div></div>
  <div class="field"><div class="field-label">Ville</div><div class="field-val">${v(edl.villeBien)}</div></div>
</div>
</div>

<!-- Descriptif des lieux Entrée / Sortie -->
<div class="section-block">
<h2>Descriptif des lieux</h2>
<table>
  <tr>
    <th style="width:18%"></th>
    <th data-edl-mode="entrant" style="width:41%;background:#d1fae5;color:#065f46">↩ ENTRÉE — ${d(edl.dateEntree)}</th>
    <th data-edl-mode="sortant" style="width:41%;background:#fee2e2;color:#991b1b">↪ SORTIE — ${d(edl.dateSortie)}</th>
  </tr>
  <tr><td colspan="3" style="background:#e8edf5;font-weight:bold;font-size:8.5pt;padding:3px 5px">FLUIDES</td></tr>
  ${col(edl.gazEntreeDesc, edl.gazSortieDesc, 'Gaz')}
  ${col(edl.elecEntreeDesc, edl.elecSortieDesc, 'Électricité')}
  ${col(edl.eauEntreeDesc, edl.eauSortieDesc, 'Eau')}
  ${col(edl.autreEntreeDesc, edl.autreSortieDesc, 'Autre')}
  <tr><td colspan="3" style="background:#e8edf5;font-weight:bold;font-size:8.5pt;padding:3px 5px">AUTRES ÉLÉMENTS</td></tr>
  ${col(edl.clotureEntreeDesc, edl.clotureSortieDesc, 'Clôture')}
  ${col(edl.portailEntreeDesc, edl.portailSortieDesc, 'Portail')}
  <tr>
    <td style="font-weight:bold;background:#f1f5f9">Clés</td>
    <td data-edl-mode="entrant">Nombre : ${v(edl.cleNbEntree,'—')}</td>
    <td data-edl-mode="sortant">Nombre : ${v(edl.cleNbSortie,'—')}</td>
  </tr>
  ${col(edl.batiEntreeDesc, edl.batiSortieDesc, 'Bâti')}
  ${col(edl.encombrEntreeDesc, edl.encombrSortieDesc, 'Encombrant')}
  <tr>
    <td style="font-weight:bold;background:#f1f5f9">Observations</td>
    <td data-edl-mode="entrant" style="white-space:pre-line">${v(edl.observationsEntree,'—')}</td>
    <td data-edl-mode="sortant" style="white-space:pre-line">${v(edl.observationsSortie,'—')}</td>
  </tr>
</table>
</div>

${photosHTML(edl.photos)}

<!-- Signatures -->
<div class="section-signatures">
<h2>Noms et signatures</h2>
<div style="display:flex;gap:20px;margin-top:6px">
  <div data-edl-mode="entrant" style="flex:1">
    <div style="font-weight:bold;text-align:center;margin-bottom:6px;color:#065f46">↩ Entrée</div>
    <div class="footer-sig">
      <div class="footer-sig-item">
        <div class="field-label">Propriétaire / Grand-Lyon</div>
        <div class="field-val">${v(edl.sigEntreeProprietaire,'')}</div>
        ${sigImg(edl.sigImgEntreeProprietaire)}
      </div>
      <div class="footer-sig-item">
        <div class="field-label">Locataire</div>
        <div class="field-val">${v(edl.sigEntreeLocataire,'')}</div>
        ${sigImg(edl.sigImgEntreeLocataire)}
      </div>
    </div>
  </div>
  <div data-edl-mode="sortant" style="flex:1">
    <div style="font-weight:bold;text-align:center;margin-bottom:6px;color:#991b1b">↪ Sortie</div>
    <div class="footer-sig">
      <div class="footer-sig-item">
        <div class="field-label">Propriétaire / Grand-Lyon</div>
        <div class="field-val">${v(edl.sigSortieProprietaire,'')}</div>
        ${sigImg(edl.sigImgSortieProprietaire)}
      </div>
      <div class="footer-sig-item">
        <div class="field-label">Locataire</div>
        <div class="field-val">${v(edl.sigSortieLocataire,'')}</div>
        ${sigImg(edl.sigImgSortieLocataire)}
      </div>
    </div>
  </div>
</div>
</div>

</body></html>`;
}

// ════════════════════════════════════════════════════════════════════════════
// PDF LOCAL COMMERCIAL / INDUSTRIEL
// ════════════════════════════════════════════════════════════════════════════
function buildLocalHTML(edl) {
  const USAGE_LABELS = {
    commercial: 'Commercial', stockage: 'Stockage', icpe: 'ICPE',
    artisanal: 'Atelier / Artisanal', bureau: 'Bureau', mixte: 'Mixte', autre: 'Autre',
  };
  const usageLabel = USAGE_LABELS[edl.usageLocal] || edl.usageLocal || '—';
  const typeEDLLabel = edl.typeEDL === 'sortant' ? 'SORTANT' : 'ENTRANT';

  const noteCell = (n) => `<td style="text-align:center;white-space:pre-line" class="${noteClass(n)}">${n || '—'}</td>`;

  const compteurRow = (prefix, label) => `
    <tr>
      <td>${label}</td>
      <td>${v(edl[prefix + 'Num'], '—')}</td>
      <td data-edl-mode="entrant">${v(edl[prefix + 'IdxE'], '—')}</td>
      <td data-edl-mode="sortant">${v(edl[prefix + 'IdxS'], '—')}</td>
      <td style="text-align:center">${edl[prefix + 'Abo'] === 'resilie' ? 'Résilié' : 'En service'}</td>
    </tr>`;

  const pieces = Array.isArray(edl.pieces) ? edl.pieces : [];

  const zonesHTML = pieces.map(p => {
    const e = p.entrant || {};
    const s = p.sortant || {};
    const photoRow = [
      ['Entrant', e.photos],
      ['Sortant', s.photos],
    ].filter(([, photos]) => Array.isArray(photos) && photos.length)
      .map(([label, photos]) => `
        <tr data-edl-mode="${label === 'Entrant' ? 'entrant' : 'sortant'}">
          <td data-edl-phase-label>${label}</td>
          <td colspan="6">${photosInlineHTML(photos)}</td>
        </tr>`).join('');
    return `
      <tbody class="piece-group">
      <tr>
        <td colspan="7" style="font-weight:bold;background:#fef3c7 !important;padding:4px 6px;color:#92400e">${v(p.nom, 'Zone')}</td>
      </tr>
      <tr data-edl-mode="entrant">
        <td data-edl-phase-label>Entrant</td>
        ${noteCell(e.plafond)}${noteCell(formatMurs(e))}${noteCell(e.sols)}${noteCell(e.menuiseries)}
        <td style="font-size:7.5pt;white-space:pre-line">${formatEquipements(e.equipements)}</td>
        <td style="font-size:7.5pt;white-space:pre-line">${v(e.notes, '—')}</td>
      </tr>
      <tr data-edl-mode="sortant">
        <td data-edl-phase-label>Sortant</td>
        ${noteCell(s.plafond)}${noteCell(formatMurs(s))}${noteCell(s.sols)}${noteCell(s.menuiseries)}
        <td style="font-size:7.5pt;white-space:pre-line">${formatEquipements(s.equipements)}</td>
        <td style="font-size:7.5pt;white-space:pre-line">${v(s.notes, '—')}</td>
      </tr>
      ${photoRow}
      </tbody>`;
  }).join('');

  return `<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><style>${CSS}</style></head>
<body>

<h1>MÉTROPOLE DE LYON — ÉTAT DES LIEUX — LOCAL (${typeEDLLabel})</h1>

<!-- Descriptif du local -->
<div class="section-block">
<h2>Descriptif du local</h2>
<div class="row">
  <div class="field"><div class="field-label">Nature / Usage</div><div class="field-val">${usageLabel}</div></div>
  <div class="field"><div class="field-label">Surface</div><div class="field-val">${v(edl.surface, '—')} m²</div></div>
  <div class="field"><div class="field-label">Date EDL</div><div class="field-val">${d(edl.dateEDL)}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Références cadastrales</div><div class="field-val">${v(edl.referencesCadastrales)}</div></div>
  <div class="field"><div class="field-label">Attestation assurance</div><div class="field-val">${edl.assurance === 'oui' ? '☑ Oui  ☐ Non' : '☐ Oui  ☑ Non'}</div></div>
</div>
</div>

<!-- Adresse -->
<div class="section-block">
<h2>Adresse du local</h2>
<div class="row">
  <div class="field"><div class="field-label">Lot bâtiment</div><div class="field-val">${v(edl.lotBatiment)}</div></div>
  <div class="field"><div class="field-label">UG</div><div class="field-val">${v(edl.ug)}</div></div>
  <div class="field"><div class="field-label">Commune</div><div class="field-val">${v(edl.commune)}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Adresse</div><div class="field-val">${v(edl.adresseRue)}</div></div>
  <div class="field"><div class="field-label">Bâtiment</div><div class="field-val">${v(edl.immeuble)}</div></div>
  <div class="field"><div class="field-label">Allée / Zone</div><div class="field-val">${v(edl.allee)}</div></div>
  <div class="field"><div class="field-label">Étage / Niveau</div><div class="field-val">${v(edl.etage)}</div></div>
  <div class="field"><div class="field-label">Porte / Cellule</div><div class="field-val">${v(edl.porte)}</div></div>
</div>
</div>

<!-- Locataire / Occupant -->
<div class="section-block">
<h2>Locataire / Occupant</h2>
<div class="row">
  <div class="field"><div class="field-label">Raison sociale / Société</div><div class="field-val">${v(edl.locataireSociete)}</div></div>
  <div class="field"><div class="field-label">SIREN</div><div class="field-val">${v(edl.locataireSiren, '—')}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Nom</div><div class="field-val">${v(edl.locataireNom)}</div></div>
  <div class="field"><div class="field-label">Prénom</div><div class="field-val">${v(edl.locatairePrenom, '')}</div></div>
  <div class="field"><div class="field-label">Fonction</div><div class="field-val">${v(edl.locataireFonction, '—')}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Adresse</div><div class="field-val">${v(edl.locataireAdresse)}</div></div>
  <div class="field"><div class="field-label">CP</div><div class="field-val">${v(edl.locataireCp)}</div></div>
  <div class="field"><div class="field-label">Ville</div><div class="field-val">${v(edl.locataireVille)}</div></div>
</div>
<div class="row">
  <div class="field"><div class="field-label">Téléphone</div><div class="field-val">${v(edl.locataireTel, '—')}</div></div>
  <div class="field"><div class="field-label">Portable</div><div class="field-val">${v(edl.locatairePort, '—')}</div></div>
</div>
</div>

<!-- Équipements & accès -->
<div class="section-block">
<h2>Équipements &amp; accès</h2>
<table>
  <tr>
    <td>${checked(edl.digicode)} Digicode</td>
    <td>${checked(edl.interphone)} Interphone / Visiophone</td>
    <td>${checked(edl.alarme)} Alarme / Télésurveillance</td>
  </tr>
  <tr>
    <td>${checked(edl.triPhase)} Triphasé / Prise de force</td>
    <td>${checked(edl.ventilationForcee)} Ventilation forcée (VMC)</td>
    <td>${checked(edl.remiseCles)} Remise des clés</td>
  </tr>
</table>
<table>
  <tr><th>Mode chauffage</th><th>Énergie</th></tr>
  <tr>
    <td>${edl.chauffageMode === 'individuel' ? '☑ Individuel  ☐ Collectif  ☐ Aucun'
        : edl.chauffageMode === 'collectif'  ? '☐ Individuel  ☑ Collectif  ☐ Aucun'
        : '☐ Individuel  ☐ Collectif  ☑ Aucun'}</td>
    <td>${formatEnergie(edl.chauffageEnergie, edl.chauffageEnergieAutre)}</td>
  </tr>
</table>
</div>

<!-- Annexes -->
<div class="section-block">
<h2>Annexes</h2>
<table>
  <tr><th>Annexe</th><th>N°</th><th>État</th></tr>
  <tr><td>Parking</td><td>${v(edl.parkingNum,'—')}</td><td>${edl.parkingEtat === 'vide' ? 'Vide' : 'Non débarrassé'}</td></tr>
  <tr><td>Cave / Débarras</td><td>${v(edl.caveNum,'—')}</td><td>${edl.caveEtat === 'vide' ? 'Vide' : 'Non débarrassé'}</td></tr>
</table>
</div>

<!-- Compteurs -->
<div class="section-block">
<h2>Relevés compteurs</h2>
<div class="row" style="margin-bottom:6px">
  <div data-edl-mode="entrant" class="field"><div class="field-label">Date entrée</div><div class="field-val">${d(edl.dateEntree)}</div></div>
  <div data-edl-mode="sortant" class="field"><div class="field-label">Date sortie</div><div class="field-val">${d(edl.dateSortie)}</div></div>
</div>
<table>
  <tr><th>Fluide</th><th>N° compteur</th><th data-edl-mode="entrant">Index entrée</th><th data-edl-mode="sortant">Index sortie</th><th>Abonnement</th></tr>
  ${compteurRow('eauFroide', 'Eau')}
  ${compteurRow('elect', 'Électricité')}
  ${compteurRow('gaz', 'Gaz')}
</table>
</div>

<!-- Zones / Espaces -->
<div class="section-block">
<h2>Description zone par zone — TB : Très bon · B : Bon · P : Passable · M : Mauvais</h2>
<table>
  <tr style="background:#1e3a5f;color:white">
    <th data-edl-phase-label>Zone / EDL</th><th>Plafond</th><th>Murs</th><th>Sols</th><th>Menuiseries</th>
    <th>Équipements</th><th>Observations</th>
  </tr>
  ${zonesHTML}
</table>
</div>

<!-- Observations -->
<div class="section-block">
<h2>Observations particulières</h2>
<table>
  <tr>
    <th data-edl-mode="entrant" style="width:50%;background:#d1fae5;color:#065f46">↩ Entrée</th>
    <th data-edl-mode="sortant" style="width:50%;background:#fee2e2;color:#991b1b">↪ Sortie</th>
  </tr>
  <tr>
    <td data-edl-mode="entrant" style="white-space:pre-line;vertical-align:top;min-height:40px">${v(edl.observationsEntree, '—')}</td>
    <td data-edl-mode="sortant" style="white-space:pre-line;vertical-align:top;min-height:40px">${v(edl.observationsSortie, '—')}</td>
  </tr>
</table>
</div>

${photosHTML(edl.photos)}

<!-- Signatures -->
<div class="section-signatures">
<h2>Signatures</h2>
<div style="display:flex;gap:20px">
  <div data-edl-mode="entrant" style="flex:1">
    <div style="font-weight:bold;margin-bottom:4px">EDL Entrant — ${d(edl.dateSignatureEntrant)}</div>
    <div class="footer-sig">
      <div class="footer-sig-item">
        <div class="field-label">Pour le propriétaire / Métropole</div>
        <div class="field-val" style="margin-bottom:3px">${v(edl.sigProprietaireEntrant,'')}</div>
        ${sigImg(edl.sigImgProprietaireEntrant)}
      </div>
      <div class="footer-sig-item">
        <div class="field-label">Pour l'occupant / Locataire</div>
        <div class="field-val" style="margin-bottom:3px">${v(edl.sigLocataireEntrant,'')}</div>
        ${sigImg(edl.sigImgLocataireEntrant)}
      </div>
    </div>
  </div>
  <div data-edl-mode="sortant" style="flex:1">
    <div style="font-weight:bold;margin-bottom:4px">EDL Sortant — ${d(edl.dateSignatureSortant)}</div>
    <div class="footer-sig">
      <div class="footer-sig-item">
        <div class="field-label">Pour le propriétaire / Métropole</div>
        <div class="field-val" style="margin-bottom:3px">${v(edl.sigProprietaireSortant,'')}</div>
        ${sigImg(edl.sigImgProprietaireSortant)}
      </div>
      <div class="footer-sig-item">
        <div class="field-label">Pour l'occupant / Locataire</div>
        <div class="field-val" style="margin-bottom:3px">${v(edl.sigLocataireSortant,'')}</div>
        ${sigImg(edl.sigImgLocataireSortant)}
      </div>
    </div>
  </div>
</div>

<p style="font-size:8pt;margin-top:10px;font-style:italic">
  Le présent état des lieux, établi contradictoirement et accepté par les parties fait partie intégrante du contrat de location auquel il est joint.
</p>
</div>

</body></html>`;
}

// ════════════════════════════════════════════════════════════════════════════
// PDF PÉPINIÈRE (Bureau & Atelier)
// ════════════════════════════════════════════════════════════════════════════

const OPT_LABEL_PDF = {
  tresbon: 'Très bon', bon: 'Bon', usure: 'Usure normale', refaire: 'À refaire',
  casse: 'Cassé(e)', remplacer: 'À remplacer', reparer: 'À réparer',
};

function constatRow(itemLabel, constat = {}) {
  const etatLabel = OPT_LABEL_PDF[constat.etat] || '—';
  const etatColor = ['tresbon', 'bon'].includes(constat.etat) ? '#166534' : constat.etat ? '#b91c1c' : '#64748b';
  return `
    <tr>
      <td style="font-weight:600">${itemLabel}</td>
      <td style="color:${etatColor};font-weight:700;text-align:center">${etatLabel}</td>
      <td style="font-size:8pt;color:#555;white-space:pre-wrap;word-wrap:break-word;overflow-wrap:break-word">${constat.note || ''}</td>
    </tr>`;
}

function clesTableHTML(cles = []) {
  if (!cles.length) return '';
  return `
    <table>
      <thead><tr><th>Désignation</th><th style="width:80px;text-align:center">Nombre</th><th style="width:100px">État</th></tr></thead>
      <tbody>
        ${cles.map(c => `<tr>
          <td>${c.libelle}</td>
          <td style="text-align:center">${c.nombre || '—'}</td>
          <td>${c.etat || '—'}</td>
        </tr>`).join('')}
      </tbody>
    </table>`;
}

function buildPepinierebureauHTML(edl) {
  const typeEDLLabel = edl.typeEDL === 'entree' ? 'ENTRÉE' : 'SORTIE';
  const isSortie = edl.typeEDL === 'sortie';
  const pepiniere = getPepiniere(edl.pepiniereId);
  const ITEMS = [
    ['portEntree',"Porte d'entrée"], ['videophone','Vidéophone'],
    ['sol','Sol'], ['murs','Murs'], ['plafond','Plafond'], ['plinthes','Plinthes'],
    ['fenetre','Fenêtre'], ['store','Store'], ['tabletteFenetre','Tablettes de fenêtres'],
    ['interrupteurs','Interrupteurs'], ['prisesCourant','Prises de courant'],
    ['radiateur','Radiateur'], ['boiteAuxLettres','Boîtes à lettres'],
  ];
  const c = edl.constatations || {};

  return `<!DOCTYPE html><html><head><meta charset="UTF-8">
  <style>${CSS}
    .constat-table td:first-child { width: 25%; }
    .constat-table td:nth-child(2) { width: 15%; }
    .constat-table td:nth-child(3) { width: 60%; }
  </style></head><body>
  <h1>État des lieux ${typeEDLLabel} — Bureau ${pepiniere ? pepiniere.label : 'Pôle LYVE'}</h1>
  <div style="text-align:center;font-size:10pt;margin-bottom:10px;font-style:italic">
    ${pepiniere ? `${pepiniere.label} — ${pepiniere.adresse}` : 'Pépinière'}
  </div>

  <div class="section-block">
  <h2>Parties</h2>
  <div class="row">
    <div class="field">
      <div class="field-label">La Métropole de Lyon</div>
      <div style="font-size:9pt;margin-bottom:4px">SIREN 200 046 977 — 20 rue du Lac, 69003 Lyon</div>
      <div class="field-label">Représentée par</div>
      <div class="field-val">${v(edl.metropoleRepresentant)}</div>
    </div>
    <div class="field">
      <div class="field-label">L'entreprise</div>
      <div class="field-val" style="font-weight:700">${v(edl.locEntreprise)}</div>
      <div class="field-label" style="margin-top:4px">SIREN</div>
      <div class="field-val">${v(edl.locSiren)}</div>
      <div class="field-label" style="margin-top:4px">Représentée par</div>
      <div class="field-val">${v(edl.locRepresentant)}</div>
      <div class="field-label" style="margin-top:4px">Adresse</div>
      <div class="field-val">${v(edl.locAdresse)}${edl.locCp ? ', '+edl.locCp : ''}${edl.locVille ? ' '+edl.locVille : ''}</div>
    </div>
  </div>
  </div>

  <div class="section-block">
  <h2>Descriptif du local</h2>
  <div class="row">
    <div class="field">
      <div class="field-label">Local bureau n°</div>
      <div class="field-val">${v(edl.localNumero)}</div>
    </div>
    <div class="field">
      <div class="field-label">Surface</div>
      <div class="field-val">${v(edl.localSurface)} m²</div>
    </div>
    <div class="field">
      <div class="field-label">Date de l'EDL</div>
      <div class="field-val">${d(edl.dateEDL)}</div>
    </div>
  </div>
  ${isSortie && edl.nouvelleAdresse ? `
  <div style="margin-bottom:8px">
    <div class="field-label">Nouvelle adresse</div>
    <div class="field-val">${edl.nouvelleAdresse}</div>
  </div>` : ''}
  </div>

  <div class="section-block">
  <h2>Constatations — Local bureau n°${v(edl.localNumero,'…')}</h2>
  <table class="constat-table">
    <thead><tr><th>Élément</th><th style="text-align:center">État</th><th>Observations</th></tr></thead>
    <tbody>
      ${ITEMS.map(([key, lbl]) => constatRow(lbl, c[key])).join('')}
    </tbody>
  </table>

  ${edl.autresEquipements ? `
  <h3>Autres équipements / modifications</h3>
  <div style="padding:6px;border:1px solid #ccc;border-radius:4px;font-size:9pt;white-space:pre-line">${edl.autresEquipements}</div>` : ''}
  </div>

  <div class="section-block">
  <h2>Clés / Badges / Accès</h2>
  ${clesTableHTML(edl.cles)}
  </div>

  ${photosHTML(edl.photos)}

  <div class="section-signatures">
    <h2>Signatures</h2>
    <div style="font-size:9pt;margin-bottom:8px">
      Dépôt de garantie, caution : paiement à réception du titre de la trésorerie principale.<br>
      Le présent état des lieux a été dressé en deux exemplaires faisant foi.
      Les signataires déclarent avoir participé en personne à son établissement et l'approuvent sans réserve.
    </div>
    <div style="font-size:9pt;margin-bottom:10px">${v(edl.lieuSignature,'Lyon')} le ${d(edl.dateSignature)}</div>
    <div class="footer-sig">
      <div class="footer-sig-item">
        <div class="field-label">L'occupant — ${v(edl.locEntreprise,'Entreprise')}</div>
        <div class="field-val">${v(edl.sigLocataire)}</div>
        ${sigImg(edl.sigImgLocataire)}
      </div>
      <div class="footer-sig-item">
        <div class="field-label">La Métropole de Lyon — Représentée par</div>
        <div class="field-val">${v(edl.sigMetropole)}</div>
        ${sigImg(edl.sigImgMetropole)}
      </div>
    </div>
  </div>
</body></html>`;
}

function buildPepiniereaAtelierHTML(edl) {
  const typeEDLLabel = edl.typeEDL === 'entree' ? 'ENTRÉE' : 'SORTIE';
  const isSortie = edl.typeEDL === 'sortie';
  const pepiniere = getPepiniere(edl.pepiniereId);
  const ITEMS_ATELIER = [
    ['sol','Sol'],['murs','Murs'],['plafond','Plafond'],['fenetre','Fenêtre'],
    ['portEntree',"Porte d'entrée"],['porteSectionnelle','Porte sectionnelle'],
    ['portail','Portail'],['interrupteurs','Interrupteurs'],['prisesCourant','Prises de courant'],
    ['aerotherme','Aérotherme'],['vidoirs','Vidoirs'],['sousCompteurs','Sous-compteurs'],
  ];
  const ITEMS_BUREAU = [
    ['sol','Sol'],['murs','Murs'],['plafond','Plafond'],['plinthes','Plinthes'],
    ['vitres','Vitres'],['interrupteurs','Interrupteurs'],
    ['prisesCourant','Prises de courant'],['portEntree',"Porte d'entrée"],
  ];
  const ca = edl.constatationsAtelier || {};
  const cb = edl.constatationsBureau || {};

  return `<!DOCTYPE html><html><head><meta charset="UTF-8">
  <style>${CSS}
    .constat-table td:first-child { width: 25%; }
    .constat-table td:nth-child(2) { width: 15%; }
    .constat-table td:nth-child(3) { width: 60%; }
  </style></head><body>
  <h1>État des lieux ${typeEDLLabel} — Atelier ${pepiniere ? pepiniere.label : 'Pôle LYVE'}</h1>
  <div style="text-align:center;font-size:10pt;margin-bottom:10px;font-style:italic">
    ${pepiniere ? `${pepiniere.label} — ${pepiniere.adresse}` : 'Pépinière'}
  </div>

  <div class="section-block">
  <h2>Parties</h2>
  <div class="row">
    <div class="field">
      <div class="field-label">La Métropole de Lyon</div>
      <div style="font-size:9pt;margin-bottom:4px">SIREN 200 046 977 — 20 rue du Lac, 69003 Lyon</div>
      <div class="field-label">Représentée par</div>
      <div class="field-val">${v(edl.metropoleRepresentant)}</div>
    </div>
    <div class="field">
      <div class="field-label">L'entreprise</div>
      <div class="field-val" style="font-weight:700">${v(edl.locEntreprise)}</div>
      <div class="field-label" style="margin-top:4px">SIREN</div>
      <div class="field-val">${v(edl.locSiren)}</div>
      <div class="field-label" style="margin-top:4px">Représentée par</div>
      <div class="field-val">${v(edl.locRepresentant)}</div>
      <div class="field-label" style="margin-top:4px">Adresse</div>
      <div class="field-val">${v(edl.locAdresse)}${edl.locCp ? ', '+edl.locCp : ''}${edl.locVille ? ' '+edl.locVille : ''}</div>
    </div>
  </div>
  </div>

  <div class="section-block">
  <h2>Descriptif du local</h2>
  <div class="row">
    <div class="field">
      <div class="field-label">Atelier n°</div>
      <div class="field-val">${v(edl.localNumero)}</div>
    </div>
    <div class="field">
      <div class="field-label">Surface</div>
      <div class="field-val">${v(edl.localSurface)} m²</div>
    </div>
    <div class="field">
      <div class="field-label">Date de l'EDL</div>
      <div class="field-val">${d(edl.dateEDL)}</div>
    </div>
  </div>
  ${isSortie && edl.nouvelleAdresse ? `
  <div style="margin-bottom:8px">
    <div class="field-label">Nouvelle adresse</div>
    <div class="field-val">${edl.nouvelleAdresse}</div>
  </div>` : ''}
  </div>

  <div class="section-block">
  <h2>Constatations — Atelier n°${v(edl.localNumero,'…')}</h2>
  <table class="constat-table">
    <thead><tr><th>Élément</th><th style="text-align:center">État</th><th>Observations</th></tr></thead>
    <tbody>${ITEMS_ATELIER.map(([key,lbl]) => constatRow(lbl, ca[key])).join('')}</tbody>
  </table>
  ${edl.autresEquipementsAtelier ? `
  <h3>Autres équipements / modifications (atelier)</h3>
  <div style="padding:6px;border:1px solid #ccc;border-radius:4px;font-size:9pt;white-space:pre-line">${edl.autresEquipementsAtelier}</div>` : ''}
  </div>

  <div class="section-block">
  <h2>Bureau de l'atelier n°${v(edl.localNumero,'…')}</h2>
  <table class="constat-table">
    <thead><tr><th>Élément</th><th style="text-align:center">État</th><th>Observations</th></tr></thead>
    <tbody>${ITEMS_BUREAU.map(([key,lbl]) => constatRow(lbl, cb[key])).join('')}</tbody>
  </table>
  ${edl.autresEquipementsBureau ? `
  <h3>Autres équipements / modifications (bureau)</h3>
  <div style="padding:6px;border:1px solid #ccc;border-radius:4px;font-size:9pt;white-space:pre-line">${edl.autresEquipementsBureau}</div>` : ''}
  </div>

  <div class="section-block">
  <h2>Clés / Badges / Accès</h2>
  ${clesTableHTML(edl.cles)}
  </div>

  <div class="section-block">
  <h2>Relevé des compteurs</h2>
  <div class="field-label" style="margin-bottom:4px">Date de lecture : ${d(edl.dateLectureCompteurs)}</div>
  <table>
    <thead><tr><th>Compteur</th><th>N°</th><th>Index</th></tr></thead>
    <tbody>
      <tr><td>Chauffage (kWh)</td><td>${v(edl.compteurChauffageNum,'—')}</td><td>${v(edl.compteurChauffageVal,'—')}</td></tr>
      <tr><td>Eau (m³)</td><td>${v(edl.compteurEauNum,'—')}</td><td>${v(edl.compteurEauVal,'—')}</td></tr>
      <tr><td>Électricité (kWh)</td><td>${v(edl.compteurElecNum,'—')}</td><td>${v(edl.compteurElecVal,'—')}</td></tr>
    </tbody>
  </table>
  </div>

  <div class="section-block">
  <h2>Local box n°${v(edl.localBoxNumero,'…')}</h2>
  <table>
    <thead><tr><th>Élément</th><th style="text-align:center;width:20%">État</th><th>Observations</th></tr></thead>
    <tbody>${constatRow('État du local box', edl.localBoxEtat)}</tbody>
  </table>
  </div>

  ${photosHTML(edl.photos)}

  <div class="section-signatures">
    <h2>Signatures</h2>
    <div style="font-size:9pt;margin-bottom:8px">
      Dépôt de garantie, caution : paiement à réception du titre de la trésorerie principale.<br>
      Le présent état des lieux a été dressé en deux exemplaires faisant foi.
      Les signataires déclarent avoir participé en personne à son établissement et l'approuvent sans réserve.
    </div>
    <div style="font-size:9pt;margin-bottom:10px">${v(edl.lieuSignature,'Lyon')} le ${d(edl.dateSignature)}</div>
    <div class="footer-sig">
      <div class="footer-sig-item">
        <div class="field-label">L'occupant — ${v(edl.locEntreprise,'Entreprise')}</div>
        <div class="field-val">${v(edl.sigLocataire)}</div>
        ${sigImg(edl.sigImgLocataire)}
      </div>
      <div class="footer-sig-item">
        <div class="field-label">La Métropole de Lyon — Représentée par</div>
        <div class="field-val">${v(edl.sigMetropole)}</div>
        ${sigImg(edl.sigImgMetropole)}
      </div>
    </div>
  </div>
</body></html>`;
}

// ════════════════════════════════════════════════════════════════════════════
// CERTIFICAT DE SIGNATURE ÉLECTRONIQUE AVANCÉE
// ════════════════════════════════════════════════════════════════════════════

/** Calcule un hash SHA-256 du contenu documentaire (hors images base64) */
async function computeDocHash(edl) {
  // On exclut tous les champs base64 (images/signatures) du hash — seul le contenu textuel compte
  const payload = JSON.stringify(edl, (key, val) => {
    if (typeof val === 'string' && (val.startsWith('data:image') || val.startsWith('data:application'))) return '[IMAGE]';
    return val;
  });
  const encoder = new TextEncoder();
  const data = encoder.encode(payload);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/** Formate un timestamp ISO en date/heure lisible FR */
function fmtTs(iso) {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'medium' });
  } catch { return iso; }
}

/** Construit le bloc HTML du certificat SEA à injecter en fin de PDF */
/** Construit le bloc HTML du certificat SEA à injecter en fin de PDF */
function buildCertificatSEA(edl, docHash) {
  // Collecter toutes les signatures présentes avec leurs métadonnées
  const CHAMPS_SIG = [
    { img: 'sigImgLocataire',            meta: 'sigMetaLocataire',            label: 'Occupant / Locataire' },
    { img: 'sigImgMetropole',            meta: 'sigMetaMetropole',            label: 'Métropole de Lyon' },
    { img: 'sigImgProprietaireEntrant',  meta: 'sigMetaProprietaireEntrant',  label: 'Propriétaire (entrée)' },
    { img: 'sigImgLocataireEntrant',     meta: 'sigMetaLocataireEntrant',     label: 'Locataire (entrée)' },
    { img: 'sigImgProprietaireSortant',  meta: 'sigMetaProprietaireSortant',  label: 'Propriétaire (sortie)' },
    { img: 'sigImgLocataireSortant',     meta: 'sigMetaLocataireSortant',     label: 'Locataire (sortie)' },
    { img: 'sigImgEntreeProprietaire',   meta: 'sigMetaEntreeProprietaire',   label: 'Grand-Lyon / Propriétaire (entrée)' },
    { img: 'sigImgEntreeLocataire',      meta: 'sigMetaEntreeLocataire',      label: 'Locataire (entrée)' },
    { img: 'sigImgSortieProprietaire',   meta: 'sigMetaSortieProprietaire',   label: 'Grand-Lyon / Propriétaire (sortie)' },
    { img: 'sigImgSortieLocataire',      meta: 'sigMetaSortieLocataire',      label: 'Locataire (sortie)' },
  ];

  const signatairesPresents = CHAMPS_SIG.filter(c => edl[c.img] && (!isSingleVisit(edl) || !fieldVisit(c.img) || fieldVisit(c.img) === visitMode(edl)));

  if (signatairesPresents.length === 0) return '';

  const lignes = signatairesPresents.map(c => {
    const m = edl[c.meta];
    const timestamp = m?.timestamp ? fmtTs(m.timestamp) : '<em style="color:#e67e22">Signature antérieure au système de certification</em>';

    let identite = '';
    if (m) {
      const nomAff = m.nom ? `<strong>${m.nom}</strong>` : '';
      if (m.externe) {
        identite = nomAff
          ? `${nomAff} <span style="color:#888;font-size:7pt">(signataire externe)</span>`
          : '<em style="color:#888">Nom non renseigné au moment de la signature</em>';
      } else {
        const emailAff = m.email ? m.email : '<em style="color:#888">Non renseigné</em>';
        const uidAff   = m.uid   ? `<span style="color:#888;font-size:7pt"> — ID: ${m.uid}</span>` : '';
        identite = `${nomAff ? nomAff + ' — ' : ''}${emailAff}${uidAff}`;
      }
    } else {
      identite = '<em style="color:#888">Non renseigné</em>';
    }

    return `
      <tr>
        <td style="font-weight:700;width:30%">${c.label}</td>
        <td>${identite}</td>
        <td style="text-align:center">${timestamp}</td>
        <td style="text-align:center;font-size:8pt;color:${m ? '#16a34a' : '#e67e22'};font-weight:700">${m ? '✓ Certifiée' : '⚠ Non certifiée'}</td>
      </tr>`;
  }).join('');

  const exportTs = fmtTs(new Date().toISOString());

  return `
<div style="page-break-inside:avoid;margin-top:16px;border:2px solid #1e3a5f;border-radius:4px;padding:10px;background:#f0f4ff">
  <div style="font-size:11pt;font-weight:700;color:#1e3a5f;border-bottom:1px solid #1e3a5f;padding-bottom:4px;margin-bottom:8px">
    &#128737; Certificat de Signature Électronique Avancée (SEA)
  </div>
  <div style="font-size:8pt;color:#555;margin-bottom:8px">
    Ce certificat atteste de l'identité des signataires au moment de la signature électronique,
    conformément au règlement eIDAS (UE n°910/2014). Chaque signature est horodatée et liée
    au compte authentifié de son auteur.
  </div>
  <table style="width:100%;border-collapse:collapse;font-size:8pt;margin-bottom:8px">
    <thead>
      <tr style="background:#1e3a5f;color:#fff">
        <th style="padding:4px 6px;text-align:left">Partie</th>
        <th style="padding:4px 6px;text-align:left">Identifiant</th>
        <th style="padding:4px 6px;text-align:center">Date &amp; heure</th>
        <th style="padding:4px 6px;text-align:center">Statut</th>
      </tr>
    </thead>
    <tbody>${lignes}</tbody>
  </table>
  <div style="font-size:7.5pt;color:#555;border-top:1px solid #b0c0e0;padding-top:6px;margin-top:4px">
    <strong>Empreinte du document (SHA-256) :</strong>
    <span style="font-family:monospace;font-size:6.5pt;color:#1e3a5f;word-break:break-all">${docHash}</span>
    <br/>
    <strong>Date d'export PDF :</strong> ${exportTs} &nbsp;|&nbsp;
    <strong>Système :</strong> ERP Immobilier — Métropole de Lyon
  </div>
</div>`;
}

// ════════════════════════════════════════════════════════════════════════════
// EXPORT PUBLIC
// ════════════════════════════════════════════════════════════════════════════
export function buildEdlHTML(edl) {
  const html = edl.typeBien === 'terrain'
    ? buildTerrainHTML(edl)
    : edl.typeBien === 'pepiniere_bureau'
      ? buildPepinierebureauHTML(edl)
      : edl.typeBien === 'pepiniere_atelier'
        ? buildPepiniereaAtelierHTML(edl)
        : edl.typeBien === 'entrepot'
          ? buildLocalHTML(edl)
          : buildLogementHTML(edl);
  return isSingleVisit(edl) ? projectVisitHtml(html, visitMode(edl)) : html;
}

export async function exportEDLPDF(edl) {
  const html2pdf = (await import('html2pdf.js')).default;

  const html = buildEdlHTML(edl);

  // Templates and projection are shared with content regression tests.

  // ── PATTERN IDENTIQUE à pdfService.js / PlanEditor / FicheBatiment (qui fonctionnent) ──
  const docHash = await computeDocHash(edl);
  const certificatHTML = buildCertificatSEA(edl, docHash);

  const cssMatch  = html.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
  const bodyMatch = html.match(/<body[^>]*>([\s\S]*)<\/body>/i);
  const cssText   = cssMatch  ? cssMatch[1]  : '';
  const bodyHTML  = (bodyMatch ? bodyMatch[1] : html) + certificatHTML;

  const container = document.createElement('div');
  container.style.cssText = [
    'font-family:Arial,Helvetica,sans-serif',
    'font-size:9pt',
    'color:#000',
    'background:#fff',
    'padding:10px',
    '--text:#000', '--text-sub:#555', '--text-muted:#888',
    '--bg:#fff', '--bg-card:#fff', '--bg-panel:#f9fafb',
    '--border:#ccc', '--border-strong:#aaa',
  ].join(';');
  container.innerHTML = '<style>' + scopeLegacyPdfCss(cssText) + '</style>' + bodyHTML;
  document.body.appendChild(container);

  const nomLocataire = (edl.typeBien === 'pepiniere_bureau' || edl.typeBien === 'pepiniere_atelier')
    ? (edl.locEntreprise || edl.locRepresentant || 'pepiniere')
    : edl.typeBien === 'terrain'
      ? (edl.locNom || edl.locRaisonSociale || 'terrain')
      : edl.typeBien === 'entrepot'
        ? (edl.locataireSociete || edl.locataireNom || 'local')
        : (edl.locataireNom || 'locataire');
  const filename = `EDL_${labelType(edl.typeBien).replace(/[^a-zA-Z0-9]/g, '_')}_${isSingleVisit(edl) ? visitMode(edl) + '_' : ''}${nomLocataire}_${edl.dateEDL || edl.dateEntree || 'date'}.pdf`;

  try {
    await preparePdfDocument(container, 'ÉTAT DES LIEUX');
    const worker = html2pdf()
      .set({
        margin:      (await import('../../../../infrastructure/pdf/metropoleBranding')).PDF_DOCUMENT_MARGINS,
        filename,
        html2canvas: { scale: 2, useCORS: true, backgroundColor: '#ffffff' },
        pagebreak:   { mode: ['css'] },
        jsPDF:       {
          unit: 'mm', format: 'a4', orientation: 'portrait',
          encryption: {
            userPassword:    '',
            ownerPassword:   'GL-EDL-Metro2026!',
            userPermissions: ['print'],
          },
        },
      })
      .from(container)
      .toPdf();
    const pdfObj = await worker.get('pdf');
    if (isSingleVisit(edl)) {
      const canvas = await worker.get('canvas');
      const pageSize = await worker.get('pageSize');
      trimEmptyPdfPages(pdfObj, canvas, pageSize.inner.ratio);
    }

    const { applyMetropoleBranding } = await import('../../../../infrastructure/pdf/metropoleBranding');
    applyMetropoleBranding(pdfObj);
    const blob = pdfObj.output('blob');

    const { deliverGeneratedPdf } = await import('../../../../infrastructure/share/documentDelivery');
    return deliverGeneratedPdf(filename, blob);
  } finally {
    document.body.removeChild(container);
  }
}

export function buildMailtoLink({ userEmail, recipientEmail, edl, pdfFilename }) {
  const isPep = edl.typeBien === 'pepiniere_bureau' || edl.typeBien === 'pepiniere_atelier';
  const nomBien = isPep
    ? `Local n°${edl.localNumero || '—'}`
    : edl.typeBien === 'terrain'
      ? (edl.adresseBien || edl.parcelle || 'terrain')
      : edl.typeBien === 'entrepot'
        ? (edl.adresseRue || edl.porte || 'local')
        : (edl.adresseRue || 'bien');
  const locataire = isPep
    ? (edl.locEntreprise || edl.locRepresentant || '')
    : edl.typeBien === 'terrain'
      ? [edl.locNom, edl.locPrenom].filter(Boolean).join(' ') || edl.locRaisonSociale
      : edl.typeBien === 'entrepot'
        ? (edl.locataireSociete || [edl.locataireNom, edl.locatairePrenom].filter(Boolean).join(' '))
        : [edl.locataireNom, edl.locatairePrenom].filter(Boolean).join(' ') || edl.locataireSociete;
  const typeLabel = labelType(edl.typeBien);
  const dateLabel = new Date(edl.dateEDL || edl.dateEntree || Date.now()).toLocaleDateString('fr-FR');

  const subject = encodeURIComponent(`État des lieux — ${typeLabel} — ${nomBien} — ${dateLabel}`);
  const body = encodeURIComponent(
    `Bonjour,\n\nVeuillez trouver ci-joint l'état des lieux du bien suivant :\n\n` +
    `  Type : ${typeLabel}\n` +
    `  Adresse : ${nomBien}\n` +
    `  Locataire : ${locataire || '—'}\n` +
    `  Date : ${dateLabel}\n\n` +
    `Le PDF "${pdfFilename}" a été téléchargé sur votre appareil.\n` +
    `Merci de le joindre à cet email avant envoi.\n\n` +
    `Cordialement,\n${userEmail}`
  );

  const to = recipientEmail ? encodeURIComponent(recipientEmail) : '';
  return `mailto:${to}?from=${encodeURIComponent(userEmail)}&subject=${subject}&body=${body}`;
}
