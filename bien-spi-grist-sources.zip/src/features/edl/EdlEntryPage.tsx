import { useEffect, useRef, useState } from 'react';
import { ArchiveRestore, FileDown, FolderOpen, Save } from 'lucide-react';
import { AppHeader } from '../../components/AppHeader';
import { SaveStatus, type SaveState } from '../../components/SaveStatus';
import { navigate, queryValue } from '../../hooks/useRoute';
import { listRecords, loadRecord, reopenRecord, saveRecord } from '../../infrastructure/storage/records';
import type { StoredRecord } from '../../domain/shared/types';
import { createId } from '../../domain/shared/types';
import EDLFormV2 from './legacy/components/EDLFormV2.jsx';
import { normalizeForStorage, typeLabel } from './legacy/localModel.js';
import { generateEdlPdf } from '../../infrastructure/pdf/EdlPdfService';
import { registerFlush } from '../../infrastructure/storage/flushRegistry';
import { ShareDocumentAction } from '../../app/components/ShareDocumentAction';
import { pdfReadyMessage } from '../../infrastructure/share/documentDelivery';
import type { ShareFile } from '../../domain/shared/integrationPorts';
import { inspectLegacyEdlJson } from './importLegacyEdl';
import { createVisit, isSingleVisit, prepareExit, visitLabel, visitMode } from './edlVisit';

type EdlData = Record<string, unknown> & { typeBien?: string; dateEDL?: string };

export function EdlEntryPage({ type, search }: { type: string; search: string }) {
  const bienId = queryValue(search, 'bienId');
  const requestedId = queryValue(search, 'id');
  const mode = queryValue(search, 'mode') === 'sortant' ? 'sortant' : 'entrant';
  const [recordId, setRecordId] = useState(requestedId || createId('edl'));
  const [form, setForm] = useState<EdlData>(() => createVisit(type, mode));
  const [ready, setReady] = useState(!requestedId);
  const [loadError, setLoadError] = useState('');
  const [linkedBienId, setLinkedBienId] = useState(bienId);
  const [exitBusy, setExitBusy] = useState(false);
  const saveQueue = useRef<Promise<unknown>>(Promise.resolve());
  const skipLoadedAutosave = useRef(false);
  const active = useRef(true);
  useEffect(() => { active.current = true; return () => { active.current = false; }; }, []);
  const [records, setRecords] = useState<StoredRecord<EdlData>[]>([]);
  const [saveState, setSaveState] = useState<SaveState>('idle');
  const [pdfMessage, setPdfMessage] = useState('');
  const [pdfFile, setPdfFile] = useState<ShareFile | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const pdfLock = useRef(false);
  const importInput = useRef<HTMLInputElement>(null);
  const currentRecord = records.find((record) => record.id === recordId);

  const refresh = async () => setRecords((await listRecords<EdlData>('edl', bienId || undefined)).filter((item) => item.payload.typeBien === type));
  useEffect(() => { void refresh(); }, [bienId, type]);
  useEffect(() => {
    if (!requestedId) return;
    let cancelled = false;
    void loadRecord<EdlData>(requestedId).then((record) => {
      if (cancelled) return;
      if (!record || record.kind !== 'edl' || record.payload.typeBien !== type || record.status === 'trashed') {
        setLoadError('Ce dossier EDL est introuvable ou incompatible. Aucun dossier n’a été modifié.'); return;
      }
      skipLoadedAutosave.current = true;
      setForm(record.payload); setRecordId(record.id); setLinkedBienId(record.bienId || ''); setReady(true);
    }).catch(() => { if (!cancelled) setLoadError('Impossible de charger cet EDL. Réessayez sans effacer les données de l’application.'); });
    return () => { cancelled = true; };
  }, [requestedId, type]);

  const persist = async (status?: 'draft' | 'finalized') => {
    if (!ready) return null;
    setSaveState('saving');
    try {
      const operation = saveQueue.current.catch(() => {}).then(() => saveRecord({ id: recordId, kind: 'edl', bienId: linkedBienId || undefined, payload: normalizeForStorage(form, 'Agent SPI'), status }));
      saveQueue.current = operation;
      const saved = await operation;
      if (!active.current) return saved;
      const params = new URLSearchParams({ ...(linkedBienId ? { bienId: linkedBienId } : {}), id: saved.id });
      window.history.replaceState({}, '', `/edl/new/${type}?${params}`);
      setRecordId(saved.id); setSaveState('saved'); await refresh(); return saved;
    } catch { setSaveState('error'); return null; }
  };
  useEffect(() => registerFlush(() => persist()), [form, recordId, ready, linkedBienId]);

  useEffect(() => {
    if (!ready) return;
    if (skipLoadedAutosave.current) { skipLoadedAutosave.current = false; return; }
    setSaveState('saving');
    const timer = window.setTimeout(() => { void persist(); }, 700);
    return () => window.clearTimeout(timer);
  }, [form]);

  const openRecord = async (id: string) => {
    if (!(await persist())) return;
    navigate(id ? `/edl/new/${type}?${new URLSearchParams({ ...(bienId ? { bienId } : {}), id })}` : `/edl/mode/${type}${bienId ? `?bienId=${encodeURIComponent(bienId)}` : ''}`);
  };
  const prepareDeparture = async () => {
    if (exitBusy) return;
    setExitBusy(true);
    try {
      const source = await persist();
      if (!source) throw new Error('save');
      const exit = await saveRecord({ kind: 'edl', bienId: source.bienId, payload: prepareExit(source.payload, source.id) });
      navigate(`/edl/new/${type}?${new URLSearchParams({ id: exit.id, ...(source.bienId ? { bienId: source.bienId } : {}) })}`);
    } catch { setPdfMessage('Impossible de préparer la sortie. L’entrée est conservée ; vérifiez sa sauvegarde.'); }
    finally { setExitBusy(false); }
  };
  const exportPdf = async () => {
    if (pdfLock.current) return;
    pdfLock.current = true; setPdfBusy(true); setPdfFile(null);
    setPdfMessage('Génération du PDF…');
    try {
      const saved = await persist('finalized');
      if (!saved) throw new Error('save');
      const result = await generateEdlPdf(saved.payload);
      setPdfFile({ name: result.filename, blob: result.blob, type: 'application/pdf' });
      setPdfMessage(pdfReadyMessage());
    } catch {
      setPdfMessage('Export impossible. Vérifiez l’état de sauvegarde de la saisie puis réessayez.');
    } finally { pdfLock.current = false; setPdfBusy(false); }
  };

  if (!ready) return <><AppHeader title="Chargement EDL" backTo="/edl" /><main className="bs-page" role="status">{loadError || 'Chargement du dossier…'}</main></>;
  return <>
    <AppHeader beforeNavigate={async () => Boolean(await persist())} title={`EDL · ${typeLabel(type)} · ${visitLabel(form)}`} backTo={`/edl/mode/${type}${linkedBienId ? `?bienId=${encodeURIComponent(linkedBienId)}` : ''}`} />
    <main className="bs-form-shell">
      <div className="bs-form-toolbar">
        <h1>EDL · {typeLabel(type)} · {visitLabel(form)}</h1>
        <label className="bs-inline-select"><FolderOpen /><select aria-label="Reprendre un EDL" value={currentRecord ? recordId : ''} onChange={(event) => void openRecord(event.target.value)}><option value="">Nouveau</option>{records.map((record) => <option key={record.id} value={record.id}>{record.status === 'archived' ? '[Archivé] ' : ''}{visitLabel(record.payload)} · {String(record.payload.dateEDL || '').slice(0,10)} · révision {record.revision}</option>)}</select></label>
        {isSingleVisit(form) && visitMode(form) === 'entrant' && <button className="bs-button" type="button" disabled={exitBusy} onClick={() => void prepareDeparture()}>{exitBusy ? 'Préparation…' : 'Préparer la sortie depuis cette entrée'}</button>}
        {typeof form.sourceEntryId === 'string' && <button className="bs-button" type="button" onClick={() => void openRecord(form.sourceEntryId as string)}>Consulter l’entrée d’origine</button>}
        {currentRecord && <span className={`bs-record-status is-${currentRecord.status}`}>{currentRecord.status === 'archived' ? 'Archivé' : currentRecord.status === 'finalized' ? 'Finalisé' : 'Brouillon'}</span>}
        <SaveStatus state={saveState} />
        <button className="bs-button" type="button" onClick={() => void persist()}><Save />Sauvegarder</button>
        {currentRecord?.status === 'archived' && <button className="bs-button" type="button" onClick={async () => { await reopenRecord(currentRecord.id); await refresh(); }}><ArchiveRestore />Réouvrir</button>}
        <input ref={importInput} hidden type="file" accept="application/json,.json" onChange={async (event) => {
          const file = event.target.files?.[0]; event.target.value = ''; if (!file) return;
          try {
            const preview = inspectLegacyEdlJson(await file.text());
            if (!(await persist())) throw new Error('save');
            const imported = await saveRecord({ kind: 'edl', bienId: linkedBienId || undefined, payload: preview.payload });
            navigate(`/edl/new/${preview.payload.typeBien}?${new URLSearchParams({ id: imported.id, ...(linkedBienId ? { bienId: linkedBienId } : {}) })}`);
          }
          catch { setPdfMessage('Import refusé : ce fichier ne correspond pas à un EDL reconnu.'); }
        }} />
        <button className="bs-button is-primary" type="button" disabled={pdfBusy} onClick={() => void exportPdf()}><FileDown />{pdfBusy ? 'Génération…' : 'Exporter PDF'}</button>
        {pdfMessage && <span className="bs-pdf-message" role="status">{pdfMessage}</span>}
        {pdfFile && <ShareDocumentAction file={pdfFile} title={`EDL ${typeLabel(type)}`} />}
      </div>
      <EDLFormV2 form={form} onChange={setForm} onSave={() => void persist()} onCancel={async () => { if (await persist()) navigate(linkedBienId ? `/biens/new?id=${linkedBienId}` : '/'); }} isEditing={Boolean(currentRecord)} utilisateurs={[]} user={{ uid: 'local', email: '', displayName: 'Agent SPI' }} userProfile={{ displayName: 'Agent SPI' }} />
    </main>
  </>;
}
