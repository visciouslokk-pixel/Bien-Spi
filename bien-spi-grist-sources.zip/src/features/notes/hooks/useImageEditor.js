import { useState, useRef } from 'react';

export function useImageEditor(sauvegarderNote) {
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [imgSize, setImgSize] = useState(100);
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [penColor, setPenColor] = useState('#dc2626');
  const [originalImg, setOriginalImg] = useState(null);
  const imageCibleRef = useRef(null);

  const ouvrirEditeur = (imgElement) => {
    imageCibleRef.current = imgElement; 
    const img = new Image();
    img.onload = () => {
      setOriginalImg(img); 
      setIsEditorOpen(true);
      setTimeout(() => {
        const canvas = canvasRef.current;
        if (canvas) { 
          canvas.width = img.width; 
          canvas.height = img.height; 
          canvas.getContext('2d').drawImage(img, 0, 0); 
        }
      }, 100);
    };
    img.src = imgElement.src; 
    setImgSize(parseInt(imgElement.style.width || "100"));
  };

  const effacerDessin = () => {
    const canvas = canvasRef.current; 
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height); 
    if (originalImg) ctx.drawImage(originalImg, 0, 0);
  };

  const validerEditeur = () => {
    const imageCible = imageCibleRef.current;
    if (imageCible) { 
      imageCible.src = canvasRef.current.toDataURL('image/jpeg', 0.8); 
      imageCible.style.width = imgSize + '%'; 
      sauvegarderNote(); 
    }
    setIsEditorOpen(false);
  };

  const draw = (e) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current; 
    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width); 
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);
    ctx.lineWidth = 4; 
    ctx.strokeStyle = penColor; 
    ctx.lineCap = 'round'; 
    ctx.lineTo(x, y); 
    ctx.stroke();
  };

  const handleMouseDown = (e) => {
    setIsDrawing(true); 
    const ctx = canvasRef.current.getContext('2d'); 
    ctx.beginPath(); 
    draw(e);
  };

  return {
    isEditorOpen, setIsEditorOpen, imgSize, setImgSize,
    canvasRef, isDrawing, setIsDrawing, penColor, setPenColor,
    ouvrirEditeur, effacerDessin, validerEditeur, draw, handleMouseDown
  };
}
