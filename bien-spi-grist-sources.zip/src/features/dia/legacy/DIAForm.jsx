import { compressedPhotoDataUrl } from '../../../infrastructure/media/compressPhoto';
// src/features/rapports/components/DIAForm.jsx
import React, { useState, useEffect } from 'react';
import { MapPin, Loader2, Map } from 'lucide-react';
import { normalizeCommune } from '../../../utils/commune';

// ── Communes Métropole de Lyon ─────────────────────────────────────────────
const COMMUNES_METROPOLE = [
  'Lyon 1er', 'Lyon 2ème', 'Lyon 3ème', 'Lyon 4ème', 'Lyon 5ème',
  'Lyon 6ème', 'Lyon 7ème', 'Lyon 8ème', 'Lyon 9ème',
  'Bron', 'Caluire-et-Cuire', 'Champagne-au-Mont-d\'Or',
  'Charbonnières-les-Bains', 'Chassieu', 'Collonges-au-Mont-d\'Or',
  'Corbas', 'Craponne', 'Curis-au-Mont-d\'Or', 'Décines-Charpieu',
  'Écully', 'Feyzin', 'Fleurieu-sur-Saône', 'Fontaines-Saint-Martin',
  'Fontaines-sur-Saône', 'Francheville', 'Genay', 'Givors', 'Grigny',
  'Irigny', 'Jonage', 'Jons', 'La Mulatière', 'La Tour-de-Salvagny',
  'Limonest', 'Lissieu', 'Marcy-l\'Étoile', 'Meyzieu', 'Mions',
  'Montanay', 'Neuville-sur-Saône', 'Oullins-Pierre-Bénite',
  'Poleymieux-au-Mont-d\'Or', 'Quincieux', 'Rillieux-la-Pape',
  'Saint-Cyr-au-Mont-d\'Or', 'Saint-Didier-au-Mont-d\'Or', 'Saint-Fons',
  'Saint-Genis-Laval', 'Saint-Genis-les-Ollières',
  'Saint-Germain-au-Mont-d\'Or', 'Saint-Priest',
  'Saint-Romain-au-Mont-d\'Or', 'Sainte-Foy-lès-Lyon',
  'Sathonay-Camp', 'Sathonay-Village', 'Solaize',
  'Tassin-la-Demi-Lune', 'Vaulx-en-Velin', 'Vénissieux',
  'Vernaison', 'Villeurbanne',
];

// ── Styles partagés ──────────────────────────────────────────────────────────
const SEC_HEADER = {
  background: 'var(--ds-red-strong)', color: 'white', padding: '8px 12px',
  fontWeight: '700', fontSize: '16px', textTransform: 'none',
  letterSpacing: '0.05em', borderRadius: '4px 4px 0 0',
};
const SEC_BODY = {
  border: '1px solid var(--border-strong)', borderTop: 'none', padding: '12px',
  borderRadius: '0 0 4px 4px', background: 'var(--card)',
};
const LABEL_SM = { fontSize: '12px', fontWeight: '600', color: 'var(--text)', marginBottom: '4px', display: 'block' };
const INPUT_SM = { padding: '8px 10px', border: '1px solid var(--border)', borderRadius: '6px', fontSize: '16px', width: '100%', boxSizing: 'border-box', background: 'var(--input)', color: 'var(--text)' };
const CB_ROW = { display: 'flex', alignItems: 'center', gap: '8px', minHeight: '48px', marginBottom: '4px', cursor: 'pointer', fontSize: '14px' };

// ── Case à cocher ────────────────────────────────────────────────────────────
function CB({ checked, onChange, label }) {
  return (
    <label style={CB_ROW}>
      <input type="checkbox" checked={!!checked} onChange={e => onChange(e.target.checked)}
        style={{ width: '15px', height: '15px', cursor: 'pointer', accentColor: 'var(--ds-red-strong)' }} />
      <span>{label}</span>
    </label>
  );
}

// ── Section ──────────────────────────────────────────────────────────────────
function Section({ title, children, color = '#1e3a5f' }) {
  return (
    <div style={{ marginBottom: '12px' }}>
      <div style={SEC_HEADER} data-section-color={color}>{title}</div>
      <div style={SEC_BODY}>{children}</div>
    </div>
  );
}

// ── Miniature SVG d'un plan ──────────────────────────────────────────────────
function PlanMini({ elements, height = 80 }) {
  const LINE_TYPES = new Set(['wall','wall-thin','wall-ext','beam','foundation',
    'roof-ridge','roof-valley','roof-hip','rafter','purlin','ridge-board','joist']);

  if (!elements?.length) return (
    <div style={{ height, background: 'var(--bg-panel)', display: 'flex', alignItems: 'center',
      justifyContent: 'center', fontSize: 11, color: '#cbd5e1', borderRadius: 6 }}>
      Plan vide
    </div>
  );

  let minX=Infinity, minY=Infinity, maxX=-Infinity, maxY=-Infinity;
  elements.forEach(el => {
    if (LINE_TYPES.has(el.type)) {
      minX = Math.min(minX, el.x1, el.x2); minY = Math.min(minY, el.y1, el.y2);
      maxX = Math.max(maxX, el.x1, el.x2); maxY = Math.max(maxY, el.y1, el.y2);
    } else if (el.x !== undefined) {
      minX = Math.min(minX, el.x); minY = Math.min(minY, el.y - (el.height||40)/2);
      maxX = Math.max(maxX, el.x + (el.width||80)); maxY = Math.max(maxY, el.y + (el.height||40)/2);
    }
  });
  if (!isFinite(minX)) return null;
  const pad = 20, vw = maxX-minX+pad*2, vh = maxY-minY+pad*2;
  const vb = `${minX-pad} ${minY-pad} ${vw} ${vh}`;

  const colorMap = { wall:'#1e293b','wall-thin':'#475569','wall-ext':'#0f172a',
    beam:'#7c3aed',foundation:'#78350f','roof-ridge':'#b45309','roof-valley':'#b45309',
    'roof-hip':'#b45309',rafter:'#92400e',purlin:'#92400e','ridge-board':'#92400e',joist:'#92400e' };

  return (
    <svg viewBox={vb} style={{ width: '100%', height, background: 'var(--bg-panel)',
      border: '1px solid var(--border)', borderRadius: 6 }}>
      {elements.map(el => {
        if (LINE_TYPES.has(el.type))
          return <line key={el.id} x1={el.x1} y1={el.y1} x2={el.x2} y2={el.y2}
            stroke={colorMap[el.type]||'#475569'} strokeWidth={el.thickness||8} strokeLinecap="square"/>;
        if (el.x !== undefined) {
          const w = el.width||60, h = el.height||40;
          return <rect key={el.id} x={el.x} y={el.y-h/2} width={w} height={h}
            fill="#dbeafe" stroke="#2563eb" strokeWidth={1.5} rx={2}/>;
        }
        return null;
      })}
    </svg>
  );
}

// ── Modal d'import d'un plan ─────────────────────────────────────────────────
function PlanImportModal({ plans, onSelect, onClose }) {
  const [search, setSearch] = useState('');
  const filtered = plans.filter(p =>
    p.nom?.toLowerCase().includes(search.toLowerCase()) ||
    p.chantierId?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 2000,
      background: 'rgba(0,0,0,0.6)', display: 'flex',
      alignItems: 'center', justifyContent: 'center',
    }} onClick={onClose}>
      <div style={{
        background: 'var(--bg-card)', borderRadius: 14, padding: 24, width: 600,
        maxHeight: '80vh', display: 'flex', flexDirection: 'column',
        boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
      }} onClick={e => e.stopPropagation()}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>📐 Importer un plan</h3>
          <button onClick={onClose} style={{ border: 'none', background: 'none', fontSize: 20, cursor: 'pointer', color: 'var(--text-muted)' }}>✕</button>
        </div>

        <input
          type="text" placeholder="Rechercher un plan..."
          value={search} onChange={e => setSearch(e.target.value)}
          style={{ ...INPUT_SM, marginBottom: 16 }}
          autoFocus
        />

        {filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '32px 0', color: 'var(--text-muted)', fontSize: 13 }}>
            Aucun plan trouvé.<br/>
            <span style={{ fontSize: 12 }}>Créez un plan dans la section Plans (sans chantier obligatoire).</span>
          </div>
        ) : (
          <div style={{ overflowY: 'auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {filtered.map(plan => (
              <div key={plan.id}
                onClick={() => onSelect(plan)}
                style={{
                  border: '1px solid var(--border)', borderRadius: 10, padding: 12,
                  cursor: 'pointer', transition: 'all .15s',
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = '#2563eb'; e.currentTarget.style.background = '#eff6ff'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = '#e2e8f0'; e.currentTarget.style.background = 'white'; }}
              >
                <PlanMini elements={plan.elements} height={70} />
                <div style={{ marginTop: 8, fontSize: 13, fontWeight: 700, color: 'var(--text)' }}>{plan.nom}</div>
                {plan.chantierId && (
                  <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>🏗 {plan.chantierId}</div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Composant principal ──────────────────────────────────────────────────────
export default function DIAForm({ dia, onChange, ajouterPhoto, supprimerPhoto, modifierLegende, availablePlans = [] }) {
  const plans = availablePlans;
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [geocodage, setGeocodage] = useState({ loading: false, error: null });

  const set = (key, val) => onChange({ ...dia, [key]: val });

  // ── Générer une carte OSM en base64 via tuiles (CORS-safe) ──────────────
  const generateOSMMapBase64 = async (lat, lon) => {
    const zoom = 16, TILE_SIZE = 256, GRID = 3;
    const n = Math.pow(2, zoom);
    const centerX = Math.floor((lon + 180) / 360 * n);
    const latRad = lat * Math.PI / 180;
    const centerY = Math.floor((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2 * n);
    const canvas = document.createElement('canvas');
    canvas.width = TILE_SIZE * GRID;
    canvas.height = TILE_SIZE * GRID;
    const ctx = canvas.getContext('2d');
    const loadTile = (tx, ty, dx, dy) => new Promise(resolve => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => { ctx.drawImage(img, dx * TILE_SIZE, dy * TILE_SIZE, TILE_SIZE, TILE_SIZE); resolve(); };
      img.onerror = () => resolve();
      img.src = `https://tile.openstreetmap.org/${zoom}/${tx}/${ty}.png`;
    });
    const promises = [];
    for (let dy = 0; dy < GRID; dy++)
      for (let dx = 0; dx < GRID; dx++)
        promises.push(loadTile(centerX + dx - 1, centerY + dy - 1, dx, dy));
    await Promise.all(promises);
    // Calcul position exacte du marqueur sur le canvas composite
    const exactX = ((lon + 180) / 360 * n - (centerX - 1)) * TILE_SIZE;
    const exactY = ((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2 * n - (centerY - 1)) * TILE_SIZE;
    // Dessin de l'épingle rouge
    ctx.fillStyle = '#dc2626';
    ctx.beginPath(); ctx.arc(exactX, exactY - 14, 10, 0, 2 * Math.PI); ctx.fill();
    ctx.strokeStyle = 'white'; ctx.lineWidth = 3; ctx.stroke();
    ctx.fillStyle = 'white';
    ctx.beginPath(); ctx.arc(exactX, exactY - 14, 4, 0, 2 * Math.PI); ctx.fill();
    ctx.fillStyle = '#dc2626';
    ctx.beginPath();
    ctx.moveTo(exactX - 7, exactY - 8); ctx.lineTo(exactX + 7, exactY - 8); ctx.lineTo(exactX, exactY);
    ctx.fill();
    // Attribution OSM
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.fillRect(0, canvas.height - 18, 230, 18);
    ctx.fillStyle = '#555'; ctx.font = '10px Arial';
    ctx.fillText('© OpenStreetMap contributors', 4, canvas.height - 5);
    try { return canvas.toDataURL('image/jpeg', 0.85); } catch { return null; }
  };

  // ── Géocodage Nominatim ──────────────────────────────────────────────────
  // normalizeCommune importé depuis utils/commune.js

  const localiser = async () => {
    const adresse = (dia.adresse || '').trim();
    const commune = (dia.commune || '').trim();
    if (!adresse && !commune) {
      setGeocodage({ loading: false, error: 'Renseignez l\'adresse et/ou la commune d\'abord.' });
      return;
    }
    setGeocodage({ loading: true, error: null });
    const communeGeo = normalizeCommune(commune);
    const q = [adresse, communeGeo, 'France'].filter(Boolean).join(', ');
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&limit=1&countrycodes=fr`,
        { headers: { 'Accept-Language': 'fr-FR,fr;q=0.9' } }
      );
      const data = await res.json();
      if (data.length > 0) {
        const lat = parseFloat(data[0].lat);
        const lon = parseFloat(data[0].lon);
        // Génération de la carte via tuiles OSM (CORS-safe → base64 fiable pour PDF)
        const mapBase64 = await generateOSMMapBase64(lat, lon);
        onChange({ ...dia, mapLat: lat, mapLon: lon, mapBase64: mapBase64 || null });
        setGeocodage({ loading: false, error: null });
      } else {
        setGeocodage({ loading: false, error: 'Adresse introuvable — essayez une adresse plus précise.' });
      }
    } catch {
      setGeocodage({ loading: false, error: 'Erreur de connexion au service de géolocalisation.' });
    }
  };

  // ── Import plan ──────────────────────────────────────────────────────────
  const importerPlan = (plan) => {
    onChange({ ...dia, planImporte: { id: plan.id, nom: plan.nom, elements: plan.elements || [] } });
    setShowPlanModal(false);
  };

  // ── OSM embed URL ────────────────────────────────────────────────────────
  const osmUrl = dia.mapLat && dia.mapLon
    ? `https://www.openstreetmap.org/export/embed.html?bbox=${dia.mapLon - 0.004},${dia.mapLat - 0.003},${dia.mapLon + 0.004},${dia.mapLat + 0.003}&layer=mapnik&marker=${dia.mapLat},${dia.mapLon}`
    : null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>

      {/* ══ COMMUNE — liste déroulante ════════════════════════════════════════ */}
      <Section title="Commune — Métropole de Lyon" color="#1e3a5f">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', alignItems: 'center' }}>
          <div>
            <label style={LABEL_SM}>Commune *</label>
            <select
              style={{ ...INPUT_SM, cursor: 'pointer' }}
              value={dia.commune || ''}
              onChange={e => set('commune', e.target.value)}
            >
              <option value="">— Sélectionner une commune —</option>
              {COMMUNES_METROPOLE.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          {dia.commune && (
            <div style={{
              background: '#dbeafe', border: '1px solid #93c5fd',
              borderRadius: 8, padding: '8px 12px', fontSize: 13,
              color: '#1d4ed8', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6,
            }}>
              <MapPin size={14} /> {dia.commune}
            </div>
          )}
        </div>
      </Section>

      {/* ══ IDENTIFICATION DU BIEN ═══════════════════════════════════════════ */}
      <Section title="Identification du bien" color="#1e3a5f">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' }}>
          <div>
            <label style={LABEL_SM}>Adresse</label>
            <input style={INPUT_SM} value={dia.adresse || ''} onChange={e => set('adresse', e.target.value)} placeholder="Adresse complète" />
          </div>
          <div>
            <label style={LABEL_SM}>Identifiant Fiscal</label>
            <input style={INPUT_SM} value={dia.identifiantFiscal || ''} onChange={e => set('identifiantFiscal', e.target.value)} placeholder="Ex: 123456789" />
          </div>
          <div>
            <label style={LABEL_SM}>Année de construction</label>
            <input style={INPUT_SM} value={dia.anneeConstruction || ''} onChange={e => set('anneeConstruction', e.target.value)} placeholder="Ex: 1975" />
          </div>
          <div>
            <label style={LABEL_SM}>Type de bien</label>
            <input style={INPUT_SM} value={dia.typeBien || ''} onChange={e => set('typeBien', e.target.value)} placeholder="Ex: Appartement, Maison..." />
          </div>
          <div>
            <label style={LABEL_SM}>Accès au domaine public</label>
            <input style={INPUT_SM} value={dia.accesDomainPublic || ''} onChange={e => set('accesDomainPublic', e.target.value)} placeholder="Ex: Direct, Via servitude..." />
          </div>
          <div>
            <label style={LABEL_SM}>DPE</label>
            <select style={{ ...INPUT_SM, cursor: 'pointer' }} value={dia.dpe || ''} onChange={e => set('dpe', e.target.value)}>
              <option value="">—</option>
              {['A','B','C','D','E','F','G'].map(l => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <label style={LABEL_SM}>Surface terrain m²</label>
            <input style={INPUT_SM} type="number" value={dia.surfaceTerrain || ''} onChange={e => set('surfaceTerrain', e.target.value)} placeholder="m²" />
          </div>
          <div>
            <label style={LABEL_SM}>Surface utile bâtie m²</label>
            <input style={INPUT_SM} type="number" value={dia.surfaceUtileBatie || ''} onChange={e => set('surfaceUtileBatie', e.target.value)} placeholder="m²" />
          </div>
          <div>
            <label style={LABEL_SM}>Motif d'acquisition</label>
            <input style={INPUT_SM} value={dia.motifAcquisition || ''} onChange={e => set('motifAcquisition', e.target.value)} placeholder="Ex: Réhabilitation..." />
          </div>
          <div>
            <label style={LABEL_SM}>Type d'acquisition</label>
            <input style={INPUT_SM} value={dia.typeAcquisition || ''} onChange={e => set('typeAcquisition', e.target.value)} placeholder="Ex: Vente, Donation..." />
          </div>
          <div>
            <label style={LABEL_SM}>Durée de portage</label>
            <input style={INPUT_SM} value={dia.dureePortage || ''} onChange={e => set('dureePortage', e.target.value)} placeholder="Ex: 5 ans" />
          </div>
        </div>
      </Section>

      {/* ══ LOCALISATION — carte auto ═════════════════════════════════════════ */}
      {false && <Section title="Localisation — Carte" color="#0f4c81">
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px', flexWrap: 'wrap' }}>
          <button
            type="button"
            onClick={localiser}
            disabled={geocodage.loading}
            style={{
              padding: '8px 18px', background: geocodage.loading ? '#94a3b8' : '#0f4c81',
              color: 'white', border: 'none', borderRadius: '8px', cursor: geocodage.loading ? 'wait' : 'pointer',
              fontSize: '13px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px',
            }}
          >
            {geocodage.loading ? <><Loader2 size={14} style={{ animation: 'spin 1s linear infinite' }} /> Localisation…</> : <><Map size={14} /> Localiser le bien</>}
          </button>

          {dia.mapLat && dia.mapLon && (
            <>
              <span style={{ fontSize: '12px', color: 'var(--text-sub)' }}>
                <MapPin size={12} style={{ display: 'inline', verticalAlign: 'middle' }} /> {dia.mapLat.toFixed(5)}, {dia.mapLon.toFixed(5)}
              </span>
              <button
                type="button"
                onClick={() => onChange({ ...dia, mapLat: null, mapLon: null })}
                style={{ padding: '4px 10px', background: '#fee2e2', color: '#dc2626', border: '1px solid #fca5a5', borderRadius: '6px', cursor: 'pointer', fontSize: '12px' }}
              >
                ✕ Effacer
              </button>
              <a
                href={`https://www.openstreetmap.org/?mlat=${dia.mapLat}&mlon=${dia.mapLon}#map=17/${dia.mapLat}/${dia.mapLon}`}
                target="_blank" rel="noreferrer"
                style={{ fontSize: '12px', color: '#2563eb', textDecoration: 'none' }}
              >
                ↗ Ouvrir dans OSM
              </a>
            </>
          )}

          {geocodage.error && (
            <span style={{ fontSize: '12px', color: '#dc2626', background: '#fee2e2', padding: '4px 8px', borderRadius: '6px' }}>
              ⚠ {geocodage.error}
            </span>
          )}
        </div>

        <p style={{ fontSize: '11px', color: 'var(--text-muted)', margin: '0 0 10px' }}>
          Renseignez l'adresse et la commune ci-dessus, puis cliquez sur « Localiser le bien » pour générer la carte automatiquement.
        </p>

        {osmUrl && (
          <iframe
            title="Localisation OSM"
            src={osmUrl}
            style={{
              width: '100%', height: '300px',
              border: '1px solid var(--border)', borderRadius: '8px',
              display: 'block',
            }}
            loading="lazy"
            allowFullScreen
          />
        )}

        {!osmUrl && (
          <div style={{
            height: '120px', background: 'var(--bg-panel)', border: '2px dashed #e2e8f0',
            borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#cbd5e1', fontSize: '13px', gap: '8px',
          }}>
            🗺 La carte apparaîtra ici après la localisation
          </div>
        )}
      </Section>}

      {/* ══ RÉPARTITION ══════════════════════════════════════════════════════ */}
      <Section title="Répartition" color="#374151">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
          {[
            ['rezDeChaussee', 'Rez-de-chaussée'],
            ['niveau1', 'Niveau 1'],
            ['niveau2', 'Niveau 2'],
            ['niveau3', 'Niveau 3'],
            ['cave', 'Cave'],
            ['exterieures', 'Extérieures'],
          ].map(([key, label]) => (
            <div key={key}>
              <label style={LABEL_SM}>{label}</label>
              <input style={INPUT_SM} value={dia[key] || ''} onChange={e => set(key, e.target.value)} placeholder="Description..." />
            </div>
          ))}
        </div>
      </Section>

      {/* ══ FLUIDES ══════════════════════════════════════════════════════════ */}
      <Section title="Fluides" color="#374151">
        {/* En-têtes colonnes */}
        <div style={{ display: 'grid', gridTemplateColumns: '140px 1fr 1fr', gap: '8px', marginBottom: '6px' }}>
          <div />
          <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Emplacement</span>
          <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>N° compteur / PDL</span>
        </div>

        {/* Eau */}
        <div style={{ display: 'grid', gridTemplateColumns: '140px 1fr 1fr', gap: '8px', alignItems: 'center', marginBottom: '8px', padding: '8px', background: 'var(--active-bg)', borderRadius: '6px', border: '1px solid var(--border)' }}>
          <CB checked={dia.fluideEau} onChange={v => set('fluideEau', v)} label="💧 Eau" />
          <input style={{ ...INPUT_SM, background: 'var(--bg-card)' }}
            value={dia.fluideEauEmplacement || ''}
            onChange={e => set('fluideEauEmplacement', e.target.value)}
            placeholder="Ex: Sous-sol, cave..."
            disabled={!dia.fluideEau} />
          <input style={{ ...INPUT_SM, background: 'var(--bg-card)' }}
            value={dia.fluideEauCompteur || ''}
            onChange={e => set('fluideEauCompteur', e.target.value)}
            placeholder="N° compteur eau"
            disabled={!dia.fluideEau} />
        </div>

        {/* Électricité */}
        <div style={{ display: 'grid', gridTemplateColumns: '140px 1fr 1fr', gap: '8px', alignItems: 'center', marginBottom: '8px', padding: '8px', background: '#fefce8', borderRadius: '6px', border: '1px solid #fde68a' }}>
          <CB checked={dia.fluideElectricite} onChange={v => set('fluideElectricite', v)} label="⚡ Électricité" />
          <input style={{ ...INPUT_SM, background: 'var(--bg-card)' }}
            value={dia.fluideElecEmplacement || ''}
            onChange={e => set('fluideElecEmplacement', e.target.value)}
            placeholder="Ex: Local compteurs..."
            disabled={!dia.fluideElectricite} />
          <input style={{ ...INPUT_SM, background: 'var(--bg-card)' }}
            value={dia.fluideElecPDL || ''}
            onChange={e => set('fluideElecPDL', e.target.value)}
            placeholder="PDL / N° compteur élec"
            disabled={!dia.fluideElectricite} />
        </div>

        {/* Gaz */}
        <div style={{ display: 'grid', gridTemplateColumns: '140px 1fr 1fr', gap: '8px', alignItems: 'center', padding: '8px', background: '#fff7ed', borderRadius: '6px', border: '1px solid #fed7aa' }}>
          <CB checked={dia.fluideGaz} onChange={v => set('fluideGaz', v)} label="🔥 Gaz" />
          <input style={{ ...INPUT_SM, background: 'var(--bg-card)' }}
            value={dia.fluideGazEmplacement || ''}
            onChange={e => set('fluideGazEmplacement', e.target.value)}
            placeholder="Ex: Façade, cave..."
            disabled={!dia.fluideGaz} />
          <input style={{ ...INPUT_SM, background: 'var(--bg-card)' }}
            value={dia.fluideGazCompteur || ''}
            onChange={e => set('fluideGazCompteur', e.target.value)}
            placeholder="N° compteur gaz"
            disabled={!dia.fluideGaz} />
        </div>
      </Section>

      {/* ══ ÉLECTRICITÉ + AMIANTE/PLOMB ══════════════════════════════════════ */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
        <Section title="Électricité (décret 2002-120 du 30/01/2002)" color="#92400e">
          <CB checked={dia.elecAbsenceCoupure} onChange={v => set('elecAbsenceCoupure', v)} label="Absence de coupure générale accessible dans le logement" />
          <CB checked={dia.elecCoupureAccessible} onChange={v => set('elecCoupureAccessible', v)} label="Coupure générale accessible [90;180] cm de hauteur ¹" />
          <CB checked={dia.elecAbsenceDifferentiel} onChange={v => set('elecAbsenceDifferentiel', v)} label="Absence de dispositif différentiel" />
          <CB checked={dia.elecAbsenceLiaison} onChange={v => set('elecAbsenceLiaison', v)} label="Absence de liaison équipotentielle des pièces humides" />
          <CB checked={dia.elecConducteurAccessible} onChange={v => set('elecConducteurAccessible', v)} label="Conducteur électrique accessible" />
          <CB checked={dia.elecMaterielVetuste} onChange={v => set('elecMaterielVetuste', v)} label="Matériel vétuste ou inadapté" />
          <CB checked={dia.elecDisjoncteurInadapte} onChange={v => set('elecDisjoncteurInadapte', v)} label="Disjoncteur inadapté en tête de circuit" />
          <CB checked={dia.elecDisjoncteur32A} onChange={v => set('elecDisjoncteur32A', v)} label="Disjoncteur 32A, 6mm² pour la plaque de cuisson ²" />
          <CB checked={dia.elecTableauAccessible} onChange={v => set('elecTableauAccessible', v)} label="Tableau électrique accessible [100;180] cm de hauteur ¹" />
          <CB checked={dia.elecAbsenceObturateur} onChange={v => set('elecAbsenceObturateur', v)} label="Absence d'obturateur dans le tableau" />
          <p style={{ fontSize: '10px', color: 'var(--text-muted)', marginTop: '6px', marginBottom: 0 }}>
            ¹ Non-obligatoire mais fortement conseillé &nbsp;² Décision prise par le SPI
          </p>
        </Section>

        <Section title="Amiante / Plomb" color="#92400e">
          <CB checked={dia.plombCanalisation} onChange={v => set('plombCanalisation', v)} label="Présence de plomb dans les canalisations d'eau froide (décret 2001-1220 du 20/12/2001)" />
          <div style={{ marginBottom: '4px' }}>
            <CB checked={dia.plombPeintures} onChange={v => set('plombPeintures', v)} label="Présence de plomb dans les peintures" />
            {dia.plombPeintures && (
              <div style={{ marginLeft: '22px', display: 'flex', gap: '12px', marginTop: '2px' }}>
                <label style={CB_ROW}>
                  <input type="radio" name="plombEtat" checked={dia.plombEtat === 'bon'} onChange={() => set('plombEtat', 'bon')} style={{ accentColor: '#1e3a5f' }} />
                  Bon état
                </label>
                <label style={CB_ROW}>
                  <input type="radio" name="plombEtat" checked={dia.plombEtat === 'mauvais'} onChange={() => set('plombEtat', 'mauvais')} style={{ accentColor: '#dc2626' }} />
                  Mauvais état
                </label>
              </div>
            )}
          </div>
          <div style={{ marginBottom: '4px' }}>
            <CB checked={dia.amiante} onChange={v => set('amiante', v)} label="Présence d'amiante" />
            {dia.amiante && (
              <div style={{ marginLeft: '22px', display: 'flex', gap: '12px', marginTop: '2px' }}>
                <label style={CB_ROW}>
                  <input type="radio" name="amianteType" checked={dia.amianteType === 'A'} onChange={() => set('amianteType', 'A')} style={{ accentColor: '#1e3a5f' }} />
                  Liste A
                </label>
                <label style={CB_ROW}>
                  <input type="radio" name="amianteType" checked={dia.amianteType === 'B'} onChange={() => set('amianteType', 'B')} style={{ accentColor: '#1e3a5f' }} />
                  Liste B
                </label>
              </div>
            )}
          </div>
        </Section>
      </div>

      {/* ══ CHAUFFAGE + ECS ══════════════════════════════════════════════════ */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
        <Section title="Chauffage" color="#065f46">
          <div style={{ marginBottom: '8px' }}>
            <label style={{ ...LABEL_SM, marginBottom: '4px' }}>Mode</label>
            <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
              <CB checked={dia.chauffageIndividuel} onChange={v => set('chauffageIndividuel', v)} label="Individuel" />
              <CB checked={dia.chauffageCentral} onChange={v => set('chauffageCentral', v)} label="Central" />
              <CB checked={dia.chauffageAppoint} onChange={v => set('chauffageAppoint', v)} label="Appoint" />
              <CB checked={dia.chauffageCollectif} onChange={v => set('chauffageCollectif', v)} label="Collectif" />
            </div>
          </div>
          <div style={{ marginBottom: '8px' }}>
            <label style={{ ...LABEL_SM, marginBottom: '4px' }}>Énergie</label>
            <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
              <CB checked={dia.chauffageElectrique} onChange={v => set('chauffageElectrique', v)} label="Électrique" />
              <CB checked={dia.chauffageGaz} onChange={v => set('chauffageGaz', v)} label="Gaz" />
              <CB checked={dia.chauffageFioul} onChange={v => set('chauffageFioul', v)} label="Fioul" />
              <CB checked={dia.chauffagePAC} onChange={v => set('chauffagePAC', v)} label="PAC" />
            </div>
          </div>
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '4px' }}>
            <CB checked={dia.chauffageAutreCheck} onChange={v => set('chauffageAutreCheck', v)} label="Autre :" />
            {dia.chauffageAutreCheck && (
              <input style={{ ...INPUT_SM, flex: 1 }} value={dia.chauffageAutre || ''} onChange={e => set('chauffageAutre', e.target.value)} placeholder="Préciser..." />
            )}
          </div>
          <CB checked={dia.chauffageNonConformite} onChange={v => set('chauffageNonConformite', v)} label="Non-conformité de la fumisterie" />
        </Section>

        <Section title="Eau Chaude Sanitaire" color="#065f46">
          <div style={{ marginBottom: '8px', display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
            <CB checked={dia.ecsChaudiere} onChange={v => set('ecsChaudiere', v)} label="Sur chaudière" />
            <CB checked={dia.ecsChauffeEau} onChange={v => set('ecsChauffeEau', v)} label="Chauffe-eau" />
          </div>
          <div style={{ marginBottom: '8px', display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
            <CB checked={dia.ecsElectrique} onChange={v => set('ecsElectrique', v)} label="Électrique" />
            <CB checked={dia.ecsGaz} onChange={v => set('ecsGaz', v)} label="Gaz" />
          </div>
          <div>
            <label style={LABEL_SM}>Volume (litres)</label>
            <input style={INPUT_SM} type="number" value={dia.ecsVolume || ''} onChange={e => set('ecsVolume', e.target.value)} placeholder="Ex: 100" />
          </div>
        </Section>
      </div>

      {/* ══ MENUISERIES + ASSAINISSEMENT ═════════════════════════════════════ */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
        <Section title="Menuiseries" color="#1e40af">
          <div style={{ marginBottom: '6px' }}>
            <label style={{ ...LABEL_SM, marginBottom: '4px' }}>Matériau</label>
            <div style={{ display: 'flex', gap: '16px' }}>
              <CB checked={dia.menuBois} onChange={v => set('menuBois', v)} label="Bois" />
              <CB checked={dia.menuAlu} onChange={v => set('menuAlu', v)} label="Aluminium" />
              <CB checked={dia.menuPVC} onChange={v => set('menuPVC', v)} label="PVC" />
            </div>
          </div>
          <div style={{ marginBottom: '6px' }}>
            <label style={{ ...LABEL_SM, marginBottom: '4px' }}>Vitrage</label>
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              <CB checked={dia.menuSimpleVitrage} onChange={v => set('menuSimpleVitrage', v)} label="Simple vitrage" />
              <CB checked={dia.menuDoubleVitrage} onChange={v => set('menuDoubleVitrage', v)} label="Double vitrage" />
              <CB checked={dia.menuTripleVitrage} onChange={v => set('menuTripleVitrage', v)} label="Triple vitrage" />
            </div>
          </div>
          <div style={{ marginBottom: '6px' }}>
            <label style={{ ...LABEL_SM, marginBottom: '4px' }}>Volets — Matériau</label>
            <div style={{ display: 'flex', gap: '16px' }}>
              <CB checked={dia.menuVoletBois} onChange={v => set('menuVoletBois', v)} label="Bois" />
              <CB checked={dia.menuVoletMetal} onChange={v => set('menuVoletMetal', v)} label="Métal" />
              <CB checked={dia.menuVoletPVC} onChange={v => set('menuVoletPVC', v)} label="PVC" />
            </div>
          </div>
          <div>
            <label style={{ ...LABEL_SM, marginBottom: '4px' }}>Volets — Commande</label>
            <div style={{ display: 'flex', gap: '16px' }}>
              <CB checked={dia.menuManuel} onChange={v => set('menuManuel', v)} label="Manuel" />
              <CB checked={dia.menuElectrique} onChange={v => set('menuElectrique', v)} label="Électrique" />
            </div>
          </div>
        </Section>

        <Section title="Assainissement" color="#1e40af">
          <CB checked={dia.assainToutEgout} onChange={v => set('assainToutEgout', v)} label="Tout à l'égout" />
          <CB checked={dia.assainNonCollectif} onChange={v => set('assainNonCollectif', v)} label="Assainissement non collectif" />
          <CB checked={dia.assainFuites} onChange={v => set('assainFuites', v)} label="Fuites, remontées d'odeurs, refoulements" />
          <CB checked={dia.assainRejet} onChange={v => set('assainRejet', v)} label="Rejet d'EP et d'EU dans le même réseau" />
          <CB checked={dia.assainMachineALaver} onChange={v => set('assainMachineALaver', v)} label="Présence d'une évacuation pour machine à laver" />
        </Section>
      </div>

      {/* ══ VENTILATION ══════════════════════════════════════════════════════ */}
      <Section title="Ventilation" color="#4c1d95">
        <div style={{ display: 'flex', gap: '24px', flexWrap: 'wrap' }}>
          <CB checked={dia.ventNaturelle} onChange={v => set('ventNaturelle', v)} label="Naturelle" />
          <CB checked={dia.ventMecanisee} onChange={v => set('ventMecanisee', v)} label="Mécanisée" />
          <CB checked={dia.ventDetalonnage} onChange={v => set('ventDetalonnage', v)} label="Détalonnage des portes suffisant" />
          <CB checked={dia.ventHumidite} onChange={v => set('ventHumidite', v)} label="Traces d'humidité / moisissures" />
        </div>
      </Section>

      {/* ══ MURS / TOITURE / PLANCHERS ═══════════════════════════════════════ */}
      <Section title="Murs extérieurs — Toiture — Planchers" color="#7f1d1d">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
          <div>
            <label style={{ ...LABEL_SM, color: '#7f1d1d', marginBottom: '6px' }}>Murs extérieurs</label>
            <CB checked={dia.mursFissures} onChange={v => set('mursFissures', v)} label="Fissures" />
            <CB checked={dia.mursHumidite} onChange={v => set('mursHumidite', v)} label="Humidité" />
            <CB checked={dia.mursRevetements} onChange={v => set('mursRevetements', v)} label="Revêtements dégradés" />
          </div>
          <div>
            <label style={{ ...LABEL_SM, color: '#7f1d1d', marginBottom: '6px' }}>Toiture</label>
            <CB checked={dia.toitureCouverture} onChange={v => set('toitureCouverture', v)} label="Couverture dégradée" />
            <CB checked={dia.toitureCharpente} onChange={v => set('toitureCharpente', v)} label="Charpente dégradée" />
            <CB checked={dia.toitureInfiltrations} onChange={v => set('toitureInfiltrations', v)} label="Infiltrations / Humidité" />
            <CB checked={dia.toitureXylophage} onChange={v => set('toitureXylophage', v)} label="Xylophage" />
            <CB checked={dia.toitureZingueries} onChange={v => set('toitureZingueries', v)} label="Zingueries dégradées" />
            <CB checked={dia.toitureDescentesEP} onChange={v => set('toitureDescentesEP', v)} label="Descentes EP/EU dégradées" />
          </div>
          <div>
            <label style={{ ...LABEL_SM, color: '#7f1d1d', marginBottom: '6px' }}>Planchers</label>
            <CB checked={dia.planchersXylophage} onChange={v => set('planchersXylophage', v)} label="Xylophage" />
            <CB checked={dia.planchersTrous} onChange={v => set('planchersTrous', v)} label="Trous" />
            <CB checked={dia.planchersHumidite} onChange={v => set('planchersHumidite', v)} label="Humidité" />
            <CB checked={dia.planchersPlanéité} onChange={v => set('planchersPlanéité', v)} label="Défaut de planéité" />
            <CB checked={dia.planchersAllege} onChange={v => set('planchersAllege', v)} label="Allège de fenêtre < 90cm ¹" />
            <CB checked={dia.planchersGardeCorps} onChange={v => set('planchersGardeCorps', v)} label="Garde-corps < 1m et 11cm entre barreaux ¹" />
            <CB checked={dia.planchersMainCourante} onChange={v => set('planchersMainCourante', v)} label="Main courante [80;100] cm ²" />
            <CB checked={dia.planchersEscaliers} onChange={v => set('planchersEscaliers', v)} label="Escaliers < 70cm de largeur ¹" />
          </div>
        </div>
        <p style={{ fontSize: '10px', color: 'var(--text-muted)', marginTop: '8px', marginBottom: 0 }}>
          ¹ Mesure non-obligatoire mais fortement conseillée &nbsp;² Décision prise par le SPI
        </p>
      </Section>

      {/* ══ SURFACE ══════════════════════════════════════════════════════════ */}
      <Section title="Surface (décret 2002-120 du 30/01/2002)" color="#374151">
        <CB
          checked={dia.surfaceHauteur}
          onChange={v => set('surfaceHauteur', v)}
          label="Hauteur sous plafond ≥ 220cm ou au moins une pièce principale ≥ 9m² et ≥ 20m³"
        />
      </Section>

      {/* ══ COMMENTAIRES + PRÉVISION DE TRAVAUX ══════════════════════════════ */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
        <Section title="Commentaires" color="#374151">
          <textarea
            rows={5}
            style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid var(--border)', fontSize: '13px', resize: 'vertical', fontFamily: 'inherit', lineHeight: '1.5', boxSizing: 'border-box', background: 'var(--input)', color: 'var(--text)' }}
            placeholder="Commentaires généraux..."
            value={dia.commentaires || ''}
            onChange={e => set('commentaires', e.target.value)}
          />
        </Section>
        <Section title="Prévision de travaux" color="#374151">
          <textarea
            rows={5}
            style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid var(--border)', fontSize: '13px', resize: 'vertical', fontFamily: 'inherit', lineHeight: '1.5', boxSizing: 'border-box', background: 'var(--input)', color: 'var(--text)' }}
            placeholder="Travaux à prévoir, estimations..."
            value={dia.previsionTravaux || ''}
            onChange={e => set('previsionTravaux', e.target.value)}
          />
        </Section>
      </div>

      {/* ══ PHOTOS ═══════════════════════════════════════════════════════════ */}
      <Section title="Photos" color="#374151">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
          <span style={{ fontSize: '13px', color: 'var(--text)' }}>
            {(dia.photos || []).length} photo{(dia.photos || []).length !== 1 ? 's' : ''}
          </span>
          <button type="button"
            style={{ padding: '6px 14px', background: '#1e3a5f', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '13px' }}
            onClick={() => document.getElementById('diaPhoto').click()}>
            + Ajouter une photo
          </button>
          <input type="file" id="diaPhoto" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={ajouterPhoto} />
        </div>
        {(dia.photos || []).length > 0 && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '10px' }}>
            {dia.photos.map((photo, index) => (
              <div key={index} style={{ border: '1px solid var(--border)', borderRadius: '8px', overflow: 'hidden' }}>
                <div style={{ position: 'relative' }}>
                  <img src={photo.src} alt={`Photo ${index + 1}`}
                    style={{ width: '100%', height: '120px', objectFit: 'cover', display: 'block' }} />
                  <button type="button" onClick={() => supprimerPhoto(index)}
                    style={{ position: 'absolute', top: '4px', right: '4px', background: 'rgba(239,68,68,0.85)', border: 'none', borderRadius: '4px', color: 'white', cursor: 'pointer', padding: '3px 6px', fontSize: '11px' }}>
                    ✕
                  </button>
                </div>
                <div style={{ padding: '6px 8px' }}>
                  <input type="text" value={photo.legende || ''} onChange={e => modifierLegende(index, e.target.value)}
                    placeholder={`Légende ${index + 1}...`}
                    style={{ width: '100%', border: 'none', borderBottom: '1px solid var(--border)', outline: 'none', fontSize: '12px', padding: '2px 0', background: 'transparent', boxSizing: 'border-box' }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </Section>

      {/* ══ PLAN — upload ou import depuis Plans ══════════════════════════════ */}
      <Section title="Plan du bien" color="#374151">
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', marginBottom: '12px', flexWrap: 'wrap' }}>
          {/* Import depuis Plans */}
          <button type="button"
            onClick={() => setShowPlanModal(true)}
            style={{ padding: '8px 16px', background: '#2563eb', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', fontSize: '13px', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}>
            📐 Importer depuis Plans
          </button>

          {/* Upload image */}
          <button type="button"
            style={{ padding: '8px 16px', background: '#374151', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer', fontSize: '13px', fontWeight: '600' }}
            onClick={() => document.getElementById('diaPlan').click()}>
            {dia.plan ? '🔄 Changer l\'image' : '🖼 Upload image'}
          </button>

          {(dia.planImporte || dia.plan) && (
            <button type="button"
              onClick={() => onChange({ ...dia, plan: null, planImporte: null })}
              style={{ padding: '6px 12px', background: '#fee2e2', color: '#dc2626', border: '1px solid #fca5a5', borderRadius: '6px', cursor: 'pointer', fontSize: '12px' }}>
              ✕ Supprimer
            </button>
          )}

          <input type="file" id="diaPlan" accept="image/*" style={{ display: 'none' }}
            onChange={async e => {
              const file = e.target.files[0];
              if (!file) return;
              e.target.value = '';
              try {
                const plan = await compressedPhotoDataUrl(file, 2048);
                onChange(current => ({ ...current, plan, planImporte: null }));
              } catch (error) { alert(error.message || 'Photo impossible à compresser.'); }
            }} />
        </div>

        {/* Affichage plan importé depuis Plans */}
        {dia.planImporte && (
          <div style={{ border: '1px solid #93c5fd', borderRadius: '8px', overflow: 'hidden', background: '#eff6ff' }}>
            <div style={{ padding: '6px 12px', background: '#dbeafe', fontSize: '12px', color: '#1d4ed8', fontWeight: '600', display: 'flex', alignItems: 'center', gap: '6px' }}>
              📐 Plan importé : {dia.planImporte.nom}
            </div>
            <div style={{ padding: '8px' }}>
              <PlanMini elements={dia.planImporte.elements} height={200} />
            </div>
          </div>
        )}

        {/* Affichage image uploadée */}
        {dia.plan && !dia.planImporte && (
          <img src={dia.plan} alt="Plan du bien"
            style={{ maxWidth: '100%', maxHeight: '400px', borderRadius: '8px', border: '1px solid var(--border)', objectFit: 'contain', display: 'block' }} />
        )}

        {!dia.plan && !dia.planImporte && (
          <div style={{ height: '80px', background: 'var(--bg-panel)', border: '2px dashed #e2e8f0', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#cbd5e1', fontSize: '13px', gap: '8px' }}>
            📐 Aucun plan attaché
          </div>
        )}
      </Section>

      {/* ══ Modal import plan ═════════════════════════════════════════════════ */}
      {showPlanModal && (
        <PlanImportModal
          plans={plans}
          onSelect={importerPlan}
          onClose={() => setShowPlanModal(false)}
        />
      )}
    </div>
  );
}
