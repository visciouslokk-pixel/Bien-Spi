// src/services/pdfService.js
import html2pdf from 'html2pdf.js';
import { applyMetropoleBranding, PDF_DOCUMENT_MARGINS } from '../../../infrastructure/pdf/metropoleBranding';
import { deliverGeneratedPdf } from '../../../infrastructure/share/documentDelivery';
import { preparePdfDocument } from '../../../infrastructure/pdf/documentTheme';

export async function genererPDF(rapport) {
  // Construit le HTML du rapport (DIA ou standard)
  const html = rapport.type === 'DIA' ? buildDIAHTML(rapport) : buildRapportHTML(rapport);

  // Crée un conteneur temporaire — thème blanc forcé (anti dark-mode)
  const container = document.createElement('div');
  container.style.cssText = 'color:#000;background:#fff;--text:#000;--text-sub:#555;--text-muted:#888;--bg:#fff;--bg-card:#fff;--bg-panel:#f9fafb;--border:#ccc;';
  container.innerHTML = html;
  document.body.appendChild(container);

  const nomFichier = `Rapport_${rapport.chantier.replace(/\s+/g, '_')}_${rapport.dateVisite}.pdf`;

  try {
    await preparePdfDocument(container, rapport.type === 'DIA' ? 'DIA' : 'RAPPORT');
    const pdf = await html2pdf()
      .set({
        margin:      PDF_DOCUMENT_MARGINS,
        filename:    nomFichier,
        html2canvas: { scale: 2, useCORS: true, backgroundColor: '#ffffff' },
        jsPDF:       { unit: 'mm', format: 'a4', orientation: 'portrait' },
      })
      .from(container)
      .toPdf()
      .get('pdf');
    applyMetropoleBranding(pdf);
    return deliverGeneratedPdf(nomFichier, pdf.output('blob'));
  } finally {
    document.body.removeChild(container);
  }
}

function buildRapportHTML(r) {
  const sections = [
    { titre: 'Observations générales',   contenu: r.observations,         couleur: '#EAF3DE' },
    { titre: 'Problèmes rencontrés',     contenu: r.problemesRencontres,  couleur: '#FCEBEB' },
    { titre: 'Décisions et actions',     contenu: r.decisionsActes,       couleur: '#FAEEDA' },
    { titre: 'Travaux prévus',           contenu: r.travauxPrevus,        couleur: '#EEEDFE' },
    { titre: 'Réserves et observations', contenu: r.reservesObservations, couleur: '#F1EFE8' },
  ];

  return `
    <div style="font-family: Arial, sans-serif; font-size: 12px; color: #1A1A1A; padding: 10px;">
      <p style="font-size: 10px; color: #888; margin: 0 0 8px;">ERP Bâtiment — Rapport de Chantier</p>
      <hr style="border: none; border-top: 0.5px solid #ddd; margin-bottom: 16px;"/>
      <h1 style="font-size: 22px; font-weight: bold; margin: 0 0 4px;">${r.titre ? r.titre + ' — ' + r.chantier : r.chantier}</h1>
      <p style="font-size: 13px; color: #555; margin: 0 0 4px;">${r.type} — ${r.dateVisite}</p>
      ${r.adresse ? `<p style="font-size: 12px; color: #888; margin: 0 0 20px; display:flex; align-items:center; gap:4px;">📍 ${r.adresse}</p>` : '<div style="margin-bottom:20px;"></div>'}
      <table style="width:100%; border-collapse:collapse; background:#F5F5F2; margin-bottom:20px;">
        <tr>
          <td style="padding:8px 12px;"><span style="font-size:9px;color:#999">TYPE</span><br/><strong>${r.type}</strong></td>
          <td style="padding:8px 12px;border-left:0.5px solid #ddd;"><span style="font-size:9px;color:#999">DATE</span><br/><strong>${r.dateVisite}</strong></td>
          <td style="padding:8px 12px;border-left:0.5px solid #ddd;"><span style="font-size:9px;color:#999">RÉDIGÉ PAR</span><br/><strong>${r.redacteur || r.creePar || '—'}</strong></td>
          <td style="padding:8px 12px;border-left:0.5px solid #ddd;"><span style="font-size:9px;color:#999">INTERVENANTS</span><br/><strong>${(Array.isArray(r.intervenants) ? r.intervenants.join(', ') : r.intervenants) || '—'}</strong></td>
        </tr>
      </table>
      ${sections
        .filter(s => s.contenu && s.contenu.trim())
        .map(s => `
          <div style="margin-bottom:14px;">
            <div style="background:${s.couleur}; padding:7px 12px; font-size:9px; font-weight:bold; color:#555; letter-spacing:0.05em; text-transform:uppercase;">
              ${s.titre}
            </div>
            <div style="border:0.5px solid #e0e0e0; padding:10px 12px; border-top:none; white-space:pre-line;">
              ${s.contenu}
            </div>
          </div>
        `).join('')}
      ${(r.datesPassage && r.datesPassage.filter(d => d).length > 0) ? `
        <div style="margin-bottom:14px;">
          <div style="background:#EEEDFE; padding:7px 12px; font-size:9px; font-weight:bold; color:#555; letter-spacing:0.05em; text-transform:uppercase;">
            Dates de passage programmées
          </div>
          <div style="border:0.5px solid #e0e0e0; padding:10px 12px; border-top:none;">
            <table style="width:100%; border-collapse:collapse;">
              ${r.datesPassage.filter(d => d).map((date, i) => `
                <tr>
                  <td style="padding:4px 8px; font-size:12px; color:#555; width:80px;">Passage ${i + 1}</td>
                  <td style="padding:4px 8px; font-size:13px; font-weight:bold; color:#222;">
                    ${new Date(date + 'T00:00:00').toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
                  </td>
                </tr>
              `).join('')}
            </table>
          </div>
        </div>
      ` : ''}

      ${r.typeMaintenance ? `
        <div style="margin-bottom:14px;">
          <div style="background:${r.typeMaintenance === 'Curative' ? '#FCEBEB' : '#EAF3DE'}; padding:7px 12px; font-size:9px; font-weight:bold; color:#555; letter-spacing:0.05em; text-transform:uppercase;">
            Type de maintenance
          </div>
          <div style="border:0.5px solid #e0e0e0; padding:10px 12px; border-top:none; font-size:13px; font-weight:bold; color:${r.typeMaintenance === 'Curative' ? '#7A1F1F' : '#27500A'};">
            ${r.typeMaintenance === 'Curative' ? 'Maintenance curative' : 'Maintenance préventive'}
          </div>
        </div>
      ` : ''}

      ${(r.photos && r.photos.length > 0) ? `
  <div style="margin-bottom:14px; page-break-inside:avoid;">
    <div style="background:#F1EFE8; padding:7px 12px; font-size:9px; font-weight:bold; color:#555; letter-spacing:0.05em; text-transform:uppercase; margin-bottom:0;">
      Photos (${r.photos.length})
    </div>
    <div style="border:0.5px solid #e0e0e0; padding:12px; border-top:none;">
      <table style="width:100%; border-collapse:collapse;">
        <tr>
          ${r.photos.map((p, i) => `
            <td style="width:${Math.floor(100/Math.min(r.photos.length,3))}%; padding:6px; vertical-align:top; text-align:center;">
              <img src="${p.src}" style="width:100%; max-height:180px; object-fit:cover; border:1px solid #e0e0e0; border-radius:4px;" />
              ${p.legende ? `<div style="font-size:10px; color:#666; margin-top:4px; font-style:italic;">${p.legende}</div>` : ''}
            </td>
            ${(i + 1) % 3 === 0 && i < r.photos.length - 1 ? '</tr><tr>' : ''}
          `).join('')}
        </tr>
      </table>
    </div>
  </div>
` : ''}
      <hr style="border:none; border-top:0.5px solid #ddd; margin-top:24px;"/>
      <table style="width:100%; font-size:9px; color:#999; margin-top:6px;">
        <tr>
          <td>ERP Bâtiment — CONFIDENTIEL</td>
          <td style="text-align:right;">Document généré le ${new Date().toLocaleDateString('fr-FR')}</td>
        </tr>
      </table>
    </div>
  `;
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function cb(val, label) {
  const box = val ? '☑' : '☐';
  return `<span style="font-size:13px;">${box} ${label}</span>`;
}

function row(...items) {
  return `<div style="display:flex; gap:16px; flex-wrap:wrap; margin-bottom:4px;">${items.join('')}</div>`;
}

// sec() : section complète avec page-break-inside:avoid
function sec(title, content, color = '#1e3a5f') {
  return `<div style="page-break-inside:avoid; margin-bottom:10px;">
    <div class="bs-pdf-section-title" style="background:${color}; color:white; padding:5px 10px; font-weight:700; font-size:11px; text-transform:uppercase; letter-spacing:0.05em;">${title}</div>
    <div style="border:1px solid #cbd5e1; border-top:none; padding:10px; font-size:12px; color:#1a1a1a;">${content}</div>
  </div>`;
}

// secPair() : deux sections côte à côte, non-coupables
function secPair(left, right) {
  return `<div style="page-break-inside:avoid; margin-bottom:10px;">
    <table style="width:100%; border-collapse:collapse;">
      <tr>
        <td style="width:50%; vertical-align:top; padding-right:6px;">${left}</td>
        <td style="width:50%; vertical-align:top; padding-left:6px;">${right}</td>
      </tr>
    </table>
  </div>`;
}

function field(label, value) {
  if (!value && value !== false) return '';
  return `<div style="margin-bottom:4px;"><span style="font-weight:600; font-size:11px; color:#555;">${label} : </span><span>${value || '—'}</span></div>`;
}

// secInner() : version sans wrapper externe (pour imbrication dans secPair)
function secInner(title, content, color = '#1e3a5f') {
  return `<div style="background:${color}; color:white; padding:5px 10px; font-weight:700; font-size:11px; text-transform:uppercase; letter-spacing:0.05em;">${title}</div>
    <div style="border:1px solid #cbd5e1; border-top:none; padding:10px; font-size:12px; color:#1a1a1a;">${content}</div>`;
}

// ── Générateur PDF DIA ──────────────────────────────────────────────────────
function buildDIAHTML(r) {
  const d = r.dia || {};

  // ── Identification ───────────────────────────────────────────────────────
  const identSection = sec('Identification du bien', `
    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:6px;">
      ${field('Commune', d.commune)}
      ${field('Adresse', d.adresse)}
      ${field('Identifiant Fiscal', d.identifiantFiscal)}
      ${field('Année de construction', d.anneeConstruction)}
      ${field('Type de bien', d.typeBien)}
      ${field('Accès domaine public', d.accesDomainPublic)}
      ${field('Surface terrain m²', d.surfaceTerrain)}
      ${field('Surface utile bâtie m²', d.surfaceUtileBatie)}
      ${field('Motif d\'acquisition', d.motifAcquisition)}
      ${field('Type d\'acquisition', d.typeAcquisition)}
      ${field('Durée de portage', d.dureePortage)}
      ${field('DPE', d.dpe)}
    </div>
  `);

  // ── Répartition ─────────────────────────────────────────────────────────
  const repartSection = sec('Répartition', `
    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:6px;">
      ${field('Rez-de-chaussée', d.rezDeChaussee)}
      ${field('Niveau 1', d.niveau1)}
      ${field('Niveau 2', d.niveau2)}
      ${field('Niveau 3', d.niveau3)}
      ${field('Cave', d.cave)}
      ${field('Extérieures', d.exterieures)}
    </div>
  `, '#374151');

  // ── Fluides ─────────────────────────────────────────────────────────────
  const fluidesSection = sec('Fluides', `
    <table style="width:100%; border-collapse:collapse; font-size:12px;">
      <thead>
        <tr style="background:#f1f5f9;">
          <th style="padding:5px 8px; text-align:left; font-size:10px; color:#6b7280; font-weight:700; text-transform:uppercase; width:120px;">Fluide</th>
          <th style="padding:5px 8px; text-align:left; font-size:10px; color:#6b7280; font-weight:700; text-transform:uppercase;">Emplacement</th>
          <th style="padding:5px 8px; text-align:left; font-size:10px; color:#6b7280; font-weight:700; text-transform:uppercase;">N° compteur / PDL</th>
        </tr>
      </thead>
      <tbody>
        <tr style="border-bottom:1px solid #e5e7eb;">
          <td style="padding:6px 8px;">${cb(d.fluideEau, 'Eau')}</td>
          <td style="padding:6px 8px; color:#374151;">${d.fluideEauEmplacement || '—'}</td>
          <td style="padding:6px 8px; color:#374151;">${d.fluideEauCompteur || '—'}</td>
        </tr>
        <tr style="border-bottom:1px solid #e5e7eb;">
          <td style="padding:6px 8px;">${cb(d.fluideElectricite, 'Électricité')}</td>
          <td style="padding:6px 8px; color:#374151;">${d.fluideElecEmplacement || '—'}</td>
          <td style="padding:6px 8px; color:#374151;">${d.fluideElecPDL || '—'}</td>
        </tr>
        <tr>
          <td style="padding:6px 8px;">${cb(d.fluideGaz, 'Gaz')}</td>
          <td style="padding:6px 8px; color:#374151;">${d.fluideGazEmplacement || '—'}</td>
          <td style="padding:6px 8px; color:#374151;">${d.fluideGazCompteur || '—'}</td>
        </tr>
      </tbody>
    </table>
  `, '#374151');

  // ── Électricité ─────────────────────────────────────────────────────────
  const elecSection = secInner('Électricité (décret 2002-120 du 30/01/2002)', `
      ${[
        [d.elecAbsenceCoupure,       'Absence de coupure générale accessible dans le logement'],
        [d.elecCoupureAccessible,    'Coupure générale accessible [90;180] cm de hauteur ¹'],
        [d.elecAbsenceDifferentiel,  'Absence de dispositif différentiel'],
        [d.elecAbsenceLiaison,       'Absence de liaison équipotentielle des pièces humides'],
        [d.elecConducteurAccessible, 'Conducteur électrique accessible'],
        [d.elecMaterielVetuste,      'Matériel vétuste ou inadapté'],
        [d.elecDisjoncteurInadapte,  'Disjoncteur inadapté en tête de circuit'],
        [d.elecDisjoncteur32A,       'Disjoncteur 32A, 6mm² pour la plaque de cuisson ²'],
        [d.elecTableauAccessible,    'Tableau électrique accessible [100;180] cm ¹'],
        [d.elecAbsenceObturateur,    'Absence d\'obturateur dans le tableau'],
      ].map(([v, l]) => `<div style="margin-bottom:3px;">${cb(v, l)}</div>`).join('')}
      <p style="font-size:9px; color:#9ca3af; margin:6px 0 0;">¹ Non-obligatoire mais fortement conseillé &nbsp; ² Décision SPI</p>
    `, '#92400e');

  // ── Amiante/Plomb ───────────────────────────────────────────────────────
  const amianteSection = secInner('Amiante / Plomb', `
      <div style="margin-bottom:3px;">${cb(d.plombCanalisation, 'Présence de plomb dans les canalisations d\'eau froide (décret 2001-1220)')}</div>
      <div style="margin-bottom:3px;">${cb(d.plombPeintures, 'Présence de plomb dans les peintures')}
        ${d.plombPeintures ? `<span style="margin-left:10px; font-size:11px; color:#555;">${d.plombEtat === 'bon' ? '☑ Bon état  ☐ Mauvais état' : d.plombEtat === 'mauvais' ? '☐ Bon état  ☑ Mauvais état' : ''}</span>` : ''}
      </div>
      <div style="margin-bottom:3px;">${cb(d.amiante, 'Présence d\'amiante')}
        ${d.amiante ? `<span style="margin-left:10px; font-size:11px; color:#555;">${d.amianteType === 'A' ? '☑ Liste A  ☐ Liste B' : d.amianteType === 'B' ? '☐ Liste A  ☑ Liste B' : ''}</span>` : ''}
      </div>
    `, '#92400e');

  // ── Chauffage ───────────────────────────────────────────────────────────
  const chauffSection = secInner('Chauffage', `
      <div style="margin-bottom:4px; font-weight:600; font-size:11px; color:#555;">Mode :</div>
      ${row(cb(d.chauffageIndividuel, 'Individuel'), cb(d.chauffageCentral, 'Central'), cb(d.chauffageAppoint, 'Appoint'), cb(d.chauffageCollectif, 'Collectif'))}
      <div style="margin:4px 0; font-weight:600; font-size:11px; color:#555;">Énergie :</div>
      ${row(cb(d.chauffageElectrique, 'Électrique'), cb(d.chauffageGaz, 'Gaz'), cb(d.chauffageFioul, 'Fioul'), cb(d.chauffagePAC, 'PAC'))}
      ${d.chauffageAutreCheck ? `<div style="margin-bottom:3px;">${cb(true, 'Autre : ' + (d.chauffageAutre || ''))}</div>` : ''}
      <div style="margin-bottom:3px;">${cb(d.chauffageNonConformite, 'Non-conformité de la fumisterie')}</div>
    `, '#065f46');

  // ── ECS ─────────────────────────────────────────────────────────────────
  const ecsSection = secInner('Eau Chaude Sanitaire', `
      ${row(cb(d.ecsChaudiere, 'Sur chaudière'), cb(d.ecsChauffeEau, 'Chauffe-eau'))}
      ${row(cb(d.ecsElectrique, 'Électrique'), cb(d.ecsGaz, 'Gaz'))}
      ${field('Volume (L)', d.ecsVolume)}
    `, '#065f46');

  // ── Menuiseries ─────────────────────────────────────────────────────────
  const menuSection = secInner('Menuiseries', `
      <div style="margin-bottom:3px; font-weight:600; font-size:11px; color:#555;">Matériau :</div>
      ${row(cb(d.menuBois, 'Bois'), cb(d.menuAlu, 'Aluminium'), cb(d.menuPVC, 'PVC'))}
      <div style="margin:4px 0 3px; font-weight:600; font-size:11px; color:#555;">Vitrage :</div>
      ${row(cb(d.menuSimpleVitrage, 'Simple vitrage'), cb(d.menuDoubleVitrage, 'Double vitrage'), cb(d.menuTripleVitrage, 'Triple vitrage'))}
      <div style="margin:4px 0 3px; font-weight:600; font-size:11px; color:#555;">Volets :</div>
      ${row(cb(d.menuVoletBois, 'Bois'), cb(d.menuVoletMetal, 'Métal'), cb(d.menuVoletPVC, 'PVC'), cb(d.menuManuel, 'Manuel'), cb(d.menuElectrique, 'Électrique'))}
    `, '#1e40af');

  // ── Assainissement ─────────────────────────────────────────────────────
  const assainSection = secInner('Assainissement', `
      ${[
        [d.assainToutEgout,      'Tout à l\'égout'],
        [d.assainNonCollectif,   'Assainissement non collectif'],
        [d.assainFuites,         'Fuites, remontées d\'odeurs, refoulements'],
        [d.assainRejet,          'Rejet d\'EP et d\'EU dans le même réseau'],
        [d.assainMachineALaver,  'Présence d\'une évacuation pour machine à laver'],
      ].map(([v, l]) => `<div style="margin-bottom:3px;">${cb(v, l)}</div>`).join('')}
    `, '#1e40af');

  // ── Ventilation ─────────────────────────────────────────────────────────
  const ventSection = sec('Ventilation', `
      ${row(cb(d.ventNaturelle, 'Naturelle'), cb(d.ventMecanisee, 'Mécanisée'), cb(d.ventDetalonnage, 'Détalonnage des portes suffisant'), cb(d.ventHumidite, 'Traces d\'humidité / moisissures'))}
    `, '#4c1d95');

  // ── Murs / Toiture / Planchers ──────────────────────────────────────────
  const structSection = sec('Murs extérieurs — Toiture — Planchers', `
      <table style="width:100%; border-collapse:collapse; font-size:12px;">
        <tr>
          <td style="width:33%; vertical-align:top; padding-right:10px; border-right:1px solid #e5e7eb;">
            <div style="font-weight:700; margin-bottom:4px; color:#7f1d1d;">Murs extérieurs</div>
            ${[
              [d.mursFissures,     'Fissures'],
              [d.mursHumidite,     'Humidité'],
              [d.mursRevetements,  'Revêtements dégradés'],
            ].map(([v, l]) => `<div style="margin-bottom:2px;">${cb(v, l)}</div>`).join('')}
          </td>
          <td style="width:33%; vertical-align:top; padding:0 10px; border-right:1px solid #e5e7eb;">
            <div style="font-weight:700; margin-bottom:4px; color:#7f1d1d;">Toiture</div>
            ${[
              [d.toitureCouverture,   'Couverture dégradée'],
              [d.toitureCharpente,    'Charpente dégradée'],
              [d.toitureInfiltrations,'Infiltrations / Humidité'],
              [d.toitureXylophage,    'Xylophage'],
              [d.toitureZingueries,   'Zingueries dégradées'],
              [d.toitureDescentesEP,  'Descentes EP/EU dégradées'],
            ].map(([v, l]) => `<div style="margin-bottom:2px;">${cb(v, l)}</div>`).join('')}
          </td>
          <td style="width:34%; vertical-align:top; padding-left:10px;">
            <div style="font-weight:700; margin-bottom:4px; color:#7f1d1d;">Planchers</div>
            ${[
              [d.planchersXylophage,     'Xylophage'],
              [d.planchersTrous,         'Trous'],
              [d.planchersHumidite,      'Humidité'],
              [d.planchersPlanéité,      'Défaut de planéité'],
              [d.planchersAllege,        'Allège fenêtre < 90cm ¹'],
              [d.planchersGardeCorps,    'Garde-corps < 1m ¹'],
              [d.planchersMainCourante,  'Main courante [80;100] cm ²'],
              [d.planchersEscaliers,     'Escaliers < 70cm ¹'],
            ].map(([v, l]) => `<div style="margin-bottom:2px;">${cb(v, l)}</div>`).join('')}
          </td>
        </tr>
      </table>
      <p style="font-size:9px; color:#9ca3af; margin:6px 0 0;">¹ Non-obligatoire mais fortement conseillé &nbsp; ² Décision SPI</p>
    `, '#7f1d1d');

  // ── Surface ─────────────────────────────────────────────────────────────
  const surfaceSection = sec('Surface (décret 2002-120 du 30/01/2002)', `
      <div>${cb(d.surfaceHauteur, 'Hauteur sous plafond ≥ 220cm ou au moins une pièce principale ≥ 9m² et ≥ 20m³')}</div>
    `, '#374151');

  // ── Commentaires / Travaux ──────────────────────────────────────────────
  const commentSection = secPair(
    secInner('Commentaires', `<div style="min-height:60px; white-space:pre-wrap;">${d.commentaires || '—'}</div>`, '#374151'),
    secInner('Prévision de travaux', `<div style="min-height:60px; white-space:pre-wrap;">${d.previsionTravaux || '—'}</div>`, '#374151')
  );

  // ── Photos ─────────────────────────────────────────────────────────────
  const photos = d.photos || [];
  const photosSection = photos.length > 0 ? sec('Photos', `
      <table style="width:100%; border-collapse:collapse;">
        <tr>
          ${photos.map((p, i) => `
            <td style="width:${Math.floor(100 / Math.min(photos.length, 3))}%; padding:6px; vertical-align:top; text-align:center;">
              <img src="${p.src}" style="width:100%; max-height:160px; object-fit:cover; border:1px solid #e0e0e0; border-radius:4px;" />
              ${p.legende ? `<div style="font-size:10px; color:#666; margin-top:3px; font-style:italic;">${p.legende}</div>` : ''}
            </td>
            ${(i + 1) % 3 === 0 && i < photos.length - 1 ? '</tr><tr>' : ''}
          `).join('')}
        </tr>
      </table>
    `, '#374151') : '';

  // ── Carte de localisation ────────────────────────────────────────────────
  const carteSection = (() => {
    if (!d.mapLat || !d.mapLon) return '';
    const adresseComplete = [d.adresse, d.commune].filter(Boolean).join(', ');
    if (d.mapBase64) {
      return sec('Localisation', `
        <div style="display:flex; gap:12px; align-items:flex-start;">
          <img src="${d.mapBase64}"
            style="width:65%; max-height:240px; object-fit:cover; border:1px solid #e2e8f0; border-radius:6px; flex-shrink:0;" />
          <div style="flex:1; font-size:12px; color:#374151;">
            <div style="font-weight:700; font-size:13px; margin-bottom:6px; color:#1e293b;">📍 ${adresseComplete || 'Localisation'}</div>
            <div style="margin-bottom:4px;"><span style="color:#6b7280; font-size:10px;">LATITUDE</span><br/>${d.mapLat.toFixed(6)}</div>
            <div style="margin-bottom:4px;"><span style="color:#6b7280; font-size:10px;">LONGITUDE</span><br/>${d.mapLon.toFixed(6)}</div>
            <div style="margin-top:8px; font-size:10px; color:#94a3b8;">© OpenStreetMap contributors</div>
          </div>
        </div>
      `, '#0f4c81');
    }
    // Pas de base64 disponible — afficher les coordonnées uniquement
    return sec('Localisation', `
      <div style="font-size:12px; color:#374151;">
        <div style="font-weight:700; font-size:13px; margin-bottom:8px; color:#1e293b;">📍 ${adresseComplete || 'Localisation'}</div>
        <div style="display:flex; gap:24px;">
          <div><span style="color:#6b7280; font-size:10px;">LATITUDE</span><br/><strong>${d.mapLat.toFixed(6)}</strong></div>
          <div><span style="color:#6b7280; font-size:10px;">LONGITUDE</span><br/><strong>${d.mapLon.toFixed(6)}</strong></div>
        </div>
        <div style="margin-top:6px; font-size:10px; color:#94a3b8;">© OpenStreetMap contributors</div>
      </div>
    `, '#0f4c81');
  })();

  // ── Plan ────────────────────────────────────────────────────────────────
  const planSection = (() => {
    if (d.planImporte?.elements?.length) {
      // Plan SVG importé depuis Plans — on l'intègre comme image SVG
      const LINE_TYPES = new Set(['wall','wall-thin','wall-ext','beam','foundation',
        'roof-ridge','roof-valley','roof-hip','rafter','purlin','ridge-board','joist']);
      const els = d.planImporte.elements;
      let minX=Infinity, minY=Infinity, maxX=-Infinity, maxY=-Infinity;
      els.forEach(el => {
        if (LINE_TYPES.has(el.type)) {
          minX=Math.min(minX,el.x1,el.x2); minY=Math.min(minY,el.y1,el.y2);
          maxX=Math.max(maxX,el.x1,el.x2); maxY=Math.max(maxY,el.y1,el.y2);
        } else if (el.x!==undefined) {
          minX=Math.min(minX,el.x); minY=Math.min(minY,el.y-(el.height||40)/2);
          maxX=Math.max(maxX,el.x+(el.width||80)); maxY=Math.max(maxY,el.y+(el.height||40)/2);
        }
      });
      const pad=20, vw=maxX-minX+pad*2, vh=maxY-minY+pad*2;
      const colorMap = { wall:'#1e293b','wall-thin':'#475569','wall-ext':'#0f172a',
        beam:'#7c3aed',foundation:'#78350f','roof-ridge':'#b45309',
        'roof-valley':'#b45309','roof-hip':'#b45309',
        rafter:'#92400e',purlin:'#92400e','ridge-board':'#92400e',joist:'#92400e' };
      if (isFinite(minX)) {
        const svgLines = els.map(el => {
          if (LINE_TYPES.has(el.type))
            return `<line x1="${el.x1}" y1="${el.y1}" x2="${el.x2}" y2="${el.y2}" stroke="${colorMap[el.type]||'#475569'}" stroke-width="${el.thickness||8}" stroke-linecap="square"/>`;
          if (el.x!==undefined) {
            const w=el.width||60, h=el.height||40;
            return `<rect x="${el.x}" y="${el.y-h/2}" width="${w}" height="${h}" fill="#dbeafe" stroke="#2563eb" stroke-width="1.5" rx="2"/>`;
          }
          return '';
        }).join('');
        const svgStr = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${minX-pad} ${minY-pad} ${vw} ${vh}" style="width:100%;max-height:300px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:4px;">${svgLines}</svg>`;
        return sec(`Plan — ${d.planImporte.nom}`, svgStr, '#374151');
      }
    }
    if (d.plan) {
      return sec('Plan', `<img src="${d.plan}" style="max-width:100%; max-height:300px; object-fit:contain; border:1px solid #e0e0e0; border-radius:4px;" />`, '#374151');
    }
    return '';
  })();

  return `
    <div style="font-family: Arial, sans-serif; font-size: 12px; color: #1A1A1A; padding: 10px;">
      <h1 style="font-size:20px; font-weight:bold; margin:0 0 4px;">${r.titre || 'Fiche d\'état du bien · DIA'}</h1>
      <p style="font-size:12px; color:#555; margin:0 0 12px;">
        📜 DIA — Métropole de Lyon
        ${d.commune ? ` &nbsp;|&nbsp; 📍 ${d.commune}` : ''}
        &nbsp;|&nbsp; ${r.dateVisite || ''}
      </p>
      <table style="width:100%; border-collapse:collapse; background:#f8fafc; margin-bottom:16px; font-size:11px;">
        <tr>
          <td style="padding:6px 10px;"><span style="color:#888; font-size:9px;">CHANTIER</span><br/><strong>${r.chantier || '—'}</strong></td>
          <td style="padding:6px 10px; border-left:0.5px solid #e0e0e0;"><span style="color:#888; font-size:9px;">DATE</span><br/><strong>${r.dateVisite || '—'}</strong></td>
          <td style="padding:6px 10px; border-left:0.5px solid #e0e0e0;"><span style="color:#888; font-size:9px;">RÉDIGÉ PAR</span><br/><strong>${r.creePar || '—'}</strong></td>
          <td style="padding:6px 10px; border-left:0.5px solid #e0e0e0;"><span style="color:#888; font-size:9px;">INTERVENANTS</span><br/><strong>${r.intervenants || '—'}</strong></td>
        </tr>
      </table>

      ${identSection}
      ${repartSection}
      ${fluidesSection}

      ${secPair(elecSection, amianteSection)}
      ${secPair(chauffSection, ecsSection)}
      ${secPair(menuSection, assainSection)}

      ${ventSection}
      ${structSection}
      ${surfaceSection}
      ${commentSection}
      ${carteSection}
      ${photosSection}
      ${planSection}

      <hr style="border:none; border-top:0.5px solid #ddd; margin-top:20px;"/>
      <table style="width:100%; font-size:9px; color:#999; margin-top:6px;">
        <tr>
          <td>Bien SPI — DIA CONFIDENTIEL</td>
          <td style="text-align:right;">Document généré le ${new Date().toLocaleDateString('fr-FR')}</td>
        </tr>
      </table>
    </div>
  `;
}
