import { useEffect, useRef, useState } from 'react';
import { ArchiveRestore, FileDown, FolderOpen, Save } from 'lucide-react';
import { AppHeader } from '../../components/AppHeader';
import { SaveStatus, type SaveState } from '../../components/SaveStatus';
import { navigate, queryValue } from '../../hooks/useRoute';
import { listRecords, loadRecord, reopenRecord, saveRecord } from '../../infrastructure/storage/records';
import type { StoredRecord } from '../../domain/shared/types';
import DIAForm from './legacy/DIAForm.jsx';
import { generateDiaPdf } from '../../infrastructure/pdf/DiaPdfService';
import { migrateDia } from '../../domain/dia/diaMigration';
import { registerFlush } from '../../infrastructure/storage/flushRegistry';

import { ShareDocumentAction } from '../../app/components/ShareDocumentAction';
import type { ShareFile } from '../../domain/shared/integrationPorts';
import { pdfReadyMessage } from '../../infrastructure/share/documentDelivery';
import { compressedPhotoDataUrl } from '../../infrastructure/media/compressPhoto';

type DiaData = Record<string, unknown> & { commune?: string; adresse?: string; photos?: Array<{ src: string; legende: string }> };

function createDia(): DiaData { return migrateDia({ commune: '', adresse: '', photos: [] }) as DiaData; }

export function DiaEntryPage({ search }: { search: string }) {
  const bienId = queryValue(search, 'bienId');
  const requestedId = queryValue(search, 'id');
  const [recordId, setRecordId] = useState(requestedId);
  const [dia, setDia] = useState<DiaData>(() => createDia());
  const [records, setRecords] = useState<StoredRecord<DiaData>[]>([]);
  const [saveState, setSaveState] = useState<SaveState>('idle');
  const [pdfMessage, setPdfMessage] = useState('');
  const [pdfFile, setPdfFile] = useState<ShareFile | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const pdfLock = useRef(false);
  const hydrated = useRef(false);
  const refresh = async () => setRecords(await listRecords<DiaData>('dia', bienId || undefined));
  const currentRecord = records.find((record) => record.id === recordId);

  useEffect(() => { void refresh(); }, [bienId]);
  useEffect(() => {
    if (!requestedId) { setDia(createDia()); setRecordId(''); hydrated.current = true; return; }
    void loadRecord<DiaData>(requestedId).then((record) => { if (record) { setDia(migrateDia(record.payload) as DiaData); setRecordId(record.id); } hydrated.current = true; });
  }, [requestedId]);

  const persist = async (status: 'draft' | 'finalized' = 'draft') => {
    setSaveState('saving');
    try { const saved = await saveRecord({ id: recordId || undefined, kind: 'dia', bienId: bienId || undefined, payload: dia, status }); if (!recordId) { const params = new URLSearchParams({ ...(bienId ? { bienId } : {}), id: saved.id }); window.history.replaceState({}, '', `/dia/new?${params}`); } setRecordId(saved.id); setSaveState('saved'); await refresh(); return saved; }
    catch { setSaveState('error'); return null; }
  };
  useEffect(() => registerFlush(() => persist()), [dia, recordId]);
  useEffect(() => { if (!hydrated.current) return; setSaveState('saving'); const timer = window.setTimeout(() => { void persist(); }, 700); return () => window.clearTimeout(timer); }, [dia]);

  const addPhoto = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]; if (!file) return;
    event.target.value = '';
    try { const src = await compressedPhotoDataUrl(file); setDia((current) => ({ ...current, photos: [...(current.photos || []), { src, legende: '' }] })); }
    catch { setPdfMessage('Photo non ajoutée : compression impossible, fichier trop volumineux ou format non pris en charge.'); }
  };
  const removePhoto = (index: number) => setDia((current) => ({ ...current, photos: (current.photos || []).filter((_, itemIndex) => itemIndex !== index) }));
  const editLegend = (index: number, legende: string) => setDia((current) => ({ ...current, photos: (current.photos || []).map((photo, itemIndex) => itemIndex === index ? { ...photo, legende } : photo) }));
  const exportPdf = async () => {
    if (pdfLock.current) return;
    pdfLock.current = true; setPdfBusy(true); setPdfFile(null);
    setPdfMessage('Génération du PDF…');
    try {
      const saved = await persist('finalized');
      if (!saved) throw new Error('save');
      const result = await generateDiaPdf(saved.payload, String(dia.adresse || dia.commune || 'Bien_SPI'));
      setPdfFile({ name: result.filename, blob: result.blob, type: 'application/pdf' });
      setPdfMessage(pdfReadyMessage());
    } catch {
      setPdfMessage('Export impossible. Vérifiez l’état de sauvegarde de la saisie puis réessayez.');
    } finally { pdfLock.current = false; setPdfBusy(false); }
  };

  return <>
    <AppHeader title="DIA" backTo={bienId ? `/biens/new?id=${bienId}` : '/'} />
    <main className="bs-form-shell">
      <div className="bs-form-toolbar">
        <h1>Fiche d'état du bien · DIA</h1>
        <label className="bs-inline-select"><FolderOpen /><select aria-label="Reprendre un DIA" value={recordId} onChange={(event) => navigate(`/dia/new?${new URLSearchParams({ ...(bienId ? { bienId } : {}), ...(event.target.value ? { id: event.target.value } : {}) })}`)}><option value="">Nouveau</option>{records.map((record) => <option key={record.id} value={record.id}>{record.status === 'archived' ? '[Archivé] ' : ''}{record.payload.commune || record.payload.adresse || 'DIA sans adresse'} · r{record.revision}</option>)}</select></label>
        {currentRecord && <span className={`bs-record-status is-${currentRecord.status}`}>{currentRecord.status === 'archived' ? 'Archivé' : currentRecord.status === 'finalized' ? 'Finalisé' : 'Brouillon'}</span>}
        <SaveStatus state={saveState} />
        <button className="bs-button" onClick={() => void persist()}><Save />Sauvegarder</button>
        {currentRecord?.status === 'archived' && <button className="bs-button" type="button" onClick={async () => { await reopenRecord(currentRecord.id); await refresh(); }}><ArchiveRestore />Réouvrir</button>}
        <button className="bs-button is-primary" disabled={pdfBusy} onClick={() => void exportPdf()}><FileDown />{pdfBusy ? 'Génération…' : 'Exporter PDF'}</button>
        {pdfMessage && <span className="bs-pdf-message" role="status">{pdfMessage}</span>}
      </div>
      {pdfFile && <ShareDocumentAction file={pdfFile} title="DIA" />}
      <DIAForm dia={dia} onChange={setDia} ajouterPhoto={addPhoto} supprimerPhoto={removePhoto} modifierLegende={editLegend} availablePlans={[]} />
    </main>
  </>;
}
