import { ClipboardCheck, FileSearch } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { navigate } from '../../hooks/useRoute';
import { MetropoleLogo } from '../../components/MetropoleLogo';
import { SupportPanel } from '../settings/SupportPanel';

const actions = [
  { label: 'EDL', detail: 'État des lieux', icon: ClipboardCheck, path: '/edl', color: 'teal' },
  { label: 'DIA', detail: 'Diagnostic complet', icon: FileSearch, path: '/dia/new', color: 'gold' }
] as const;

export function HomePage() {
  return (
    <main className="bs-home">
      <section className="bs-home__intro">
        <div><p>Bien SPI · Service patrimoine</p><h1>Que souhaitez-vous faire&nbsp;?</h1></div>
        <MetropoleLogo />
      </section>
      <section className="bs-home__actions" aria-label="Modules métier">
        {actions.map(({ label, detail, icon: Icon, path, color }) => (
          <button key={label} className={`bs-module-card is-${color}`} type="button" onClick={() => navigate(path)}>
            <Icon aria-hidden="true" />
            <span><strong>{label}</strong><small>{detail}</small></span>
          </button>
        ))}
      </section>
      {!Capacitor.isNativePlatform() && <p><button type="button" className="bs-button" onClick={() => navigate('/installation')}>Installation et préparation hors ligne</button></p>}
      <div className="bs-home-support"><SupportPanel /><span>Assistance et sauvegardes</span></div>
    </main>
  );
}
