import { DIA_FIELDS, diaSchema, type DiaPayload } from './dia.schema';

const RESERVED = new Set<string>([...DIA_FIELDS, 'photos', 'legacyFields']);

export function migrateDia(payload: unknown): DiaPayload {
  const source = payload && typeof payload === 'object' ? { ...(payload as Record<string, unknown>) } : {};
  if (source.accesDomainPublic === undefined && source.accesDomainePublic !== undefined) {
    source.accesDomainPublic = source.accesDomainePublic;
  }
  delete source.accesDomainePublic;
  const existingLegacy = source.legacyFields && typeof source.legacyFields === 'object' ? source.legacyFields as Record<string, unknown> : {};
  const legacyFields = { ...existingLegacy };
  for (const key of Object.keys(source)) {
    if (!RESERVED.has(key)) { legacyFields[key] = source[key]; delete source[key]; }
  }
  return diaSchema.parse({ ...source, legacyFields });
}
