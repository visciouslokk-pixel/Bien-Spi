import { z } from 'zod';

const flexibleValue = z.union([z.string(), z.number(), z.boolean(), z.null()]);

export const DIA_FIELDS = [
  'commune', 'adresse', 'typeBien', 'accesDomainPublic', 'anneeConstruction', 'identifiantFiscal',
  'typeAcquisition', 'motifAcquisition', 'dureePortage', 'surfaceTerrain', 'surfaceUtileBatie',
  'fluideEau', 'fluideEauCompteur', 'fluideEauEmplacement', 'fluideElectricite', 'fluideElecPDL',
  'fluideElecEmplacement', 'fluideGaz', 'fluideGazCompteur', 'fluideGazEmplacement', 'dpe',
  'elecCoupureAccessible', 'elecTableauAccessible', 'elecAbsenceCoupure', 'elecAbsenceDifferentiel',
  'elecAbsenceLiaison', 'elecAbsenceObturateur', 'elecConducteurAccessible', 'elecDisjoncteur32A',
  'elecDisjoncteurInadapte', 'elecMaterielVetuste', 'plombCanalisation', 'plombPeintures',
  'plombEtat', 'amiante', 'amianteType', 'chauffageCentral', 'chauffageIndividuel',
  'chauffageCollectif', 'chauffageElectrique', 'chauffageGaz', 'chauffageFioul', 'chauffagePAC',
  'chauffageAppoint', 'chauffageAutreCheck', 'chauffageAutre', 'chauffageNonConformite',
  'ecsChaudiere', 'ecsChauffeEau', 'ecsElectrique', 'ecsGaz', 'ecsVolume', 'menuBois', 'menuPVC',
  'menuAlu', 'menuSimpleVitrage', 'menuDoubleVitrage', 'menuTripleVitrage', 'menuManuel',
  'menuElectrique', 'menuVoletBois', 'menuVoletPVC', 'menuVoletMetal', 'assainToutEgout',
  'assainNonCollectif', 'assainFuites', 'assainRejet', 'assainMachineALaver', 'ventNaturelle',
  'ventMecanisee', 'ventDetalonnage', 'ventHumidite', 'mursFissures', 'mursHumidite',
  'mursRevetements', 'toitureCharpente', 'toitureCouverture', 'toitureZingueries',
  'toitureDescentesEP', 'toitureInfiltrations', 'toitureXylophage', 'planchersPlan',
  'planchersEscaliers', 'planchersGardeCorps', 'planchersMainCourante', 'planchersAllege',
  'planchersTrous', 'planchersHumidite', 'planchersXylophage', 'surfaceHauteur', 'commentaires',
  'previsionTravaux', 'mapLat', 'mapLon', 'plan', 'planImporte'
] as const;

const diaShape = Object.fromEntries(DIA_FIELDS.map((field) => [field, flexibleValue.optional()])) as Record<(typeof DIA_FIELDS)[number], z.ZodOptional<typeof flexibleValue>>;

export const diaSchema = z.object({
  ...diaShape,
  photos: z.array(z.object({ src: z.string(), legende: z.string().default('') }).passthrough()).default([]),
  legacyFields: z.record(z.string(), z.unknown()).optional().default({})
});

export type DiaPayload = z.infer<typeof diaSchema>;
