import { z } from 'zod';

export const edlTypeSchema = z.enum(['appartement', 'maison', 'terrain', 'entrepot', 'pepiniere_atelier', 'pepiniere_bureau']);

export const edlSchema = z.object({
  typeBien: edlTypeSchema,
  typeEDL: z.string().optional().default(''),
  dateEDL: z.string().optional().default(''),
  pieces: z.array(z.record(z.string(), z.unknown())).default([]),
  cles: z.array(z.record(z.string(), z.unknown())).default([]),
  photos: z.array(z.unknown()).default([]),
  signatures: z.array(z.unknown()).optional().default([]),
  partageAvec: z.array(z.unknown()).optional().default([])
}).catchall(z.unknown());

export type EdlPayload = z.infer<typeof edlSchema>;

export function migrateLegacyEdl(payload: unknown, fallbackType: z.infer<typeof edlTypeSchema> = 'appartement') {
  const source = payload && typeof payload === 'object' ? payload as Record<string, unknown> : {};
  return edlSchema.parse({ ...source, typeBien: source.typeBien ?? fallbackType });
}
