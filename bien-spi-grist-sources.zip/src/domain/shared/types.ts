export type RecordKind = 'bien' | 'security-profile' | 'edl' | 'dia' | 'plan' | 'plan-level' | 'document' | 'report' | 'contact';
export type RecordStatus = 'draft' | 'finalized' | 'archived' | 'trashed';

export interface StoredRecord<T = unknown> {
  id: string;
  kind: RecordKind;
  bienId?: string;
  schemaVersion: number;
  revision: number;
  status: RecordStatus;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
  payload: T;
}

export function createId(prefix = 'id') {
  const uuid = globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return `${prefix}-${uuid}`;
}
