import { useEffect, useMemo, useRef, useState } from 'react';
import { Download, Share2 } from 'lucide-react';
import type { ShareCapability, ShareFile, ShareReceipt } from '../../domain/shared/integrationPorts';
import { deliveryMessage } from '../../infrastructure/share/documentDelivery';
import { createShareAdapter } from '../../infrastructure/share/createShareAdapter';
import { OperationStatus } from './OperationStatus';

export function ShareDocumentAction({ file, title }: { file: ShareFile; title: string }) {
  const adapter = useMemo(() => createShareAdapter(), []);
  const [capabilities, setCapabilities] = useState<ShareCapability[]>([]);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  useEffect(() => { void adapter.capabilities().then(setCapabilities).catch(() => setMessage('Actions indisponibles. Réessayez.')); }, [adapter]);
  const shareMessage = { title, text: `${title} — document généré dans Bien SPI`, subject: title };
  const run = async (operation: () => Promise<ShareReceipt>) => {
    if (lock.current) return;
    lock.current = true; setBusy(true); setMessage('Ouverture…');
    try { setMessage(deliveryMessage(await operation())); }
    catch { setMessage('Opération impossible. Le document reste disponible ici ; vérifiez l’espace libre et réessayez.'); }
    finally { lock.current = false; setBusy(false); }
  };
  return <div className="bs-share-actions" aria-label="Partager le document" aria-busy={busy}>
    <small>{file.name} · Ce PDF reflète la saisie au moment de sa génération.</small>
    {capabilities.includes('download') && <button disabled={busy} type="button" className="bs-button" onClick={() => void run(() => adapter.download(file))}><Download />Enregistrer le PDF</button>}
    {capabilities.includes('system-share') && <button disabled={busy} type="button" className="bs-button" onClick={() => void run(() => adapter.share(file, shareMessage))}><Share2 />Partager</button>}
    {message && <OperationStatus kind={message.includes('impossible') ? 'error' : 'info'}>{message}</OperationStatus>}
    <small>Enregistrez le PDF dans Téléchargements pour le transférer au PC par USB. Le dossier sauvegardé permet de le régénérer.</small>
  </div>;
}
