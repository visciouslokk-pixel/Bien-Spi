import type { ReactNode } from 'react';

export function OperationStatus({ kind, children }: { kind: 'info' | 'success' | 'warning' | 'error'; children: ReactNode }) {
  return <p className={`bs-operation-status is-${kind}`} role={kind === 'error' ? 'alert' : 'status'}>{children}</p>;
}
