export function normalizeCommune(value = '') {
  return value
    .replace(/^Lyon\s+(\d+)(?:er|e|ème)?$/i, 'Lyon $1e Arrondissement')
    .replace(/^Oullins-Pierre-Bénite$/i, 'Oullins-Pierre-Bénite')
    .trim();
}
