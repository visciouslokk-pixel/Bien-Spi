# Bien SPI — interface Grist pilote

Sources expurgées des référentiels internes. Installer Node.js, puis npm install, npm test, npm run build. Résultat : migration/grist/widget/dist. Héberger ce dossier statique sur Pages ou Forge, puis changer l’URL du widget Grist. Ne contient aucun dossier métier. Ne pas utiliser en production avant recette et finalisation du stockage des pièces jointes.
